package it.mdc.tool.core.platformComposer;

import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import net.sf.orcc.ir.Expression;
import net.sf.orcc.ir.Var;
import net.sf.orcc.ir.util.ExpressionEvaluator;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A Verilog Multi-Dataflow Network Test Bench printer
 * 
 * printNetwork() is in charge of printing the top module.
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class TestBenchPrinterGeneric {
  private Network network;
  
  private ProtocolManager protocolManager;
  
  private ExpressionEvaluator evaluator;
  
  public String printNetSysSigKind(final String sysSigId) {
    boolean _equals = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.KIND).equals("input");
    if (_equals) {
      return "reg";
    } else {
      return "wire";
    }
  }
  
  public String printModCommSigKind(final String pred, final String commSigId) {
    boolean _equals = this.protocolManager.getModCommSignals().get(pred).get(commSigId).get(ProtocolManager.KIND).equals("input");
    if (_equals) {
      return "reg";
    } else {
      return "wire";
    }
  }
  
  /**
   * Print test bench time scale.
   */
  public CharSequence printTimeScale() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("`timescale 1 ns / 1 ps");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Print the header of the Verilog file.
   */
  public CharSequence headerComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Test Bench module ");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Please note that the testbench manages only common signals to dataflows");
      _builder.newLine();
      _builder.append("// - clock system signals");
      _builder.newLine();
      _builder.append("// - reset system signals");
      _builder.newLine();
      _builder.append("// - dataflow communication signals");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Print test bench parameters.
   */
  public CharSequence printParameters(final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<String> _keySet = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId : _keySet) {
        {
          boolean _containsKey = this.protocolManager.getNetSysSignals().get(sysSigId).containsKey(ProtocolManager.CLOCK);
          if (_containsKey) {
            _builder.append("parameter ");
            String _upperCase = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP).toUpperCase();
            _builder.append(_upperCase);
            _builder.append("_PERIOD = 10;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    {
      EList<Port> _inputs = this.network.getInputs();
      for(final Port input : _inputs) {
        {
          Set<Integer> _keySet_1 = configMap.keySet();
          for(final Integer config : _keySet_1) {
            _builder.append("parameter ");
            String _upperCase_1 = input.getName().toUpperCase();
            _builder.append(_upperCase_1);
            _builder.append("_");
            String _upperCase_2 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_2);
            _builder.append("_FILE = \"");
            String _name = input.getName();
            _builder.append(_name);
            _builder.append("_");
            String _get = configMap.get(config);
            _builder.append(_get);
            _builder.append("_file.mem\";");
            _builder.newLineIfNotEmpty();
            _builder.append("parameter ");
            String _upperCase_3 = input.getName().toUpperCase();
            _builder.append(_upperCase_3);
            _builder.append("_");
            String _upperCase_4 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_4);
            _builder.append("_SIZE = 64;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    {
      EList<Port> _outputs = this.network.getOutputs();
      for(final Port output : _outputs) {
        {
          Set<Integer> _keySet_2 = configMap.keySet();
          for(final Integer config_1 : _keySet_2) {
            _builder.append("parameter ");
            String _upperCase_5 = output.getName().toUpperCase();
            _builder.append(_upperCase_5);
            _builder.append("_");
            String _upperCase_6 = configMap.get(config_1).toUpperCase();
            _builder.append(_upperCase_6);
            _builder.append("_FILE = \"");
            String _name_1 = output.getName();
            _builder.append(_name_1);
            _builder.append("_");
            String _get_1 = configMap.get(config_1);
            _builder.append(_get_1);
            _builder.append("_file.mem\";");
            _builder.newLineIfNotEmpty();
            _builder.append("parameter ");
            String _upperCase_7 = output.getName().toUpperCase();
            _builder.append(_upperCase_7);
            _builder.append("_");
            String _upperCase_8 = configMap.get(config_1).toUpperCase();
            _builder.append(_upperCase_8);
            _builder.append("_SIZE = 64;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t \t");
    {
      EList<Var> _variables = this.network.getVariables();
      for(final Var netVar : _variables) {
        _builder.append("parameter ");
        {
          int _sizeInBits = netVar.getType().getSizeInBits();
          boolean _notEquals = (_sizeInBits != 1);
          if (_notEquals) {
            _builder.append("[");
            int _sizeInBits_1 = netVar.getType().getSizeInBits();
            int _minus = (_sizeInBits_1 - 1);
            _builder.append(_minus, "\t \t");
            _builder.append(":0] ");
          }
        }
        String _name_2 = netVar.getName();
        _builder.append(_name_2, "\t \t");
        _builder.append(" = ");
        Expression _initialValue = netVar.getInitialValue();
        int _evaluateAsInteger = this.evaluator.evaluateAsInteger(((Expression) _initialValue));
        _builder.append(_evaluateAsInteger, "\t \t");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * Print test bench internal signals.
   */
  public CharSequence printSignals(final List<SboxLut> luts, final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("reg start_feeding;");
    _builder.newLine();
    {
      EList<Port> _inputs = this.network.getInputs();
      for(final Port input : _inputs) {
        {
          Set<String> _keySet = this.protocolManager.getFirstModCommSignals().keySet();
          for(final String commSigId : _keySet) {
            {
              boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId);
              if (_isInputSide) {
                String _printModCommSigKind = this.printModCommSigKind(this.protocolManager.getFirstMod(), commSigId);
                _builder.append(_printModCommSigKind);
                _builder.append(" ");
                String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId, input);
                _builder.append(_commSigPrintRange);
                String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                _builder.append(_sigPrintName);
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        {
          Set<Integer> _keySet_1 = configMap.keySet();
          for(final Integer config : _keySet_1) {
            _builder.append("reg [");
            int _sizeInBits = input.getType().getSizeInBits();
            int _minus = (_sizeInBits - 1);
            _builder.append(_minus);
            _builder.append(":0] ");
            String _name = input.getName();
            _builder.append(_name);
            _builder.append("_");
            String _get = configMap.get(config);
            _builder.append(_get);
            _builder.append("_file_data [");
            String _upperCase = input.getName().toUpperCase();
            _builder.append(_upperCase);
            _builder.append("_");
            String _upperCase_1 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_1);
            _builder.append("_SIZE-1:0];");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("integer ");
        String _name_1 = input.getName();
        _builder.append(_name_1);
        _builder.append("_i = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    {
      EList<Port> _outputs = this.network.getOutputs();
      for(final Port output : _outputs) {
        {
          Set<String> _keySet_2 = this.protocolManager.getLastModCommSignals().keySet();
          for(final String commSigId_1 : _keySet_2) {
            {
              boolean _isOutputSide = this.protocolManager.isOutputSide(this.protocolManager.getLastMod(), commSigId_1);
              if (_isOutputSide) {
                String _printModCommSigKind_1 = this.printModCommSigKind(this.protocolManager.getLastMod(), commSigId_1);
                _builder.append(_printModCommSigKind_1);
                _builder.append(" ");
                String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getLastMod(), null, commSigId_1, output);
                _builder.append(_commSigPrintRange_1);
                String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                _builder.append(_sigPrintName_1);
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        {
          Set<Integer> _keySet_3 = configMap.keySet();
          for(final Integer config_1 : _keySet_3) {
            _builder.append("reg [");
            int _sizeInBits_1 = output.getType().getSizeInBits();
            int _minus_1 = (_sizeInBits_1 - 1);
            _builder.append(_minus_1);
            _builder.append(":0] ");
            String _name_2 = output.getName();
            _builder.append(_name_2);
            _builder.append("_");
            String _get_1 = configMap.get(config_1);
            _builder.append(_get_1);
            _builder.append("_file_data [");
            String _upperCase_2 = output.getName().toUpperCase();
            _builder.append(_upperCase_2);
            _builder.append("_");
            String _upperCase_3 = configMap.get(config_1).toUpperCase();
            _builder.append(_upperCase_3);
            _builder.append("_SIZE-1:0];");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("integer ");
        String _name_3 = output.getName();
        _builder.append(_name_3);
        _builder.append("_i = 0;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    {
      EList<Var> _parameters = this.network.getParameters();
      for(final Var netParm : _parameters) {
        _builder.append("reg ");
        {
          int _sizeInBits_2 = netParm.getType().getSizeInBits();
          boolean _notEquals = (_sizeInBits_2 != 1);
          if (_notEquals) {
            _builder.append("[");
            int _sizeInBits_3 = netParm.getType().getSizeInBits();
            int _minus_2 = (_sizeInBits_3 - 1);
            _builder.append(_minus_2);
            _builder.append(":0] ");
          }
        }
        String _name_4 = netParm.getName();
        _builder.append(_name_4);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("reg [7:0] ID;");
    _builder.newLine();
    _builder.newLine();
    {
      Set<String> _keySet_4 = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId : _keySet_4) {
        String _printNetSysSigKind = this.printNetSysSigKind(sysSigId);
        _builder.append(_printNetSysSigKind);
        _builder.append(" ");
        String _sysSigPrintRange = this.protocolManager.getSysSigPrintRange(null, sysSigId);
        _builder.append(_sysSigPrintRange);
        String _get_2 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
        _builder.append(_get_2);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  /**
   * read data files to initialize I/O
   */
  public CharSequence readDataFiles(final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<Integer> _keySet = configMap.keySet();
      for(final Integer config : _keySet) {
        {
          EList<Port> _inputs = this.network.getInputs();
          for(final Port input : _inputs) {
            _builder.append("initial");
            _builder.newLine();
            _builder.append(" \t");
            _builder.append("$readmemh(");
            String _upperCase = input.getName().toUpperCase();
            _builder.append(_upperCase, " \t");
            _builder.append("_");
            String _upperCase_1 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_1, " \t");
            _builder.append("_FILE, ");
            String _name = input.getName();
            _builder.append(_name, " \t");
            _builder.append("_");
            String _get = configMap.get(config);
            _builder.append(_get, " \t");
            _builder.append("_file_data);");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          EList<Port> _outputs = this.network.getOutputs();
          for(final Port output : _outputs) {
            _builder.append("initial");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("$readmemh(");
            String _upperCase_2 = output.getName().toUpperCase();
            _builder.append(_upperCase_2, "\t");
            _builder.append("_");
            String _upperCase_3 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_3, "\t");
            _builder.append("_FILE, ");
            String _name_1 = output.getName();
            _builder.append(_name_1, "\t");
            _builder.append("_");
            String _get_1 = configMap.get(config);
            _builder.append(_get_1, "\t");
            _builder.append("_file_data);");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print top module interface.
   */
  public CharSequence printDUT(final List<SboxLut> luts) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("multi_dataflow ");
    {
      boolean _isEmpty = this.network.getVariables().isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append(" # (");
        _builder.newLineIfNotEmpty();
        {
          EList<Var> _variables = this.network.getVariables();
          boolean _hasElements = false;
          for(final Var netVar : _variables) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder.appendImmediate(",", "\t");
            }
            _builder.append("\t");
            _builder.append(".");
            String _name = netVar.getName();
            _builder.append(_name, "\t");
            _builder.append("(");
            String _name_1 = netVar.getName();
            _builder.append(_name_1, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append(") ");
      }
    }
    _builder.append("dut (");
    _builder.newLineIfNotEmpty();
    {
      EList<Port> _inputs = this.network.getInputs();
      for(final Port input : _inputs) {
        {
          Set<String> _keySet = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
          for(final String commSigId : _keySet) {
            {
              boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId);
              if (_isInputSide) {
                _builder.append("\t");
                _builder.append(".");
                String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                _builder.append(_sigPrintName, "\t");
                _builder.append("(");
                String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                _builder.append(_sigPrintName_1, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("\t");
        _builder.newLine();
      }
    }
    {
      EList<Port> _outputs = this.network.getOutputs();
      for(final Port output : _outputs) {
        {
          Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
          for(final String commSigId_1 : _keySet_1) {
            {
              boolean _isOutputSide = this.protocolManager.isOutputSide(this.protocolManager.getLastMod(), commSigId_1);
              if (_isOutputSide) {
                _builder.append("\t");
                _builder.append(".");
                String _sigPrintName_2 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                _builder.append(_sigPrintName_2, "\t");
                _builder.append("(");
                String _sigPrintName_3 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                _builder.append(_sigPrintName_3, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      EList<Var> _parameters = this.network.getParameters();
      for(final Var netParm : _parameters) {
        _builder.append("\t");
        _builder.append(".");
        String _name_2 = netParm.getName();
        _builder.append(_name_2, "\t");
        _builder.append("(");
        String _name_3 = netParm.getName();
        _builder.append(_name_3, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      boolean _isEmpty_1 = luts.isEmpty();
      boolean _not_1 = (!_isEmpty_1);
      if (_not_1) {
        _builder.append("\t");
        _builder.append(".ID(ID),");
        _builder.newLine();
      }
    }
    _builder.append("\t\t\t");
    _builder.newLine();
    {
      Set<String> _keySet_2 = this.protocolManager.getNetSysSignals().keySet();
      boolean _hasElements_1 = false;
      for(final String sysSigId : _keySet_2) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(",", "\t");
        }
        _builder.append("\t");
        _builder.append(".");
        String _get = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
        _builder.append(_get, "\t");
        _builder.append("(");
        String _get_1 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
        _builder.append(_get_1, "\t");
        _builder.append(")");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(");\t");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Print test bench clocks behavior.
   */
  public CharSequence printClocks() {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<String> _keySet = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId : _keySet) {
        {
          boolean _containsKey = this.protocolManager.getNetSysSignals().get(sysSigId).containsKey(ProtocolManager.CLOCK);
          if (_containsKey) {
            _builder.append("always #(");
            String _upperCase = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP).toUpperCase();
            _builder.append(_upperCase);
            _builder.append("_PERIOD/2)");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            String _get = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get, "\t");
            _builder.append(" = ~");
            String _get_1 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get_1, "\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * print signals initialization and behavior
   */
  public CharSequence printInitial(final List<SboxLut> luts, final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("initial");
    _builder.newLine();
    _builder.append("begin");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// feeding flag initialization");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("start_feeding = 0;");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      boolean _isEmpty = luts.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("\t");
        _builder.append("// network configuration");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("ID = 8\'d0;");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      boolean _isEmpty_1 = this.network.getParameters().isEmpty();
      boolean _not_1 = (!_isEmpty_1);
      if (_not_1) {
        _builder.append("\t");
        _builder.append("// dynamic parameters initialization");
        _builder.newLine();
        {
          EList<Var> _parameters = this.network.getParameters();
          for(final Var netParm : _parameters) {
            String _name = netParm.getName();
            _builder.append(_name);
            _builder.append(" = 0;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// clocks initialization");
    _builder.newLine();
    {
      Set<String> _keySet = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId : _keySet) {
        {
          boolean _containsKey = this.protocolManager.getNetSysSignals().get(sysSigId).containsKey(ProtocolManager.CLOCK);
          if (_containsKey) {
            _builder.append("\t\t");
            String _get = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get);
            _builder.append(" = 0;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// network signals initialization");
    _builder.newLine();
    {
      EList<Port> _inputs = this.network.getInputs();
      for(final Port input : _inputs) {
        {
          Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
          for(final String commSigId : _keySet_1) {
            {
              boolean _isInputSideDirect = this.protocolManager.isInputSideDirect(this.protocolManager.getFirstMod(), commSigId);
              if (_isInputSideDirect) {
                _builder.append("\t\t\t");
                {
                  boolean _equals = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH)).equals("data");
                  if (_equals) {
                    String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                    _builder.append(_sigPrintName, "\t\t\t");
                    _builder.append(" = 0;");
                    _builder.newLineIfNotEmpty();
                  } else {
                    _builder.append("\t\t\t");
                    String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                    _builder.append(_sigPrintName_1, "\t\t\t");
                    _builder.append("  = 1\'b");
                    {
                      boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
                      if (_isNegMatchingWrapMapping) {
                        _builder.append("1");
                      } else {
                        _builder.append("0");
                      }
                    }
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
          }
        }
      }
    }
    {
      EList<Port> _outputs = this.network.getOutputs();
      for(final Port output : _outputs) {
        {
          Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
          for(final String commSigId_1 : _keySet_2) {
            {
              boolean _isOutputSideReverse = this.protocolManager.isOutputSideReverse(this.protocolManager.getLastMod(), commSigId_1);
              if (_isOutputSideReverse) {
                _builder.append("\t\t\t");
                String _sigPrintName_2 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                _builder.append(_sigPrintName_2, "\t\t\t");
                _builder.append(" = 1\'b");
                {
                  boolean _isNegMatchingWrapMapping_1 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
                  if (_isNegMatchingWrapMapping_1) {
                    _builder.append("1");
                  } else {
                    _builder.append("0");
                  }
                }
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// initial reset");
    _builder.newLine();
    {
      Set<String> _keySet_3 = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId_1 : _keySet_3) {
        {
          if ((this.protocolManager.getNetSysSignals().get(sysSigId_1).containsKey(ProtocolManager.RST) || this.protocolManager.getNetSysSignals().get(sysSigId_1).containsKey(ProtocolManager.RSTN))) {
            _builder.append("\t\t\t");
            String _get_1 = this.protocolManager.getNetSysSignals().get(sysSigId_1).get(ProtocolManager.NETP);
            _builder.append(_get_1, "\t\t\t");
            _builder.append(" = ");
            {
              boolean _containsKey_1 = this.protocolManager.getNetSysSignals().get(sysSigId_1).containsKey(ProtocolManager.RST);
              if (_containsKey_1) {
                _builder.append("0");
              } else {
                _builder.append("1");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("#2");
    _builder.newLine();
    {
      Set<String> _keySet_4 = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId_2 : _keySet_4) {
        {
          if ((this.protocolManager.getNetSysSignals().get(sysSigId_2).containsKey(ProtocolManager.RST) || this.protocolManager.getNetSysSignals().get(sysSigId_2).containsKey(ProtocolManager.RSTN))) {
            _builder.append("\t\t\t");
            String _get_2 = this.protocolManager.getNetSysSignals().get(sysSigId_2).get(ProtocolManager.NETP);
            _builder.append(_get_2, "\t\t\t");
            _builder.append(" = ");
            {
              boolean _containsKey_2 = this.protocolManager.getNetSysSignals().get(sysSigId_2).containsKey(ProtocolManager.RST);
              if (_containsKey_2) {
                _builder.append("1");
              } else {
                _builder.append("0");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("#100");
    _builder.newLine();
    {
      Set<String> _keySet_5 = this.protocolManager.getNetSysSignals().keySet();
      for(final String sysSigId_3 : _keySet_5) {
        {
          if ((this.protocolManager.getNetSysSignals().get(sysSigId_3).containsKey(ProtocolManager.RST) || this.protocolManager.getNetSysSignals().get(sysSigId_3).containsKey(ProtocolManager.RSTN))) {
            _builder.append("\t\t\t");
            String _get_3 = this.protocolManager.getNetSysSignals().get(sysSigId_3).get(ProtocolManager.NETP);
            _builder.append(_get_3, "\t\t\t");
            _builder.append(" = ");
            {
              boolean _containsKey_3 = this.protocolManager.getNetSysSignals().get(sysSigId_3).containsKey(ProtocolManager.RST);
              if (_containsKey_3) {
                _builder.append("0");
              } else {
                _builder.append("1");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("#100");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// network inputs (output side)");
    _builder.newLine();
    {
      EList<Port> _outputs_1 = this.network.getOutputs();
      for(final Port output_1 : _outputs_1) {
        {
          Set<String> _keySet_6 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
          for(final String commSigId_2 : _keySet_6) {
            {
              boolean _isOutputSideReverse_1 = this.protocolManager.isOutputSideReverse(this.protocolManager.getLastMod(), commSigId_2);
              if (_isOutputSideReverse_1) {
                _builder.append("\t\t\t");
                String _sigPrintName_3 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_2, output_1);
                _builder.append(_sigPrintName_3, "\t\t\t");
                _builder.append(" = 1\'b");
                {
                  boolean _isNegMatchingWrapMapping_2 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_2).get(ProtocolManager.CH));
                  if (_isNegMatchingWrapMapping_2) {
                    _builder.append("1");
                  } else {
                    _builder.append("0");
                  }
                }
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.append("\t\t\t");
    _builder.newLine();
    {
      Set<Integer> _keySet_7 = configMap.keySet();
      for(final Integer config : _keySet_7) {
        _builder.append("\t \t\t");
        _builder.append("// executing ");
        String _get_4 = configMap.get(config);
        _builder.append(_get_4, "\t \t\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t \t\t");
        _builder.append("ID = 8\'d");
        _builder.append(config, "\t \t\t");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("start_feeding = 1;");
        _builder.newLine();
        {
          EList<Port> _inputs_1 = this.network.getInputs();
          for(final Port input_1 : _inputs_1) {
            _builder.append("while(");
            String _name_1 = input_1.getName();
            _builder.append(_name_1);
            _builder.append("_i != ");
            String _upperCase = input_1.getName().toUpperCase();
            _builder.append(_upperCase);
            _builder.append("_");
            String _upperCase_1 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_1);
            _builder.append("_SIZE)");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("#10;");
            _builder.newLine();
          }
        }
        _builder.append("start_feeding = 0;");
        _builder.newLine();
        {
          EList<Port> _inputs_2 = this.network.getInputs();
          for(final Port input_2 : _inputs_2) {
            {
              Set<String> _keySet_8 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_3 : _keySet_8) {
                {
                  boolean _isInputSideDirect_1 = this.protocolManager.isInputSideDirect(this.protocolManager.getFirstMod(), commSigId_3);
                  if (_isInputSideDirect_1) {
                    {
                      boolean _equals_1 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_3).get(ProtocolManager.CH)).equals("data");
                      if (_equals_1) {
                        String _sigPrintName_4 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_3, input_2);
                        _builder.append(_sigPrintName_4);
                        _builder.append(" = 0;");
                        _builder.newLineIfNotEmpty();
                      } else {
                        String _sigPrintName_5 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_3, input_2);
                        _builder.append(_sigPrintName_5);
                        _builder.append("  = 1\'b");
                        {
                          boolean _isNegMatchingWrapMapping_3 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_3).get(ProtocolManager.CH));
                          if (_isNegMatchingWrapMapping_3) {
                            _builder.append("1");
                          } else {
                            _builder.append("0");
                          }
                        }
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            String _name_2 = input_2.getName();
            _builder.append(_name_2);
            _builder.append("_i = 0;");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("#1000");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$stop;");
    _builder.newLine();
    _builder.append("end");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printInputFeeding(final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<Integer> _keySet = configMap.keySet();
      for(final Integer config : _keySet) {
        {
          EList<Port> _inputs = this.network.getInputs();
          for(final Port input : _inputs) {
            _builder.append("always@(*)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("if(start_feeding && ID == ");
            _builder.append(config, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append(" \t\t\t");
            _builder.append("begin");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.append("while(");
            String _name = input.getName();
            _builder.append(_name, "\t\t");
            _builder.append("_i < ");
            String _upperCase = input.getName().toUpperCase();
            _builder.append(_upperCase, "\t\t");
            _builder.append("_");
            String _upperCase_1 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_1, "\t\t");
            _builder.append("_SIZE)");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t");
            _builder.append("begin");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("#10");
            _builder.newLine();
            {
              Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId : _keySet_1) {
                {
                  boolean _equals = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH)).equals("full");
                  if (_equals) {
                    _builder.append("\t\t \t\t\t");
                    _builder.append("if(");
                    String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                    _builder.append(_sigPrintName, "\t\t \t\t\t");
                    _builder.append(" == ");
                    {
                      boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
                      if (_isNegMatchingWrapMapping) {
                        _builder.append("1");
                      } else {
                        _builder.append("0");
                      }
                    }
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t\t \t\t\t");
                    _builder.append("begin");
                    _builder.newLine();
                  }
                }
              }
            }
            {
              Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_1 : _keySet_2) {
                {
                  boolean _isInputSideDirect = this.protocolManager.isInputSideDirect(this.protocolManager.getFirstMod(), commSigId_1);
                  if (_isInputSideDirect) {
                    {
                      boolean _equals_1 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_1).get(ProtocolManager.CH)).equals("data");
                      if (_equals_1) {
                        _builder.append("\t\t\t\t\t\t");
                        String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_1, input);
                        _builder.append(_sigPrintName_1, "\t\t\t\t\t\t");
                        _builder.append(" = ");
                        String _name_1 = input.getName();
                        _builder.append(_name_1, "\t\t\t\t\t\t");
                        _builder.append("_");
                        String _get = configMap.get(config);
                        _builder.append(_get, "\t\t\t\t\t\t");
                        _builder.append("_file_data[");
                        String _name_2 = input.getName();
                        _builder.append(_name_2, "\t\t\t\t\t\t");
                        _builder.append("_i];");
                        _builder.newLineIfNotEmpty();
                      } else {
                        _builder.append("\t\t\t\t\t\t");
                        String _sigPrintName_2 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_1, input);
                        _builder.append(_sigPrintName_2, "\t\t\t\t\t\t");
                        _builder.append("  = 1\'b");
                        {
                          boolean _isNegMatchingWrapMapping_1 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
                          if (_isNegMatchingWrapMapping_1) {
                            _builder.append("0");
                          } else {
                            _builder.append("1");
                          }
                        }
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            _builder.append("\t\t\t\t");
            String _name_3 = input.getName();
            _builder.append(_name_3, "\t\t\t\t");
            _builder.append("_i = ");
            String _name_4 = input.getName();
            _builder.append(_name_4, "\t\t\t\t");
            _builder.append("_i + 1;");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t");
            _builder.append("end");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("else");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("begin");
            _builder.newLine();
            {
              Set<String> _keySet_3 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_2 : _keySet_3) {
                {
                  boolean _isInputSideDirect_1 = this.protocolManager.isInputSideDirect(this.protocolManager.getFirstMod(), commSigId_2);
                  if (_isInputSideDirect_1) {
                    {
                      boolean _equals_2 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_2).get(ProtocolManager.CH)).equals("data");
                      if (_equals_2) {
                        _builder.append("\t\t\t\t\t\t");
                        String _sigPrintName_3 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_2, input);
                        _builder.append(_sigPrintName_3, "\t\t\t\t\t\t");
                        _builder.append(" = 0;");
                        _builder.newLineIfNotEmpty();
                      } else {
                        _builder.append("\t\t\t\t\t\t");
                        String _sigPrintName_4 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_2, input);
                        _builder.append(_sigPrintName_4, "\t\t\t\t\t\t");
                        _builder.append("  = 1\'b");
                        {
                          boolean _isNegMatchingWrapMapping_2 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_2).get(ProtocolManager.CH));
                          if (_isNegMatchingWrapMapping_2) {
                            _builder.append("1");
                          } else {
                            _builder.append("0");
                          }
                        }
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            _builder.append("\t\t\t");
            _builder.append("end");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.append("end");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.append("#10");
            _builder.newLine();
            {
              Set<String> _keySet_4 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_3 : _keySet_4) {
                {
                  boolean _isInputSideDirect_2 = this.protocolManager.isInputSideDirect(this.protocolManager.getFirstMod(), commSigId_3);
                  if (_isInputSideDirect_2) {
                    {
                      boolean _equals_3 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_3).get(ProtocolManager.CH)).equals("data");
                      if (_equals_3) {
                        _builder.append("\t\t\t\t");
                        String _sigPrintName_5 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_3, input);
                        _builder.append(_sigPrintName_5, "\t\t\t\t");
                        _builder.append(" = 0;");
                        _builder.newLineIfNotEmpty();
                      } else {
                        _builder.append("\t\t\t\t");
                        String _sigPrintName_6 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_3, input);
                        _builder.append(_sigPrintName_6, "\t\t\t\t");
                        _builder.append("  = 1\'b");
                        {
                          boolean _isNegMatchingWrapMapping_3 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId_3).get(ProtocolManager.CH));
                          if (_isNegMatchingWrapMapping_3) {
                            _builder.append("1");
                          } else {
                            _builder.append("0");
                          }
                        }
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            _builder.append("\t\t\t");
            _builder.append("end");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * print output check logic
   */
  public CharSequence printOutputCheck(final Map<Integer, String> configMap) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<Integer> _keySet = configMap.keySet();
      for(final Integer config : _keySet) {
        {
          EList<Port> _outputs = this.network.getOutputs();
          for(final Port output : _outputs) {
            _builder.append("always@(posedge ");
            {
              Set<String> _keySet_1 = this.protocolManager.getNetSysSignals().keySet();
              for(final String sysSigId : _keySet_1) {
                {
                  boolean _containsKey = this.protocolManager.getNetSysSignals().get(sysSigId).containsKey(ProtocolManager.CLOCK);
                  if (_containsKey) {
                    String _get = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
                    _builder.append(_get);
                  }
                }
              }
            }
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t");
            _builder.append("if(ID == ");
            _builder.append(config, "\t\t\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t");
            _builder.append("begin");
            _builder.newLine();
            {
              Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
              for(final String commSigId : _keySet_2) {
                _builder.append("\t\t\t\t");
                {
                  boolean _equals = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId).get(ProtocolManager.CH)).equals("push");
                  if (_equals) {
                    _builder.append("if(");
                    String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId, output);
                    _builder.append(_sigPrintName, "\t\t\t\t");
                    _builder.append(" == ");
                    {
                      boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId).get(ProtocolManager.CH));
                      if (_isNegMatchingWrapMapping) {
                        _builder.append("0");
                      } else {
                        _builder.append("1");
                      }
                    }
                    _builder.append(")");
                  }
                }
                _builder.newLineIfNotEmpty();
              }
            }
            {
              Set<String> _keySet_3 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
              for(final String commSigId_1 : _keySet_3) {
                {
                  boolean _isOutputSideDirect = this.protocolManager.isOutputSideDirect(this.protocolManager.getLastMod(), commSigId_1);
                  if (_isOutputSideDirect) {
                    _builder.append("\t\t\t\t");
                    {
                      boolean _equals_1 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH)).equals("data");
                      if (_equals_1) {
                        _builder.append("\tbegin\t");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t");
                        _builder.append("\t");
                        _builder.append("if(");
                        String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                        _builder.append(_sigPrintName_1, "\t\t\t\t\t");
                        _builder.append(" != ");
                        String _name = output.getName();
                        _builder.append(_name, "\t\t\t\t\t");
                        _builder.append("_");
                        String _get_1 = configMap.get(config);
                        _builder.append(_get_1, "\t\t\t\t\t");
                        _builder.append("_file_data[");
                        String _name_1 = output.getName();
                        _builder.append(_name_1, "\t\t\t\t\t");
                        _builder.append("_i])");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t");
                        _builder.append("\t\t");
                        _builder.append("$display(\"Error for config %d on output %d: obtained %d, expected %d\", ");
                        _builder.append(config, "\t\t\t\t\t\t");
                        _builder.append(", ");
                        String _name_2 = output.getName();
                        _builder.append(_name_2, "\t\t\t\t\t\t");
                        _builder.append("_i, ");
                        String _sigPrintName_2 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                        _builder.append(_sigPrintName_2, "\t\t\t\t\t\t");
                        _builder.append(", ");
                        String _name_3 = output.getName();
                        _builder.append(_name_3, "\t\t\t\t\t\t");
                        _builder.append("_");
                        String _get_2 = configMap.get(config);
                        _builder.append(_get_2, "\t\t\t\t\t\t");
                        _builder.append("_file_data[");
                        String _name_4 = output.getName();
                        _builder.append(_name_4, "\t\t\t\t\t\t");
                        _builder.append("_i]);");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t");
                        _builder.append("\t");
                        String _name_5 = output.getName();
                        _builder.append(_name_5, "\t\t\t\t\t");
                        _builder.append("_i = ");
                        String _name_6 = output.getName();
                        _builder.append(_name_6, "\t\t\t\t\t");
                        _builder.append("_i + 1;");
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t\t\t\t");
                        _builder.append("\t");
                        _builder.append("end");
                        _builder.newLine();
                      }
                    }
                  }
                }
              }
            }
            _builder.append("\t\t\t\t");
            _builder.append("if(");
            String _name_7 = output.getName();
            _builder.append(_name_7, "\t\t\t\t");
            _builder.append("_i == ");
            String _upperCase = output.getName().toUpperCase();
            _builder.append(_upperCase, "\t\t\t\t");
            _builder.append("_");
            String _upperCase_1 = configMap.get(config).toUpperCase();
            _builder.append(_upperCase_1, "\t\t\t\t");
            _builder.append("_SIZE)");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t\t");
            String _name_8 = output.getName();
            _builder.append(_name_8, "\t\t\t\t\t");
            _builder.append("_i = 0;");
            _builder.newLineIfNotEmpty();
            _builder.append("\t\t\t\t");
            _builder.append("end");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the top module of the merged network.
   * 
   * <ul>
   * <li> headerComments()
   * <li> printInterface()
   * <li> printInternalSignals()
   * <li> printConfig()
   * <li> printAssignments()
   * </ul>
   * According with user options, also the following can be run.
   * <ul>
   * <li> printActors()
   * <li> printEnableGenerator()
   * <li> printPowerController()
   * 
   * </ul>
   */
  public CharSequence printTestBench(final Network network, final List<SboxLut> luts, final ProtocolManager protocolManager, final Map<Integer, String> configMap) {
    CharSequence _xblockexpression = null;
    {
      this.network = network;
      this.protocolManager = protocolManager;
      ExpressionEvaluator _expressionEvaluator = new ExpressionEvaluator();
      this.evaluator = _expressionEvaluator;
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _printTimeScale = this.printTimeScale();
      _builder.append(_printTimeScale);
      _builder.newLineIfNotEmpty();
      CharSequence _headerComments = this.headerComments();
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("module tb_multi_dataflow;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// test bench parameters");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printParameters = this.printParameters(configMap);
      _builder.append(_printParameters, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// multi_dataflow signals");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printSignals = this.printSignals(luts, configMap);
      _builder.append(_printSignals, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// network input and output files");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _readDataFiles = this.readDataFiles(configMap);
      _builder.append(_readDataFiles, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// dut");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printDUT = this.printDUT(luts);
      _builder.append(_printDUT, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// clocks");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printClocks = this.printClocks();
      _builder.append(_printClocks, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// signals evolution");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printInitial = this.printInitial(luts, configMap);
      _builder.append(_printInitial, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// input feeding");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printInputFeeding = this.printInputFeeding(configMap);
      _builder.append(_printInputFeeding, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// output check");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      CharSequence _printOutputCheck = this.printOutputCheck(configMap);
      _builder.append(_printOutputCheck, "\t");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
}
