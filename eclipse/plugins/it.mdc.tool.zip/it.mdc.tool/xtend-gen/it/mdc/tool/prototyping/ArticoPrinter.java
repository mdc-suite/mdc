package it.mdc.tool.prototyping;

import it.mdc.tool.core.platformComposer.ProtocolManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Printer for ARTICo3 Compliant Kernel
 * 
 * @author Tiziana Fanni
 * 
 * TODO
 * make reset parametric depending on polarity
 * .«resetSignal»(«IF getResetSysSignals().get(resetSignal).equals("LOW")»!«ENDIF»reset),
 */
@SuppressWarnings("all")
public class ArticoPrinter extends WrapperPrinter {
  private Map<Port, Integer> inputMap;
  
  private Map<Port, Integer> outputMap;
  
  private Map<Port, Integer> portMap;
  
  private List<Integer> signals;
  
  private int portSize;
  
  private int dataSize = 32;
  
  private Map<String, List<Port>> netPorts;
  
  private boolean enableMonitoring;
  
  private Map<String, Map<String, String>> netSysSignals;
  
  private Map<String, Map<String, Map<String, String>>> modCommSignals;
  
  private Map<String, Map<String, String>> wrapCommSignals;
  
  private List<String> monList;
  
  @Override
  public void computeNetsPorts(final Map<String, Map<String, String>> networkVertexMap) {
    HashMap<String, List<Port>> _hashMap = new HashMap<String, List<Port>>();
    this.netPorts = _hashMap;
    Set<String> _keySet = networkVertexMap.keySet();
    for (final String net : _keySet) {
      List<Integer> _sort = IterableExtensions.<Integer>sort(this.portMap.values());
      for (final int id : _sort) {
        Set<Port> _keySet_1 = this.portMap.keySet();
        for (final Port port : _keySet_1) {
          boolean _equals = this.portMap.get(port).equals(Integer.valueOf(id));
          if (_equals) {
            boolean _contains = networkVertexMap.get(net).values().contains(port.getName());
            if (_contains) {
              boolean _containsKey = this.netPorts.containsKey(net);
              if (_containsKey) {
                this.netPorts.get(net).add(port);
              } else {
                List<Port> ports = new ArrayList<Port>();
                ports.add(port);
                this.netPorts.put(net, ports);
              }
            }
          }
        }
      }
    }
  }
  
  @Override
  public int computeSizePointer() {
    if (this.enableMonitoring) {
      int _size = this.portMap.size();
      int _size_1 = this.monList.size();
      int _plus = (_size + _size_1);
      double _log10 = Math.log10(_plus);
      double _log10_1 = Math.log10(2);
      double _divide = (_log10 / _log10_1);
      double _plus_1 = (_divide + 0.5);
      return Math.round(((float) _plus_1));
    } else {
      double _log10_2 = Math.log10(this.portMap.size());
      double _log10_3 = Math.log10(2);
      double _divide_1 = (_log10_2 / _log10_3);
      double _plus_2 = (_divide_1 + 0.5);
      return Math.round(((float) _plus_2));
    }
  }
  
  @Override
  public String getLongId(final int id) {
    if ((id < 10)) {
      String _string = Integer.valueOf(id).toString();
      return ("0" + _string);
    } else {
      return Integer.valueOf(id).toString();
    }
  }
  
  @Override
  public int mapInOut(final Network network) {
    int _xblockexpression = (int) 0;
    {
      int index = 0;
      int size = 0;
      HashMap<Port, Integer> _hashMap = new HashMap<Port, Integer>();
      this.inputMap = _hashMap;
      HashMap<Port, Integer> _hashMap_1 = new HashMap<Port, Integer>();
      this.outputMap = _hashMap_1;
      HashMap<Port, Integer> _hashMap_2 = new HashMap<Port, Integer>();
      this.portMap = _hashMap_2;
      EList<Port> _inputs = network.getInputs();
      for (final Port input : _inputs) {
        {
          this.inputMap.put(input, Integer.valueOf(index));
          this.portMap.put(input, Integer.valueOf(index));
          index = (index + 1);
        }
      }
      index = 0;
      EList<Port> _outputs = network.getOutputs();
      for (final Port output : _outputs) {
        {
          this.outputMap.put(output, Integer.valueOf(index));
          int _size = this.inputMap.size();
          int _plus = (index + _size);
          this.portMap.put(output, Integer.valueOf(_plus));
          index = (index + 1);
        }
      }
      size = Math.max(this.inputMap.size(), this.outputMap.size());
      double _log10 = Math.log10(size);
      double _log10_1 = Math.log10(2);
      double _divide = (_log10 / _log10_1);
      double _plus = (_divide + 0.5);
      _xblockexpression = this.portSize = Math.round(((float) _plus));
    }
    return _xblockexpression;
  }
  
  @Override
  public void mapSignals() {
    int size = Math.max(this.inputMap.size(), this.outputMap.size());
    int index = 1;
    ArrayList<Integer> _arrayList = new ArrayList<Integer>(size);
    this.signals = _arrayList;
    while ((index <= size)) {
      {
        this.signals.add((index - 1), Integer.valueOf(index));
        index = (index + 1);
      }
    }
  }
  
  @Override
  public Map<Port, Integer> getPortMap() {
    return this.portMap;
  }
  
  @Override
  public Map<Port, Integer> getInputMap() {
    return this.inputMap;
  }
  
  @Override
  public Map<Port, Integer> getOutputMap() {
    return this.outputMap;
  }
  
  public List<String> initArticoPrinter(final Boolean enableMonitoring, final List<String> monList, final Map<String, Map<String, String>> netSysSignals, final Map<String, Map<String, Map<String, String>>> modCommSignals, final Map<String, Map<String, String>> wrapCommSignals) {
    List<String> _xblockexpression = null;
    {
      this.netSysSignals = netSysSignals;
      this.modCommSignals = modCommSignals;
      this.wrapCommSignals = wrapCommSignals;
      this.enableMonitoring = (enableMonitoring).booleanValue();
      _xblockexpression = this.monList = monList;
    }
    return _xblockexpression;
  }
  
  @Override
  public CharSequence printTop(final Network network) {
    CharSequence _xblockexpression = null;
    {
      this.mapInOut(network);
      this.mapSignals();
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// This file has been automatically generated by:");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// on ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// More info available at http://sites.unica.it/rpct/");
      _builder.newLine();
      _builder.append("// ");
      _builder.newLine();
      _builder.append("// This is an ARTICo³ Compliant Kernel");
      _builder.newLine();
      _builder.append("// ARTICo³ documentation is available at https://des-cei.github.io/tools/artico3");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("module cgr_accelerator# (");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("parameter integer C_DATA_WIDTH = 32, // Data bus width (for ARTICo³ in Zynq, use 32 bits)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("parameter integer C_ADDR_WIDTH = 16 // Address bus width (for ARTICo³ in Zynq, use 16 bits)");
      _builder.newLine();
      _builder.append(")\t\t");
      _builder.newLine();
      _builder.append("(\t");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Global signals");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input clk,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input reset,");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Control Signals");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire start,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output reg ready,");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Configuration registers\t\t\t\t\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire [C_DATA_WIDTH-1 : 0] reg_0_o,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire reg_0_o_vld,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input [C_DATA_WIDTH-1 : 0] reg_0_i,");
      _builder.newLine();
      _builder.append("\t\t\t");
      _builder.newLine();
      {
        Set<Port> _keySet = this.portMap.keySet();
        for(final Port port : _keySet) {
          _builder.append("\t");
          _builder.append("// ");
          String _name = port.getName();
          _builder.append(_name, "\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire [C_DATA_WIDTH-1 : 0] reg_");
          Integer _get = this.portMap.get(port);
          int _plus = ((_get).intValue() + 1);
          _builder.append(_plus, "\t");
          _builder.append("_o,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire reg_");
          Integer _get_1 = this.portMap.get(port);
          int _plus_1 = ((_get_1).intValue() + 1);
          _builder.append(_plus_1, "\t");
          _builder.append("_o_vld,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("input [C_DATA_WIDTH-1 : 0] reg_");
          Integer _get_2 = this.portMap.get(port);
          int _plus_2 = ((_get_2).intValue() + 1);
          _builder.append(_plus_2, "\t");
          _builder.append("_i,");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          _builder.append("\t");
          _builder.append("// Monitors registers");
          _builder.newLine();
          {
            for(final String monitor : this.monList) {
              _builder.append("\t");
              _builder.append("// ");
              _builder.append(monitor, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("output wire [C_DATA_WIDTH-1 : 0] reg_");
              int _size = this.portMap.keySet().size();
              int _plus_3 = (_size + 1);
              int _indexOf = this.monList.indexOf(monitor);
              int _plus_4 = (_plus_3 + _indexOf);
              _builder.append(_plus_4, "\t");
              _builder.append("_o,");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("output wire reg_");
              int _size_1 = this.portMap.keySet().size();
              int _plus_5 = (_size_1 + 1);
              int _indexOf_1 = this.monList.indexOf(monitor);
              int _plus_6 = (_plus_5 + _indexOf_1);
              _builder.append(_plus_6, "\t");
              _builder.append("_o_vld,");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("input [C_DATA_WIDTH-1 : 0] reg_");
              int _size_2 = this.portMap.keySet().size();
              int _plus_7 = (_size_2 + 1);
              int _indexOf_2 = this.monList.indexOf(monitor);
              int _plus_8 = (_plus_7 + _indexOf_2);
              _builder.append(_plus_8, "\t");
              _builder.append("_i,");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Data memories");
      _builder.newLine();
      {
        Set<Port> _keySet_1 = this.portMap.keySet();
        for(final Port port_1 : _keySet_1) {
          _builder.append("\t");
          _builder.append("// bram_");
          Integer _get_3 = this.portMap.get(port_1);
          _builder.append(_get_3, "\t");
          _builder.append(" (");
          String _name_1 = port_1.getName();
          _builder.append(_name_1, "\t");
          _builder.append(")");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output bram_");
          Integer _get_4 = this.portMap.get(port_1);
          _builder.append(_get_4, "\t");
          _builder.append("_clk,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output bram_");
          Integer _get_5 = this.portMap.get(port_1);
          _builder.append(_get_5, "\t");
          _builder.append("_rst,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire bram_");
          Integer _get_6 = this.portMap.get(port_1);
          _builder.append(_get_6, "\t");
          _builder.append("_en,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire bram_");
          Integer _get_7 = this.portMap.get(port_1);
          _builder.append(_get_7, "\t");
          _builder.append("_we,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire [C_ADDR_WIDTH-1 : 0] bram_");
          Integer _get_8 = this.portMap.get(port_1);
          _builder.append(_get_8, "\t");
          _builder.append("_addr,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("output wire [C_DATA_WIDTH-1 : 0] bram_");
          Integer _get_9 = this.portMap.get(port_1);
          _builder.append(_get_9, "\t");
          _builder.append("_din,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("input wire [C_DATA_WIDTH-1 : 0] bram_");
          Integer _get_10 = this.portMap.get(port_1);
          _builder.append(_get_10, "\t");
          _builder.append("_dout,");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      _builder.append("\t");
      _builder.append("// Data Counter ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input [31 : 0] values);");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Wire(s) and Reg(s)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("wire [C_DATA_WIDTH-1:0] slv_reg0;");
      _builder.newLine();
      {
        Set<Port> _keySet_2 = this.portMap.keySet();
        for(final Port port_2 : _keySet_2) {
          _builder.append("\t");
          _builder.append("wire [C_DATA_WIDTH-1:0] slv_reg");
          Integer _get_11 = this.portMap.get(port_2);
          int _plus_9 = ((_get_11).intValue() + 1);
          _builder.append(_plus_9, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      }
      {
        if (this.enableMonitoring) {
          _builder.append("\t");
          _builder.append("// Monitors registers");
          _builder.newLine();
          {
            for(final String monitor_1 : this.monList) {
              _builder.append("\t");
              _builder.append("wire [C_DATA_WIDTH-1:0] slv_reg");
              int _size_3 = this.portMap.keySet().size();
              int _plus_10 = (_size_3 + 1);
              int _indexOf_3 = this.monList.indexOf(monitor_1);
              int _plus_11 = (_plus_10 + _indexOf_3);
              _builder.append(_plus_11, "\t");
              _builder.append("; // ");
              _builder.append(monitor_1, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("wire done;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("wire done_input;");
      _builder.newLine();
      {
        Set<Port> _keySet_3 = this.inputMap.keySet();
        for(final Port input : _keySet_3) {
          {
            Set<String> _keySet_4 = this.getInFirstModCommSignals().keySet();
            for(final String commSigId : _keySet_4) {
              _builder.append("\t");
              _builder.append("wire ");
              String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId, input);
              _builder.append(_commSigPrintRange, "\t");
              String _name_2 = input.getName();
              _builder.append(_name_2, "\t");
              _builder.append("_");
              String _matchingWrapMapping = this.getMatchingWrapMapping(this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
              _builder.append(_matchingWrapMapping, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.newLine();
        }
      }
      {
        Set<Port> _keySet_5 = this.inputMap.keySet();
        for(final Port input_1 : _keySet_5) {
          _builder.append("\t");
          _builder.append("wire en_");
          String _name_3 = input_1.getName();
          _builder.append(_name_3, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire done_");
          String _name_4 = input_1.getName();
          _builder.append(_name_4, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire last_");
          String _name_5 = input_1.getName();
          _builder.append(_name_5, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_ADDR_WIDTH-1:0] count_");
          String _name_6 = input_1.getName();
          _builder.append(_name_6, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire wren_mem_");
          Integer _get_12 = this.portMap.get(input_1);
          int _plus_12 = ((_get_12).intValue() + 1);
          _builder.append(_plus_12, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire rden_mem_");
          Integer _get_13 = this.portMap.get(input_1);
          int _plus_13 = ((_get_13).intValue() + 1);
          _builder.append(_plus_13, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_ADDR_WIDTH-1:0] address_mem_");
          Integer _get_14 = this.portMap.get(input_1);
          int _plus_14 = ((_get_14).intValue() + 1);
          _builder.append(_plus_14, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_DATA_WIDTH-1:0] data_in_mem_");
          Integer _get_15 = this.portMap.get(input_1);
          int _plus_15 = ((_get_15).intValue() + 1);
          _builder.append(_plus_15, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_DATA_WIDTH-1:0] data_out_mem_");
          Integer _get_16 = this.portMap.get(input_1);
          int _plus_16 = ((_get_16).intValue() + 1);
          _builder.append(_plus_16, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      {
        Set<Port> _keySet_6 = this.outputMap.keySet();
        for(final Port output : _keySet_6) {
          {
            Set<String> _keySet_7 = this.getOutLastModCommSignals().keySet();
            for(final String commSigId_1 : _keySet_7) {
              _builder.append("\t");
              _builder.append("wire ");
              String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getLastMod(), null, commSigId_1, output);
              _builder.append(_commSigPrintRange_1, "\t");
              String _name_7 = output.getName();
              _builder.append(_name_7, "\t");
              _builder.append("_");
              String _matchingWrapMapping_1 = this.getMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
              _builder.append(_matchingWrapMapping_1, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.newLine();
        }
      }
      _builder.append("\t");
      _builder.append("wire done_output;");
      _builder.newLine();
      {
        Set<Port> _keySet_8 = this.outputMap.keySet();
        for(final Port output_1 : _keySet_8) {
          _builder.append("\t");
          _builder.append("wire en_");
          String _name_8 = output_1.getName();
          _builder.append(_name_8, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire done_");
          String _name_9 = output_1.getName();
          _builder.append(_name_9, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire last_");
          String _name_10 = output_1.getName();
          _builder.append(_name_10, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_ADDR_WIDTH-1:0] count_");
          String _name_11 = output_1.getName();
          _builder.append(_name_11, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire rden_mem_");
          Integer _get_17 = this.portMap.get(output_1);
          int _plus_17 = ((_get_17).intValue() + 1);
          _builder.append(_plus_17, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire wren_mem_");
          Integer _get_18 = this.portMap.get(output_1);
          int _plus_18 = ((_get_18).intValue() + 1);
          _builder.append(_plus_18, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_ADDR_WIDTH-1:0] address_mem_");
          Integer _get_19 = this.portMap.get(output_1);
          int _plus_19 = ((_get_19).intValue() + 1);
          _builder.append(_plus_19, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_DATA_WIDTH-1:0] data_in_mem_");
          Integer _get_20 = this.portMap.get(output_1);
          int _plus_20 = ((_get_20).intValue() + 1);
          _builder.append(_plus_20, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("wire [C_DATA_WIDTH-1:0] data_out_mem_");
          Integer _get_21 = this.portMap.get(output_1);
          int _plus_21 = ((_get_21).intValue() + 1);
          _builder.append(_plus_21, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      _builder.append("\t");
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          _builder.append("\t");
          _builder.append("//monitoring");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("wire valid;\t\t");
          _builder.newLine();
          {
            for(final String monitor_2 : this.monList) {
              _builder.append("\t");
              _builder.append("// Monitor ");
              int _indexOf_4 = this.monList.indexOf(monitor_2);
              _builder.append(_indexOf_4, "\t");
              _builder.append(": ");
              _builder.append(monitor_2, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("wire clear_monitor_");
              int _indexOf_5 = this.monList.indexOf(monitor_2);
              _builder.append(_indexOf_5, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("reg [C_DATA_WIDTH-1:0]  ");
              _builder.append(monitor_2, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.newLine();
            }
          }
          {
            boolean _contains = this.monList.contains("count_clock_cycles");
            if (_contains) {
              _builder.append("\t");
              _builder.append("reg en_clock_count;");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("reg state, next_state;  ");
              _builder.newLine();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("// Logic to manage ready signal");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always@(posedge clk or negedge reset)");
      _builder.newLine();
      _builder.append("\t ");
      _builder.append("if(!reset)");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("ready <= 1;");
      _builder.newLine();
      _builder.append("\t ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t   ");
      _builder.append("if(start) ready <= 0;");
      _builder.newLine();
      _builder.append("\t ");
      _builder.append("else if(done) ready <= 1;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          _builder.append("// ----------------------------------------------------------------------------");
          _builder.newLine();
          _builder.append("// Monitoring Logic");
          _builder.newLine();
          _builder.append("// ----------------------------------------------------------------------------");
          _builder.newLine();
          _builder.newLine();
          _builder.append("assign valid = 1\'b1;");
          _builder.newLine();
          _builder.newLine();
          {
            for(final String monitor_3 : this.monList) {
              {
                boolean _contains_1 = monitor_3.contains("count_full_");
                if (_contains_1) {
                  _builder.append("\t");
                  _builder.append("// TO FIX");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("// monitoring total full of  FIFO  ");
                  String _replace = monitor_3.replace("count_full_", "");
                  _builder.append(_replace, "\t");
                  _builder.append("_full");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t");
                  _builder.append("always@(posedge clk or negedge reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t    ");
                  _builder.append("if(!reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append(monitor_3, "\t\t        ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("end ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t    ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("if(clear_monitor_");
                  int _indexOf_6 = this.monList.indexOf(monitor_3);
                  _builder.append(_indexOf_6, "\t\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("else if(");
                  String _replace_1 = monitor_3.replace("count_full_", "");
                  _builder.append(_replace_1, "\t\t        ");
                  _builder.append("_full)");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" + 1;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("else ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("end");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.newLine();
                }
              }
              {
                boolean _equals = monitor_3.equals("count_clock_cycles");
                if (_equals) {
                  _builder.append("\t");
                  _builder.append("// monitoring clock cycles");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t");
                  _builder.append("always@(posedge clk or negedge reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t    ");
                  _builder.append("if(!reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("state <= 0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append(monitor_3, "\t\t        ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("end ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t    ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("state <= next_state;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("if(clear_monitor_");
                  int _indexOf_7 = this.monList.indexOf(monitor_3);
                  _builder.append(_indexOf_7, "\t\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("else if(en_clock_count)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" + 1;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("else ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t            ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t\t            ");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.append("end");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append(" ");
                  _builder.append("// state transitions (to enable monitoring only from start to done signals)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("always@(state or start or done)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("case(state)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("//wait ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("1\'b0: if(start) ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append("next_state = 1\'b1;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append("next_state = 1\'b0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("// count");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("1\'b1: if(done)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append("next_state = 1\'b0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append("next_state = 1\'b1;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("default: next_state = 1\'b0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("endcase ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append(" ");
                  _builder.append("// enabling monitoring");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("always@(state)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("case(state)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("//wait (clock count disabled)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("1\'b0: en_clock_count = 0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("1\'b1: en_clock_count = 1;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("default: en_clock_count = 0;");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("endcase ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("\t        ");
                  _builder.newLine();
                }
              }
              {
                boolean _contains_2 = monitor_3.contains("count_in_tokens_");
                if (_contains_2) {
                  _builder.append("\t");
                  _builder.append("// monitoring input tokens (of port ");
                  String _replace_2 = monitor_3.replace("count_in_tokens_", "");
                  _builder.append(_replace_2, "\t");
                  _builder.append(")\t\t");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("always@(posedge clk or negedge reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("if(!reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append(monitor_3, "\t        ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("end ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("if(clear_monitor_");
                  int _indexOf_8 = this.monList.indexOf(monitor_3);
                  _builder.append(_indexOf_8, "\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else if(rden_mem_");
                  Integer _portIdFromName = this.getPortIdFromName(monitor_3.replace("count_in_tokens_", ""));
                  int _plus_22 = ((_portIdFromName).intValue() + 1);
                  _builder.append(_plus_22, "\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" + 1;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("end");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.newLine();
                }
              }
              {
                boolean _contains_3 = monitor_3.contains("count_out_tokens_");
                if (_contains_3) {
                  _builder.append("\t");
                  _builder.append("// monitoring output tokens (of port ");
                  String _replace_3 = monitor_3.replace("count_out_tokens_", "");
                  _builder.append(_replace_3, "\t");
                  _builder.append(")\t\t");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("always@(posedge clk or negedge reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("if(!reset)");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append(monitor_3, "\t        ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("end ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("    ");
                  _builder.append("else");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("begin");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("if(clear_monitor_");
                  int _indexOf_9 = this.monList.indexOf(monitor_3);
                  _builder.append(_indexOf_9, "\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else if(wren_mem_");
                  Integer _portIdFromName_1 = this.getPortIdFromName(monitor_3.replace("count_out_tokens_", ""));
                  int _plus_23 = ((_portIdFromName_1).intValue() + 1);
                  _builder.append(_plus_23, "\t        ");
                  _builder.append(")");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" + 1;");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("else ");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("            ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(" <= ");
                  _builder.append(monitor_3, "\t            ");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.append("end");
                  _builder.newLine();
                  _builder.append("\t");
                  _builder.append("        ");
                  _builder.newLine();
                }
              }
            }
          }
        }
      }
      _builder.append("\t\t");
      _builder.newLine();
      _builder.append("// Coprocessor Front-End(s)");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      {
        Set<Port> _keySet_9 = this.inputMap.keySet();
        for(final Port input_2 : _keySet_9) {
          _builder.append("\t");
          _builder.append("front_end i_front_end_");
          String _name_12 = input_2.getName();
          _builder.append(_name_12, "\t");
          _builder.append("(");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aclk(clk),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aresetn(reset),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".start(start),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".zero(slv_reg");
          Integer _get_22 = this.portMap.get(input_2);
          int _plus_24 = ((_get_22).intValue() + 1);
          _builder.append(_plus_24, "\t\t");
          _builder.append("[C_ADDR_WIDTH-1:0]=={C_ADDR_WIDTH{1\'b1}}),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".last(last_");
          String _name_13 = input_2.getName();
          _builder.append(_name_13, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".full(");
          {
            boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFullChannelWrapCommSignalID());
            if (_isNegMatchingWrapMapping) {
              _builder.append("!");
            }
          }
          String _name_14 = input_2.getName();
          _builder.append(_name_14, "\t\t");
          _builder.append("_full),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".en(en_");
          String _name_15 = input_2.getName();
          _builder.append(_name_15, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".rden(rden_mem_");
          Integer _get_23 = this.portMap.get(input_2);
          int _plus_25 = ((_get_23).intValue() + 1);
          _builder.append(_plus_25, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".wr(");
          String _name_16 = input_2.getName();
          _builder.append(_name_16, "\t\t");
          _builder.append("_push),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".done(done_");
          String _name_17 = input_2.getName();
          _builder.append(_name_17, "\t\t");
          _builder.append(")\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append(");");
          _builder.newLine();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("counter #(\t\t\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".SIZE(C_ADDR_WIDTH) ) ");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("i_counter_");
          String _name_18 = input_2.getName();
          _builder.append(_name_18, "\t");
          _builder.append(" (");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aclk(clk),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aresetn(reset),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".clr(ready),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".en(en_");
          String _name_19 = input_2.getName();
          _builder.append(_name_19, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".max(slv_reg");
          Integer _get_24 = this.portMap.get(input_2);
          int _plus_26 = ((_get_24).intValue() + 1);
          _builder.append(_plus_26, "\t\t");
          _builder.append("[C_ADDR_WIDTH-1:0]),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".count(count_");
          String _name_20 = input_2.getName();
          _builder.append(_name_20, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".last(last_");
          String _name_21 = input_2.getName();
          _builder.append(_name_21, "\t\t");
          _builder.append(")");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append(");");
          _builder.newLine();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("assign address_mem_");
          Integer _get_25 = this.portMap.get(input_2);
          int _plus_27 = ((_get_25).intValue() + 1);
          _builder.append(_plus_27, "\t");
          _builder.append(" = count_");
          String _name_22 = input_2.getName();
          _builder.append(_name_22, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign wren_mem_");
          Integer _get_26 = this.portMap.get(input_2);
          int _plus_28 = ((_get_26).intValue() + 1);
          _builder.append(_plus_28, "\t");
          _builder.append(" = 1\'b0;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign data_in_mem_");
          Integer _get_27 = this.portMap.get(input_2);
          int _plus_29 = ((_get_27).intValue() + 1);
          _builder.append(_plus_29, "\t");
          _builder.append(" = 32\'b0;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      _builder.append("\t\t\t\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign done_input = ");
      {
        Set<Port> _keySet_10 = this.inputMap.keySet();
        boolean _hasElements = false;
        for(final Port input_3 : _keySet_10) {
          if (!_hasElements) {
            _hasElements = true;
          } else {
            _builder.appendImmediate(" && ", "\t");
          }
          _builder.append("done_");
          String _name_23 = input_3.getName();
          _builder.append(_name_23, "\t");
        }
      }
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// Multi-Dataflow Reconfigurable Datapath");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("multi_dataflow reconf_dpath (");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("// Multi-Dataflow Input(s)");
      _builder.newLine();
      {
        Set<Port> _keySet_11 = this.inputMap.keySet();
        for(final Port input_4 : _keySet_11) {
          {
            Set<String> _keySet_12 = this.getInFirstModCommSignals().keySet();
            for(final String commSigId_2 : _keySet_12) {
              _builder.append("\t\t");
              _builder.append(".");
              String _name_24 = input_4.getName();
              _builder.append(_name_24, "\t\t");
              String _suffix = this.getSuffix(this.getInFirstModCommSignals(), commSigId_2);
              _builder.append(_suffix, "\t\t");
              _builder.append("(");
              String _name_25 = input_4.getName();
              _builder.append(_name_25, "\t\t");
              _builder.append("_");
              String _matchingWrapMapping_2 = this.getMatchingWrapMapping(this.getFirstModCommSignals().get(commSigId_2).get(ProtocolManager.CH));
              _builder.append(_matchingWrapMapping_2, "\t\t");
              _builder.append("),");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t\t");
      _builder.append("// Multi-Dataflow Output(s)");
      _builder.newLine();
      {
        Set<Port> _keySet_13 = this.outputMap.keySet();
        for(final Port output_2 : _keySet_13) {
          {
            Set<String> _keySet_14 = this.getOutLastModCommSignals().keySet();
            for(final String commSigId_3 : _keySet_14) {
              _builder.append("\t\t");
              _builder.append(".");
              String _name_26 = output_2.getName();
              _builder.append(_name_26, "\t\t");
              String _suffix_1 = this.getSuffix(this.getOutLastModCommSignals(), commSigId_3);
              _builder.append(_suffix_1, "\t\t");
              _builder.append("(");
              {
                boolean _isNegMatchingWrapMapping_1 = this.protocolManager.isNegMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_3).get(ProtocolManager.CH));
                if (_isNegMatchingWrapMapping_1) {
                  _builder.append("!");
                }
              }
              String _name_27 = output_2.getName();
              _builder.append(_name_27, "\t\t");
              _builder.append("_");
              String _matchingWrapMapping_3 = this.getMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_3).get(ProtocolManager.CH));
              _builder.append(_matchingWrapMapping_3, "\t\t");
              _builder.append("),");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      {
        List<String> _clockSysSignals = this.getClockSysSignals();
        for(final String clockSignal : _clockSysSignals) {
          _builder.append("\t\t");
          _builder.append(".");
          _builder.append(clockSignal, "\t\t");
          _builder.append("(clk),");
          _builder.newLineIfNotEmpty();
        }
      }
      {
        Set<String> _keySet_15 = this.getResetSysSignals().keySet();
        for(final String resetSignal : _keySet_15) {
          _builder.append("\t\t");
          _builder.append(".");
          _builder.append(resetSignal, "\t\t");
          _builder.append("(reset),");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t\t");
      _builder.append("// Multi-Dataflow Kernel ID");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append(".ID(slv_reg0[31:24])");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(");");
      _builder.newLine();
      _builder.newLine();
      {
        Set<Port> _keySet_16 = this.inputMap.keySet();
        for(final Port input_5 : _keySet_16) {
          _builder.append("\t");
          _builder.append("assign ");
          String _name_28 = input_5.getName();
          _builder.append(_name_28, "\t");
          _builder.append("_data = data_out_mem_");
          Integer _get_28 = this.portMap.get(input_5);
          int _plus_30 = ((_get_28).intValue() + 1);
          _builder.append(_plus_30, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      }
      {
        Set<Port> _keySet_17 = this.outputMap.keySet();
        for(final Port output_3 : _keySet_17) {
          _builder.append("\t");
          _builder.append("assign data_in_mem_");
          Integer _get_29 = this.portMap.get(output_3);
          int _plus_31 = ((_get_29).intValue() + 1);
          _builder.append(_plus_31, "\t");
          _builder.append(" = ");
          String _name_29 = output_3.getName();
          _builder.append(_name_29, "\t");
          _builder.append("_data;");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t\t");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// Coprocessor Back-End(s)");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      {
        Set<Port> _keySet_18 = this.outputMap.keySet();
        for(final Port output_4 : _keySet_18) {
          _builder.append("\t");
          _builder.append("back_end i_back_end_");
          String _name_30 = output_4.getName();
          _builder.append(_name_30, "\t");
          _builder.append("(");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aclk(clk),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aresetn(reset),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".start(start),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".zero(slv_reg");
          Integer _get_30 = this.portMap.get(output_4);
          int _plus_32 = ((_get_30).intValue() + 1);
          _builder.append(_plus_32, "\t\t");
          _builder.append("[C_ADDR_WIDTH-1:0]=={C_ADDR_WIDTH{1\'b1}}),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".last(last_");
          String _name_31 = output_4.getName();
          _builder.append(_name_31, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".wr(");
          String _name_32 = output_4.getName();
          _builder.append(_name_32, "\t\t");
          _builder.append("_push),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".wren(wren_mem_");
          Integer _get_31 = this.portMap.get(output_4);
          int _plus_33 = ((_get_31).intValue() + 1);
          _builder.append(_plus_33, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".en(en_");
          String _name_33 = output_4.getName();
          _builder.append(_name_33, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".full(");
          String _name_34 = output_4.getName();
          _builder.append(_name_34, "\t\t");
          _builder.append("_full),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".done(done_");
          String _name_35 = output_4.getName();
          _builder.append(_name_35, "\t\t");
          _builder.append(")");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append(");");
          _builder.newLine();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("counter #(\t\t\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".SIZE(C_ADDR_WIDTH) )");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("i_counter_");
          String _name_36 = output_4.getName();
          _builder.append(_name_36, "\t");
          _builder.append(" (");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aclk(clk),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".aresetn(reset),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".clr(ready),");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".en(en_");
          String _name_37 = output_4.getName();
          _builder.append(_name_37, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".max(slv_reg");
          Integer _get_32 = this.portMap.get(output_4);
          int _plus_34 = ((_get_32).intValue() + 1);
          _builder.append(_plus_34, "\t\t");
          _builder.append("[C_ADDR_WIDTH-1:0]),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".count(count_");
          String _name_38 = output_4.getName();
          _builder.append(_name_38, "\t\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append(".last(last_");
          String _name_39 = output_4.getName();
          _builder.append(_name_39, "\t\t");
          _builder.append(")");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append(");");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("assign address_mem_");
          Integer _get_33 = this.portMap.get(output_4);
          int _plus_35 = ((_get_33).intValue() + 1);
          _builder.append(_plus_35, "\t");
          _builder.append(" = count_");
          String _name_40 = output_4.getName();
          _builder.append(_name_40, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign rden_mem_");
          Integer _get_34 = this.portMap.get(output_4);
          int _plus_36 = ((_get_34).intValue() + 1);
          _builder.append(_plus_36, "\t");
          _builder.append(" = 1\'b0;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      _builder.append("\t");
      _builder.append("assign done_output = ");
      {
        Set<Port> _keySet_19 = this.outputMap.keySet();
        boolean _hasElements_1 = false;
        for(final Port output_5 : _keySet_19) {
          if (!_hasElements_1) {
            _hasElements_1 = true;
          } else {
            _builder.appendImmediate(" && ", "\t");
          }
          _builder.append("done_");
          String _name_41 = output_5.getName();
          _builder.append(_name_41, "\t");
        }
      }
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("assign done = done_input && done_output;");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.newLine();
      {
        Set<Port> _keySet_20 = this.portMap.keySet();
        for(final Port port_3 : _keySet_20) {
          _builder.append("\t");
          _builder.append("// bram_");
          Integer _get_35 = this.portMap.get(port_3);
          _builder.append(_get_35, "\t");
          _builder.append(" (");
          String _name_42 = port_3.getName();
          _builder.append(_name_42, "\t");
          _builder.append(")");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign bram_");
          Integer _get_36 = this.portMap.get(port_3);
          _builder.append(_get_36, "\t");
          _builder.append("_rst = !reset;");
          _builder.newLineIfNotEmpty();
          {
            boolean _containsKey = this.inputMap.containsKey(port_3);
            if (_containsKey) {
              _builder.append("\t");
              _builder.append("assign bram_");
              Integer _get_37 = this.portMap.get(port_3);
              _builder.append(_get_37, "\t");
              _builder.append("_en = rden_mem_");
              Integer _get_38 = this.portMap.get(port_3);
              int _plus_37 = ((_get_38).intValue() + 1);
              _builder.append(_plus_37, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            } else {
              _builder.append("\t");
              _builder.append("assign bram_");
              Integer _get_39 = this.portMap.get(port_3);
              _builder.append(_get_39, "\t");
              _builder.append("_en = wren_mem_");
              Integer _get_40 = this.portMap.get(port_3);
              int _plus_38 = ((_get_40).intValue() + 1);
              _builder.append(_plus_38, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append("assign bram_");
          Integer _get_41 = this.portMap.get(port_3);
          _builder.append(_get_41, "\t");
          _builder.append("_we = wren_mem_");
          Integer _get_42 = this.portMap.get(port_3);
          int _plus_39 = ((_get_42).intValue() + 1);
          _builder.append(_plus_39, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign bram_");
          Integer _get_43 = this.portMap.get(port_3);
          _builder.append(_get_43, "\t");
          _builder.append("_addr = address_mem_");
          Integer _get_44 = this.portMap.get(port_3);
          int _plus_40 = ((_get_44).intValue() + 1);
          _builder.append(_plus_40, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign bram_");
          Integer _get_45 = this.portMap.get(port_3);
          _builder.append(_get_45, "\t");
          _builder.append("_din = data_in_mem_");
          Integer _get_46 = this.portMap.get(port_3);
          int _plus_41 = ((_get_46).intValue() + 1);
          _builder.append(_plus_41, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign data_out_mem_");
          Integer _get_47 = this.portMap.get(port_3);
          int _plus_42 = ((_get_47).intValue() + 1);
          _builder.append(_plus_42, "\t");
          _builder.append(" = bram_");
          Integer _get_48 = this.portMap.get(port_3);
          _builder.append(_get_48, "\t");
          _builder.append("_dout;");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign slv_reg0 = reg_0_i;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign reg_0_o_vld = 1\'b0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign reg_0_o = {C_DATA_WIDTH{1\'b0}};");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      {
        Set<Port> _keySet_21 = this.portMap.keySet();
        for(final Port port_4 : _keySet_21) {
          _builder.append("\t");
          _builder.append("assign slv_reg");
          Integer _get_49 = this.portMap.get(port_4);
          int _plus_43 = ((_get_49).intValue() + 1);
          _builder.append(_plus_43, "\t");
          _builder.append(" = reg_");
          Integer _get_50 = this.portMap.get(port_4);
          int _plus_44 = ((_get_50).intValue() + 1);
          _builder.append(_plus_44, "\t");
          _builder.append("_i;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign reg_");
          Integer _get_51 = this.portMap.get(port_4);
          int _plus_45 = ((_get_51).intValue() + 1);
          _builder.append(_plus_45, "\t");
          _builder.append("_o_vld = 1\'b0;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("assign reg_");
          Integer _get_52 = this.portMap.get(port_4);
          int _plus_46 = ((_get_52).intValue() + 1);
          _builder.append(_plus_46, "\t");
          _builder.append("_o = {C_DATA_WIDTH{1\'b0}};");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
        }
      }
      {
        if (this.enableMonitoring) {
          _builder.append("\t");
          _builder.append("// Monitors registers");
          _builder.newLine();
          {
            for(final String monitor_4 : this.monList) {
              _builder.append("\t");
              _builder.append("assign slv_reg");
              int _size_4 = this.portMap.keySet().size();
              int _plus_47 = (_size_4 + 1);
              int _indexOf_10 = this.monList.indexOf(monitor_4);
              int _plus_48 = (_plus_47 + _indexOf_10);
              _builder.append(_plus_48, "\t");
              _builder.append(" = reg_");
              int _size_5 = this.portMap.keySet().size();
              int _plus_49 = (_size_5 + 1);
              int _indexOf_11 = this.monList.indexOf(monitor_4);
              int _plus_50 = (_plus_49 + _indexOf_11);
              _builder.append(_plus_50, "\t");
              _builder.append("_i;");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("assign reg_");
              int _size_6 = this.portMap.keySet().size();
              int _plus_51 = (_size_6 + 1);
              int _indexOf_12 = this.monList.indexOf(monitor_4);
              int _plus_52 = (_plus_51 + _indexOf_12);
              _builder.append(_plus_52, "\t");
              _builder.append("_o_vld = valid;");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("assign reg_");
              int _size_7 = this.portMap.keySet().size();
              int _plus_53 = (_size_7 + 1);
              int _indexOf_13 = this.monList.indexOf(monitor_4);
              int _plus_54 = (_plus_53 + _indexOf_13);
              _builder.append(_plus_54, "\t");
              _builder.append("_o = ");
              _builder.append(monitor_4, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("assign clear_monitor_");
              int _indexOf_14 = this.monList.indexOf(monitor_4);
              _builder.append(_indexOf_14, "\t");
              _builder.append(" = reg_");
              int _size_8 = this.portMap.keySet().size();
              int _plus_55 = (_size_8 + 1);
              int _indexOf_15 = this.monList.indexOf(monitor_4);
              int _plus_56 = (_plus_55 + _indexOf_15);
              _builder.append(_plus_56, "\t");
              _builder.append("_i[31];");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.newLine();
            }
          }
        }
      }
      _builder.append("endmodule");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  @Override
  public CharSequence printXML() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    _builder.newLine();
    _builder.append("<mdcInfo>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<baseAddress>0x43C00000</baseAddress>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<nbEvents>");
    int _size = this.monList.size();
    _builder.append(_size, "  ");
    _builder.append("</nbEvents>");
    _builder.newLineIfNotEmpty();
    {
      for(final String monitor : this.monList) {
        _builder.append("  ");
        _builder.append("<event> ");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append("<index>");
        int _size_1 = this.portMap.size();
        int _plus = (_size_1 + 1);
        int _indexOf = this.monList.indexOf(monitor);
        int _plus_1 = (_plus + _indexOf);
        _builder.append(_plus_1, "    ");
        _builder.append("</index>");
        _builder.newLineIfNotEmpty();
        {
          boolean _contains = monitor.contains("count_full_");
          if (_contains) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase = monitor.replace("count_", "").toUpperCase();
            _builder.append(_upperCase, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Total number of FIFO full of input ");
            String _replace = monitor.replace("count_full_", "");
            _builder.append(_replace, "    ");
            _builder.append(" during the execution of the accelerator</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          boolean _contains_1 = monitor.contains("count_clock_cycles");
          if (_contains_1) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_1 = monitor.replace("count_", "").toUpperCase();
            _builder.append(_upperCase_1, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of clock cycles from start to done signals.</desc>");
            _builder.newLine();
          }
        }
        {
          boolean _contains_2 = monitor.contains("count_in_tokens_");
          if (_contains_2) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_2 = monitor.replace("count_in_", "").toUpperCase();
            _builder.append(_upperCase_2, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of input tokens to the accelerator at port ");
            String _replace_1 = monitor.replace("count_in_tokens_", "");
            _builder.append(_replace_1, "    ");
            _builder.append("</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          boolean _contains_3 = monitor.contains("count_out_tokens_");
          if (_contains_3) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_3 = monitor.replace("count_out_", "").toUpperCase();
            _builder.append(_upperCase_3, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of output tokens from the accelerator at port ");
            String _replace_2 = monitor.replace("count_out_tokens_", "");
            _builder.append(_replace_2, "    ");
            _builder.append("</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("  ");
        _builder.append("</event>");
        _builder.newLine();
      }
    }
    _builder.append("</mdcInfo>");
    _builder.newLine();
    return _builder;
  }
  
  @Override
  public Integer getPortIdFromName(final String name) {
    Set<Port> _keySet = this.portMap.keySet();
    for (final Port port : _keySet) {
      boolean _equals = port.getName().equals(name);
      if (_equals) {
        return this.portMap.get(port);
      }
    }
    return null;
  }
  
  @Override
  public String getSuffix(final Map<String, String> idNameMap, final String id) {
    boolean _containsKey = idNameMap.containsKey(id);
    if (_containsKey) {
      boolean _equals = idNameMap.get(id).equals("");
      if (_equals) {
        return "";
      } else {
        String _get = idNameMap.get(id);
        return ("_" + _get);
      }
    }
    return null;
  }
  
  public String getMatchingWrapMapping(final String channel) {
    Set<String> _keySet = this.wrapCommSignals.keySet();
    for (final String commSigId : _keySet) {
      boolean _containsKey = this.wrapCommSignals.get(commSigId).containsKey(ProtocolManager.CH);
      if (_containsKey) {
        boolean _equals = channel.equals(this.wrapCommSignals.get(commSigId).get(ProtocolManager.CH));
        if (_equals) {
          return this.wrapCommSignals.get(commSigId).get(ProtocolManager.MAP);
        }
      }
    }
    return null;
  }
  
  public Map<String, String> getOutLastModCommSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.getLastModCommSignals().keySet();
    for (final String commSigId : _keySet) {
      if (((this.getLastModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("output") && this.getLastModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("direct")) || 
        (this.getLastModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("input") && this.getLastModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("reverse")))) {
        result.put(commSigId, this.getLastModCommSignals().get(commSigId).get(ProtocolManager.CH));
      }
    }
    return result;
  }
  
  public Map<String, Map<String, String>> getLastModCommSignals() {
    boolean _containsKey = this.modCommSignals.containsKey(ProtocolManager.SUCC);
    if (_containsKey) {
      return this.modCommSignals.get(ProtocolManager.SUCC);
    } else {
      return this.modCommSignals.get(ProtocolManager.ACTOR);
    }
  }
  
  public Map<String, String> getInFirstModCommSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.getFirstModCommSignals().keySet();
    for (final String commSigId : _keySet) {
      if (((this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("input") && this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("direct")) || 
        (this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("output") && this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("reverse")))) {
        result.put(commSigId, this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
      }
    }
    return result;
  }
  
  public Map<String, Map<String, String>> getFirstModCommSignals() {
    boolean _containsKey = this.modCommSignals.containsKey(ProtocolManager.PRED);
    if (_containsKey) {
      return this.modCommSignals.get(ProtocolManager.PRED);
    } else {
      return this.modCommSignals.get(ProtocolManager.ACTOR);
    }
  }
  
  public List<String> getClockSysSignals() {
    List<String> result = new ArrayList<String>();
    Set<String> _keySet = this.netSysSignals.keySet();
    for (final String sysSigId : _keySet) {
      boolean _containsKey = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.CLOCK);
      if (_containsKey) {
        result.add(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP));
      }
    }
    return result;
  }
  
  public Map<String, String> getResetSysSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.netSysSignals.keySet();
    for (final String sysSigId : _keySet) {
      boolean _containsKey = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.RST);
      if (_containsKey) {
        result.put(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP), "HIGH");
      } else {
        boolean _containsKey_1 = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.RSTN);
        if (_containsKey_1) {
          result.put(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP), "LOW");
        }
      }
    }
    return result;
  }
}
