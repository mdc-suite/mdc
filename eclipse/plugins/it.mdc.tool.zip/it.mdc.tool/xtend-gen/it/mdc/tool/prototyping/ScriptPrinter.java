package it.mdc.tool.prototyping;

import com.google.common.base.Objects;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IntegerRange;

/**
 * Vivado AXI IP Script Printer
 * 
 * @author Tiziana Fanni
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class ScriptPrinter {
  protected Map<Port, Integer> inputMap;
  
  protected Map<Port, Integer> outputMap;
  
  protected Map<Port, Integer> portMap;
  
  protected int fifoNum;
  
  protected boolean enDma = false;
  
  private String boardpart;
  
  private String partname;
  
  private String coupling;
  
  private List<String> libraries;
  
  private String processor;
  
  public boolean initScriptPrinter(final List<String> libraries, final String coupling, final String processor, final Boolean enDma, final String boardpart, final String partname) {
    boolean _xblockexpression = false;
    {
      this.boardpart = boardpart;
      this.partname = partname;
      this.coupling = coupling;
      this.libraries = libraries;
      this.processor = processor;
      _xblockexpression = this.enDma = (enDma).booleanValue();
    }
    return _xblockexpression;
  }
  
  public boolean isMemoryMapped() {
    boolean _equals = this.coupling.equals("mm");
    if (_equals) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isArm() {
    boolean _equals = this.processor.equals("ARM");
    if (_equals) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isUS() {
    if (((!Objects.equal(this.partname, null)) && (this.partname.contains("xczu") || this.partname.startsWith("xck26")))) {
      return true;
    } else {
      return false;
    }
  }
  
  public CharSequence printTopScript(final Network network) {
    CharSequence _xblockexpression = null;
    {
      this.mapInOut(network);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("# Script compliant with Vivado 2017.1");
      _builder.newLine();
      _builder.newLine();
      _builder.append("###########################");
      _builder.newLine();
      _builder.append("# IP Settings");
      _builder.newLine();
      _builder.append("###########################");
      _builder.newLine();
      _builder.newLine();
      _builder.append("# paths");
      _builder.newLine();
      _builder.newLine();
      _builder.append("# Resolve the output root from scripts/generate_*.tcl, not the caller CWD.");
      _builder.newLine();
      _builder.append("set root [file normalize [file join [file dirname [info script]] ..]]");
      _builder.newLine();
      _builder.append("set projdir $root/project_top");
      _builder.newLine();
      _builder.append("set ipdir $root/");
      _builder.append(this.coupling);
      _builder.append("_accelerator/project_ip");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("set constraints_files []");
      _builder.newLine();
      _builder.newLine();
      _builder.append("# FPGA device");
      _builder.newLine();
      _builder.append("set partname \"");
      _builder.append(this.partname);
      _builder.append("\"");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      {
        boolean _notEquals = (!Objects.equal(this.boardpart, "none"));
        if (_notEquals) {
          _builder.append("# Board part");
          _builder.newLine();
          _builder.append("set boardpart \"");
          _builder.append(this.boardpart);
          _builder.append("\"");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.newLine();
      _builder.append("# Design name");
      _builder.newLine();
      _builder.append("set design system");
      _builder.newLine();
      _builder.append("set bd_design \"design_1\"");
      _builder.newLine();
      _builder.newLine();
      _builder.append("set ip_name \"");
      _builder.append(this.coupling);
      _builder.append("_accelerator\"");
      _builder.newLineIfNotEmpty();
      _builder.append("set ip_version \"1.0\"");
      _builder.newLine();
      _builder.append("set ip_v \"v1_0\"");
      _builder.newLine();
      _builder.newLine();
      _builder.newLine();
      _builder.append("###########################");
      _builder.newLine();
      _builder.append("# Create Project");
      _builder.newLine();
      _builder.append("###########################");
      _builder.newLine();
      _builder.append("create_project -force $design $projdir -part $partname ");
      _builder.newLine();
      {
        boolean _notEquals_1 = (!Objects.equal(this.boardpart, "none"));
        if (_notEquals_1) {
          _builder.append("set_property board_part $boardpart [current_project]");
        }
      }
      _builder.newLineIfNotEmpty();
      _builder.append("set_property target_language Verilog [current_project]");
      _builder.newLine();
      _builder.append("set_property  ip_repo_paths $ipdir [current_project]");
      _builder.newLine();
      _builder.append("update_ip_catalog -rebuild -scan_changes");
      _builder.newLine();
      _builder.append("###########################");
      _builder.newLine();
      _builder.append("#create block design");
      _builder.newLine();
      _builder.append("create_bd_design $bd_design");
      _builder.newLine();
      _builder.newLine();
      {
        boolean _isArm = this.isArm();
        if (_isArm) {
          {
            boolean _isUS = this.isUS();
            if (_isUS) {
              _builder.append("# Zynq PS US");
              _builder.newLine();
              _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:zynq_ultra_ps_e:3.1 zynq_ultra_ps_e_0");
              _builder.newLine();
              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:zynq_ultra_ps_e -config {apply_board_preset \"1\" }  [get_bd_cells zynq_ultra_ps_e_0]");
              _builder.newLine();
              _builder.append("set_property -dict [list CONFIG.PSU__USE__M_AXI_GP1 {0}] [get_bd_cells zynq_ultra_ps_e_0]");
              _builder.newLine();
            } else {
              _builder.append("# Zynq PS");
              _builder.newLine();
              _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 processing_system7_0");
              _builder.newLine();
              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:processing_system7 -config {make_external \"FIXED_IO, DDR\" apply_board_preset \"1\" Master \"Disable\" Slave \"Disable\" }  [get_bd_cells processing_system7_0]");
              _builder.newLine();
              _builder.append("connect_bd_net [get_bd_pins processing_system7_0/M_AXI_GP0_ACLK] [get_bd_pins processing_system7_0/FCLK_CLK0]");
              _builder.newLine();
            }
          }
        } else {
          _builder.append("# MicroBlaze");
          _builder.newLine();
          _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:microblaze:10.0 microblaze_0");
          _builder.newLine();
          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:microblaze -config {preset \"None\" local_mem \"8KB\" ecc \"None\" cache \"None\" debug_module \"Debug Only\" axi_periph \"Enabled\" axi_intc \"0\" clk \"New Clocking Wizard (100 MHz)\" }  [get_bd_cells microblaze_0]");
          _builder.newLine();
          _builder.append("set_property -dict [list CONFIG.PRIM_SOURCE {Single_ended_clock_capable_pin} CONFIG.USE_LOCKED {false} CONFIG.USE_RESET {false}] [get_bd_cells clk_wiz_1]");
          _builder.newLine();
          _builder.append("delete_bd_objs [get_bd_nets clk_wiz_1_locked]");
          _builder.newLine();
          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:board -config {Board_Interface \"sys_clock ( System clock ) \" }  [get_bd_pins clk_wiz_1/clk_in1]");
          _builder.newLine();
          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:board -config {rst_polarity \"ACTIVE_LOW\" }  [get_bd_pins rst_clk_wiz_1_100M/ext_reset_in]");
          _builder.newLine();
          _builder.append("set_property -dict [list CONFIG.C_FSL_LINKS {");
          {
            int _size = this.inputMap.size();
            int _size_1 = this.outputMap.size();
            boolean _greaterThan = (_size > _size_1);
            if (_greaterThan) {
              int _size_2 = this.inputMap.size();
              _builder.append(_size_2);
            } else {
              int _size_3 = this.outputMap.size();
              _builder.append(_size_3);
            }
          }
          _builder.append("}] [get_bd_cells microblaze_0]");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.newLine();
      _builder.append("# accelerator IP");
      _builder.newLine();
      _builder.append("create_bd_cell -type ip -vlnv user.org:user:$ip_name:$ip_version $ip_name\\_0");
      _builder.newLine();
      {
        boolean _isArm_1 = this.isArm();
        if (_isArm_1) {
          {
            boolean _isUS_1 = this.isUS();
            if (_isUS_1) {
              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/zynq_ultra_ps_e_0/M_AXI_HPM0_FPD\" intc_ip \"New AXI Interconnect\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins $ip_name\\_0/s00_axi]");
              _builder.newLine();
            } else {
              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"New AXI Interconnect\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins $ip_name\\_0/s00_axi]");
              _builder.newLine();
            }
          }
        } else {
          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"New AXI Interconnect\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins $ip_name\\_0/s00_axi]");
          _builder.newLine();
        }
      }
      {
        boolean _isMemoryMapped = this.isMemoryMapped();
        if (_isMemoryMapped) {
          {
            boolean _isArm_2 = this.isArm();
            if (_isArm_2) {
              {
                if (this.enDma) {
                  _builder.append("# CDMA");
                  _builder.newLine();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_cdma:4.1 axi_cdma_0");
                  _builder.newLine();
                  _builder.append("set_property -dict [list CONFIG.C_INCLUDE_SG {0}] [get_bd_cells axi_cdma_0]");
                  _builder.newLine();
                  {
                    boolean _isUS_2 = this.isUS();
                    if (_isUS_2) {
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/zynq_ultra_ps_e_0/M_AXI_HPM0_FPD\" intc_ip \"/ps8_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_cdma_0/S_AXI_LITE]");
                      _builder.newLine();
                      _builder.append("set_property -dict [list CONFIG.PSU__USE__S_AXI_GP2 {1} CONFIG.PSU__SAXIGP2__DATA_WIDTH {32}] [get_bd_cells zynq_ultra_ps_e_0]");
                      _builder.newLine();
                    } else {
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"/ps7_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_cdma_0/S_AXI_LITE]");
                      _builder.newLine();
                      _builder.append("set_property -dict [list CONFIG.PCW_USE_S_AXI_HP0 {1}] [get_bd_cells processing_system7_0]");
                      _builder.newLine();
                    }
                  }
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/axi_cdma_0/M_AXI\" intc_ip \"New AXI Interconnect\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins mm_accelerator_0/s01_axi]");
                  _builder.newLine();
                  {
                    boolean _isUS_3 = this.isUS();
                    if (_isUS_3) {
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/axi_cdma_0/M_AXI\" intc_ip \"/axi_mem_intercon\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins zynq_ultra_ps_e_0/S_AXI_HP0_FPD]");
                      _builder.newLine();
                    } else {
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/axi_cdma_0/M_AXI\" intc_ip \"/axi_mem_intercon\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins processing_system7_0/S_AXI_HP0]");
                      _builder.newLine();
                    }
                  }
                } else {
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"Auto\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins $ip_name\\_0/s01_axi]");
                  _builder.newLine();
                }
              }
            } else {
              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"Auto\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins mm_accelerator_0/s01_axi]\t\t");
              _builder.newLine();
              {
                if (this.enDma) {
                  _builder.append("# AXI controlled BRAM");
                  _builder.newLine();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_bram_ctrl:4.0 axi_bram_ctrl_0");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/S_AXI]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:bram_cntlr -config {BRAM \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/BRAM_PORTA]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:bram_cntlr -config {BRAM \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/BRAM_PORTB]");
                  _builder.newLine();
                  _builder.append("# CDMA");
                  _builder.newLine();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_cdma:4.1 axi_cdma_0");
                  _builder.newLine();
                  _builder.append("set_property -dict [list CONFIG.C_INCLUDE_SG {0}] [get_bd_cells axi_cdma_0]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Slave \"/axi_bram_ctrl_0/S_AXI\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_cdma_0/M_AXI]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_cdma_0/S_AXI_LITE]");
                  _builder.newLine();
                  _builder.append("include_bd_addr_seg [get_bd_addr_segs -excluded axi_cdma_0/Data/SEG_mm_accelerator_0_reg03]");
                  _builder.newLine();
                }
              }
            }
          }
        } else {
          _builder.newLine();
          _builder.append("# fifos - accelerator side");
          _builder.newLine();
          {
            Set<Port> _keySet = this.inputMap.keySet();
            for(final Port input : _keySet) {
              _builder.append("# fifo_in ");
              Integer _get = this.inputMap.get(input);
              _builder.append(_get);
              _builder.newLineIfNotEmpty();
              {
                boolean _isArm_3 = this.isArm();
                if (_isArm_3) {
                  {
                    boolean _isUS_4 = this.isUS();
                    if (_isUS_4) {
                      _builder.append("connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] [get_bd_pins s_accelerator_0/s");
                      String _longId = this.getLongId((this.inputMap.get(input)).intValue());
                      _builder.append(_longId);
                      _builder.append("_axis_aclk]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_net [get_bd_pins rst_ps8_0_99M/peripheral_aresetn] [get_bd_pins s_accelerator_0/s");
                      String _longId_1 = this.getLongId((this.inputMap.get(input)).intValue());
                      _builder.append(_longId_1);
                      _builder.append("_axis_aresetn]");
                      _builder.newLineIfNotEmpty();
                    } else {
                      _builder.append("connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] [get_bd_pins s_accelerator_0/s");
                      String _longId_2 = this.getLongId((this.inputMap.get(input)).intValue());
                      _builder.append(_longId_2);
                      _builder.append("_axis_aclk]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] [get_bd_pins s_accelerator_0/s");
                      String _longId_3 = this.getLongId((this.inputMap.get(input)).intValue());
                      _builder.append(_longId_3);
                      _builder.append("_axis_aresetn]");
                      _builder.newLineIfNotEmpty();
                    }
                  }
                  {
                    if (this.enDma) {
                      _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axis_data_fifo:1.1 axis_data_fifo_in_");
                      Integer _get_1 = this.inputMap.get(input);
                      _builder.append(_get_1);
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_in_");
                      Integer _get_2 = this.inputMap.get(input);
                      _builder.append(_get_2);
                      _builder.append("/M_AXIS] [get_bd_intf_pins s_accelerator_0/s");
                      String _longId_4 = this.getLongId((this.inputMap.get(input)).intValue());
                      _builder.append(_longId_4);
                      _builder.append("_axis]");
                      _builder.newLineIfNotEmpty();
                      {
                        boolean _isUS_5 = this.isUS();
                        if (_isUS_5) {
                          _builder.append("connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] [get_bd_pins axis_data_fifo_in_");
                          Integer _get_3 = this.inputMap.get(input);
                          _builder.append(_get_3);
                          _builder.append("/s_axis_aclk]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_net [get_bd_pins rst_ps8_0_99M/peripheral_aresetn] [get_bd_pins axis_data_fifo_in_");
                          Integer _get_4 = this.inputMap.get(input);
                          _builder.append(_get_4);
                          _builder.append("/s_axis_aresetn]");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] [get_bd_pins axis_data_fifo_in_");
                          Integer _get_5 = this.inputMap.get(input);
                          _builder.append(_get_5);
                          _builder.append("/s_axis_aclk]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] [get_bd_pins axis_data_fifo_in_");
                          Integer _get_6 = this.inputMap.get(input);
                          _builder.append(_get_6);
                          _builder.append("/s_axis_aresetn]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                } else {
                  _builder.append("connect_bd_net [get_bd_pins s_accelerator_0/s");
                  String _longId_5 = this.getLongId((this.inputMap.get(input)).intValue());
                  _builder.append(_longId_5);
                  _builder.append("_axis_aclk] [get_bd_pins clk_wiz_1/clk_out1]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins s_accelerator_0/s");
                  String _longId_6 = this.getLongId((this.inputMap.get(input)).intValue());
                  _builder.append(_longId_6);
                  _builder.append("_axis_aresetn] [get_bd_pins rst_clk_wiz_1_100M/peripheral_aresetn]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axis_data_fifo:1.1 axis_data_fifo_in_");
                  Integer _get_7 = this.inputMap.get(input);
                  _builder.append(_get_7);
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_in_");
                  Integer _get_8 = this.inputMap.get(input);
                  _builder.append(_get_8);
                  _builder.append("/M_AXIS] [get_bd_intf_pins s_accelerator_0/s");
                  String _longId_7 = this.getLongId((this.inputMap.get(input)).intValue());
                  _builder.append(_longId_7);
                  _builder.append("_axis]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins clk_wiz_1/clk_out1] [get_bd_pins axis_data_fifo_in_");
                  Integer _get_9 = this.inputMap.get(input);
                  _builder.append(_get_9);
                  _builder.append("/s_axis_aclk]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins rst_clk_wiz_1_100M/peripheral_aresetn] [get_bd_pins axis_data_fifo_in_");
                  Integer _get_10 = this.inputMap.get(input);
                  _builder.append(_get_10);
                  _builder.append("/s_axis_aresetn]");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.newLine();
          {
            Set<Port> _keySet_1 = this.outputMap.keySet();
            for(final Port output : _keySet_1) {
              _builder.append("# fifo_out ");
              Integer _get_11 = this.inputMap.get(output);
              _builder.append(_get_11);
              _builder.newLineIfNotEmpty();
              {
                boolean _isArm_4 = this.isArm();
                if (_isArm_4) {
                  {
                    boolean _isUS_6 = this.isUS();
                    if (_isUS_6) {
                      _builder.append("connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] [get_bd_pins s_accelerator_0/m");
                      String _longId_8 = this.getLongId((this.outputMap.get(output)).intValue());
                      _builder.append(_longId_8);
                      _builder.append("_axis_aclk]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_net [get_bd_pins rst_ps8_0_99M/peripheral_aresetn] [get_bd_pins s_accelerator_0/m");
                      String _longId_9 = this.getLongId((this.outputMap.get(output)).intValue());
                      _builder.append(_longId_9);
                      _builder.append("_axis_aresetn]");
                      _builder.newLineIfNotEmpty();
                    } else {
                      _builder.append("connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] [get_bd_pins s_accelerator_0/m");
                      String _longId_10 = this.getLongId((this.outputMap.get(output)).intValue());
                      _builder.append(_longId_10);
                      _builder.append("_axis_aclk]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] [get_bd_pins s_accelerator_0/m");
                      String _longId_11 = this.getLongId((this.outputMap.get(output)).intValue());
                      _builder.append(_longId_11);
                      _builder.append("_axis_aresetn]");
                      _builder.newLineIfNotEmpty();
                    }
                  }
                  {
                    if (this.enDma) {
                      _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axis_data_fifo:1.1 axis_data_fifo_out_");
                      Integer _get_12 = this.outputMap.get(output);
                      _builder.append(_get_12);
                      _builder.newLineIfNotEmpty();
                      _builder.append("connect_bd_intf_net [get_bd_intf_pins s_accelerator_0/m");
                      String _longId_12 = this.getLongId((this.outputMap.get(output)).intValue());
                      _builder.append(_longId_12);
                      _builder.append("_axis] [get_bd_intf_pins axis_data_fifo_out_");
                      Integer _get_13 = this.outputMap.get(output);
                      _builder.append(_get_13);
                      _builder.append("/S_AXIS]");
                      _builder.newLineIfNotEmpty();
                      {
                        boolean _isUS_7 = this.isUS();
                        if (_isUS_7) {
                          _builder.append("connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] [get_bd_pins axis_data_fifo_out_");
                          Integer _get_14 = this.outputMap.get(output);
                          _builder.append(_get_14);
                          _builder.append("/s_axis_aclk]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_net [get_bd_pins rst_ps8_0_99M/peripheral_aresetn] [get_bd_pins axis_data_fifo_out_");
                          Integer _get_15 = this.outputMap.get(output);
                          _builder.append(_get_15);
                          _builder.append("/s_axis_aresetn]");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("connect_bd_net [get_bd_pins processing_system7_0/FCLK_CLK0] [get_bd_pins axis_data_fifo_out_");
                          Integer _get_16 = this.outputMap.get(output);
                          _builder.append(_get_16);
                          _builder.append("/s_axis_aclk]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_net [get_bd_pins rst_ps7_0_100M/peripheral_aresetn] [get_bd_pins axis_data_fifo_out_");
                          Integer _get_17 = this.outputMap.get(output);
                          _builder.append(_get_17);
                          _builder.append("/s_axis_aresetn]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                } else {
                  _builder.append("connect_bd_net [get_bd_pins s_accelerator_0/m");
                  String _longId_13 = this.getLongId((this.outputMap.get(output)).intValue());
                  _builder.append(_longId_13);
                  _builder.append("_axis_aclk] [get_bd_pins clk_wiz_1/clk_out1]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins s_accelerator_0/m");
                  String _longId_14 = this.getLongId((this.outputMap.get(output)).intValue());
                  _builder.append(_longId_14);
                  _builder.append("_axis_aresetn] [get_bd_pins rst_clk_wiz_1_100M/peripheral_aresetn]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axis_data_fifo:1.1 axis_data_fifo_out_");
                  Integer _get_18 = this.outputMap.get(output);
                  _builder.append(_get_18);
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_intf_net [get_bd_intf_pins s_accelerator_0/m");
                  String _longId_15 = this.getLongId((this.outputMap.get(output)).intValue());
                  _builder.append(_longId_15);
                  _builder.append("_axis] [get_bd_intf_pins axis_data_fifo_out_");
                  Integer _get_19 = this.outputMap.get(output);
                  _builder.append(_get_19);
                  _builder.append("/S_AXIS]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins clk_wiz_1/clk_out1] [get_bd_pins axis_data_fifo_out_");
                  Integer _get_20 = this.outputMap.get(output);
                  _builder.append(_get_20);
                  _builder.append("/s_axis_aclk]");
                  _builder.newLineIfNotEmpty();
                  _builder.append("connect_bd_net [get_bd_pins rst_clk_wiz_1_100M/peripheral_aresetn] [get_bd_pins axis_data_fifo_out_");
                  Integer _get_21 = this.outputMap.get(output);
                  _builder.append(_get_21);
                  _builder.append("/s_axis_aresetn]");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.newLine();
          _builder.append("# fifos - processor side");
          _builder.newLine();
          {
            if (this.enDma) {
              {
                boolean _isArm_5 = this.isArm();
                if (_isArm_5) {
                  {
                    IntegerRange _upTo = new IntegerRange(0, (this.fifoNum - 1));
                    for(final Integer i : _upTo) {
                      _builder.append("# DMA ");
                      _builder.append(i);
                      _builder.newLineIfNotEmpty();
                      _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_dma:7.1 axi_dma_");
                      _builder.append(i);
                      _builder.newLineIfNotEmpty();
                      {
                        boolean _isUS_8 = this.isUS();
                        if (_isUS_8) {
                          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/zynq_ultra_ps_e_0/M_AXI_HPM0_FPD\" intc_ip \"/ps8_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                          _builder.append(i);
                          _builder.append("/S_AXI_LITE]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("set_property -dict [list CONFIG.PSU__USE__S_AXI_GP");
                          _builder.append(((i).intValue() + 2));
                          _builder.append(" {1} CONFIG.PSU__SAXIGP");
                          _builder.append(((i).intValue() + 2));
                          _builder.append("__DATA_WIDTH {32}] [get_bd_cells zynq_ultra_ps_e_0]");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"/ps7_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                          _builder.append(i);
                          _builder.append("/S_AXI_LITE]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("set_property -dict [list CONFIG.PCW_USE_S_AXI_HP");
                          _builder.append(i);
                          _builder.append(" {1}] [get_bd_cells processing_system7_0]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                      _builder.append("set_property -dict [list CONFIG.c_include_sg {0} CONFIG.c_sg_include_stscntrl_strm {0}] [get_bd_cells axi_dma_");
                      _builder.append(i);
                      _builder.append("]");
                      _builder.newLineIfNotEmpty();
                      {
                        int _size_4 = this.inputMap.size();
                        boolean _lessThan = ((i).intValue() < _size_4);
                        if (_lessThan) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_in_");
                          _builder.append(i);
                          _builder.append("/S_AXIS] [get_bd_intf_pins axi_dma_");
                          _builder.append(i);
                          _builder.append("/M_AXIS_MM2S]\t\t\t\t\t\t");
                          _builder.newLineIfNotEmpty();
                          {
                            boolean _isUS_9 = this.isUS();
                            if (_isUS_9) {
                              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/axi_dma_");
                              _builder.append(i);
                              _builder.append("/M_AXI_MM2S\" intc_ip \"Auto\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins zynq_ultra_ps_e_0/S_AXI_HP");
                              _builder.append(i);
                              _builder.append("_FPD]");
                              _builder.newLineIfNotEmpty();
                            } else {
                              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/axi_dma_");
                              _builder.append(i);
                              _builder.append("/M_AXI_MM2S\" intc_ip \"Auto\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins processing_system7_0/S_AXI_HP");
                              _builder.append(i);
                              _builder.append("]");
                              _builder.newLineIfNotEmpty();
                            }
                          }
                        } else {
                          _builder.append("set_property -dict [list CONFIG.c_include_mm2s {0}] [get_bd_cells axi_dma_");
                          _builder.append(i);
                          _builder.append("]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                      {
                        int _size_5 = this.outputMap.size();
                        boolean _lessThan_1 = ((i).intValue() < _size_5);
                        if (_lessThan_1) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_out_");
                          _builder.append(i);
                          _builder.append("/M_AXIS] [get_bd_intf_pins axi_dma_");
                          _builder.append(i);
                          _builder.append("/S_AXIS_S2MM]");
                          _builder.newLineIfNotEmpty();
                          {
                            boolean _isUS_10 = this.isUS();
                            if (_isUS_10) {
                              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Slave \"/zynq_ultra_ps_e_0/S_AXI_HP");
                              _builder.append(i);
                              _builder.append("_FPD\" intc_ip \"/axi_smc\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                              _builder.append(i);
                              _builder.append("/M_AXI_S2MM]");
                              _builder.newLineIfNotEmpty();
                            } else {
                              _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Slave \"/processing_system7_0/S_AXI_HP");
                              _builder.append(i);
                              _builder.append("\" intc_ip \"/axi_smc\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                              _builder.append(i);
                              _builder.append("/M_AXI_S2MM]");
                              _builder.newLineIfNotEmpty();
                            }
                          }
                        } else {
                          _builder.append("set_property -dict [list CONFIG.c_include_s2mm {0}] [get_bd_cells axi_dma_");
                          _builder.append(i);
                          _builder.append("]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                } else {
                  _builder.append("# AXI controlled BRAM");
                  _builder.newLine();
                  _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_bram_ctrl:4.0 axi_bram_ctrl_0");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/S_AXI]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:bram_cntlr -config {BRAM \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/BRAM_PORTA]");
                  _builder.newLine();
                  _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:bram_cntlr -config {BRAM \"Auto\" }  [get_bd_intf_pins axi_bram_ctrl_0/BRAM_PORTB]");
                  _builder.newLine();
                  {
                    IntegerRange _upTo_1 = new IntegerRange(0, (this.fifoNum - 1));
                    for(final Integer i_1 : _upTo_1) {
                      _builder.append("# DMA ");
                      _builder.append(i_1);
                      _builder.newLineIfNotEmpty();
                      _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_dma:7.1 axi_dma_");
                      _builder.append(i_1);
                      _builder.newLineIfNotEmpty();
                      _builder.append("set_property -dict [list CONFIG.c_include_sg {0} CONFIG.c_sg_include_stscntrl_strm {0}] [get_bd_cells axi_dma_");
                      _builder.append(i_1);
                      _builder.append("]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/microblaze_0 (Periph)\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                      _builder.append(i_1);
                      _builder.append("/S_AXI_LITE]");
                      _builder.newLineIfNotEmpty();
                      {
                        int _size_6 = this.inputMap.size();
                        boolean _lessThan_2 = ((i_1).intValue() < _size_6);
                        if (_lessThan_2) {
                          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Slave \"/axi_bram_ctrl_0/S_AXI\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                          _builder.append(i_1);
                          _builder.append("/M_AXI_MM2S]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_in_");
                          _builder.append(i_1);
                          _builder.append("/S_AXIS] [get_bd_intf_pins axi_dma_");
                          _builder.append(i_1);
                          _builder.append("/M_AXIS_MM2S]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                      {
                        int _size_7 = this.outputMap.size();
                        boolean _lessThan_3 = ((i_1).intValue() < _size_7);
                        if (_lessThan_3) {
                          _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Slave \"/axi_bram_ctrl_0/S_AXI\" intc_ip \"/microblaze_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_dma_");
                          _builder.append(i_1);
                          _builder.append("/M_AXI_S2MM]");
                          _builder.newLineIfNotEmpty();
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins axis_data_fifo_out_");
                          _builder.append(i_1);
                          _builder.append("/M_AXIS] [get_bd_intf_pins axi_dma_");
                          _builder.append(i_1);
                          _builder.append("/S_AXIS_S2MM]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                }
              }
            } else {
              {
                boolean _isArm_6 = this.isArm();
                if (_isArm_6) {
                  {
                    IntegerRange _upTo_2 = new IntegerRange(0, (this.fifoNum - 1));
                    for(final Integer i_2 : _upTo_2) {
                      _builder.append("create_bd_cell -type ip -vlnv xilinx.com:ip:axi_fifo_mm_s:4.1 axi_fifo_mm_s_");
                      _builder.append(i_2);
                      _builder.newLineIfNotEmpty();
                      _builder.append("set_property -dict [list CONFIG.C_USE_TX_CTRL {0}] [get_bd_cells axi_fifo_mm_s_");
                      _builder.append(i_2);
                      _builder.append("]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("set_property -dict [list CONFIG.C_DATA_INTERFACE_TYPE {1}] [get_bd_cells axi_fifo_mm_s_");
                      _builder.append(i_2);
                      _builder.append("]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"/ps7_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_fifo_mm_s_");
                      _builder.append(i_2);
                      _builder.append("/S_AXI]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("apply_bd_automation -rule xilinx.com:bd_rule:axi4 -config {Master \"/processing_system7_0/M_AXI_GP0\" intc_ip \"/ps7_0_axi_periph\" Clk_xbar \"Auto\" Clk_master \"Auto\" Clk_slave \"Auto\" }  [get_bd_intf_pins axi_fifo_mm_s_");
                      _builder.append(i_2);
                      _builder.append("/S_AXI_FULL]");
                      _builder.newLineIfNotEmpty();
                      {
                        int _size_8 = this.inputMap.size();
                        boolean _lessThan_4 = ((i_2).intValue() < _size_8);
                        if (_lessThan_4) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins axi_fifo_mm_s_");
                          _builder.append(i_2);
                          _builder.append("/AXI_STR_TXD] [get_bd_intf_pins s_accelerator_0/s");
                          String _longId_16 = this.getLongId((i_2).intValue());
                          _builder.append(_longId_16);
                          _builder.append("_axis]");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("set_property -dict [list CONFIG.C_USE_TX_DATA {0}] [get_bd_cells axi_fifo_mm_s_");
                          _builder.append(i_2);
                          _builder.append("]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                      {
                        int _size_9 = this.outputMap.size();
                        boolean _lessThan_5 = ((i_2).intValue() < _size_9);
                        if (_lessThan_5) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins s_accelerator_0/m");
                          String _longId_17 = this.getLongId((i_2).intValue());
                          _builder.append(_longId_17);
                          _builder.append("_axis] [get_bd_intf_pins axi_fifo_mm_s_");
                          _builder.append(i_2);
                          _builder.append("/AXI_STR_RXD]");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("set_property -dict [list CONFIG.C_USE_RX_DATA {0}] [get_bd_cells axi_fifo_mm_s_");
                          _builder.append(i_2);
                          _builder.append("]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                } else {
                  {
                    IntegerRange _upTo_3 = new IntegerRange(0, (this.fifoNum - 1));
                    for(final Integer i_3 : _upTo_3) {
                      {
                        int _size_10 = this.inputMap.size();
                        boolean _lessThan_6 = ((i_3).intValue() < _size_10);
                        if (_lessThan_6) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins microblaze_0/S");
                          _builder.append(i_3);
                          _builder.append("_AXIS] [get_bd_intf_pins axis_data_fifo_out_");
                          _builder.append(i_3);
                          _builder.append("/M_AXIS]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                      {
                        int _size_11 = this.outputMap.size();
                        boolean _lessThan_7 = ((i_3).intValue() < _size_11);
                        if (_lessThan_7) {
                          _builder.append("connect_bd_intf_net [get_bd_intf_pins microblaze_0/M");
                          _builder.append(i_3);
                          _builder.append("_AXIS] [get_bd_intf_pins axis_data_fifo_in_");
                          _builder.append(i_3);
                          _builder.append("/S_AXIS]");
                          _builder.newLineIfNotEmpty();
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      _builder.newLine();
      _builder.append("make_wrapper -files [get_files $projdir/$design.srcs/sources_1/bd/design_1/design_1.bd] -top");
      _builder.newLine();
      _builder.append("add_files -norecurse $projdir/$design.srcs/sources_1/bd/design_1/hdl/design_1_wrapper.v");
      _builder.newLine();
      _builder.newLine();
      _builder.append("generate_target all [get_files  $projdir/$design.srcs/sources_1/bd/design_1/design_1.bd]");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printIpScript() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("# Script compliant with Vivado 2017.1");
    _builder.newLine();
    _builder.newLine();
    _builder.append("###########################");
    _builder.newLine();
    _builder.append("# IP Settings");
    _builder.newLine();
    _builder.append("###########################");
    _builder.newLine();
    _builder.newLine();
    _builder.append("# paths");
    _builder.newLine();
    _builder.newLine();
    _builder.append("# Resolve the output root from scripts/generate_*.tcl, not the caller CWD.");
    _builder.newLine();
    _builder.append("set root [file normalize [file join [file dirname [info script]] ..]]");
    _builder.newLine();
    _builder.append("set iproot $root/");
    _builder.append(this.coupling);
    _builder.append("_accelerator");
    _builder.newLineIfNotEmpty();
    _builder.append("set ipdir $iproot/project_ip");
    _builder.newLine();
    _builder.append("set acc_ip_dir $ipdir/acc_ip");
    _builder.newLine();
    _builder.newLine();
    _builder.append("set hdl_files_path $root/");
    _builder.append(this.coupling);
    _builder.append("_accelerator/hdl");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("set bd_pkg_dir ");
    _builder.append(this.coupling);
    _builder.append("_accelerator/bd");
    _builder.newLineIfNotEmpty();
    _builder.append("set drivers_dir ");
    _builder.append(this.coupling);
    _builder.append("_accelerator/drivers");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("set constraints_files []");
    _builder.newLine();
    _builder.newLine();
    _builder.append("# FPGA device");
    _builder.newLine();
    _builder.append("set partname \"");
    _builder.append(this.partname);
    _builder.append("\"");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.newLine();
    {
      boolean _notEquals = (!Objects.equal(this.boardpart, "none"));
      if (_notEquals) {
        _builder.append("# Board part");
        _builder.newLine();
        _builder.append("set boardpart \"");
        _builder.append(this.boardpart);
        _builder.append("\"");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("# Design name");
    _builder.newLine();
    _builder.append("set ip_name \"");
    _builder.append(this.coupling);
    _builder.append("_accelerator\"");
    _builder.newLineIfNotEmpty();
    _builder.append("set design $ip_name");
    _builder.newLine();
    _builder.newLine();
    _builder.append("###########################");
    _builder.newLine();
    _builder.append("# Create IP");
    _builder.newLine();
    _builder.append("###########################");
    _builder.newLine();
    _builder.newLine();
    _builder.append("create_project -force $design $ipdir -part $partname ");
    _builder.newLine();
    {
      boolean _notEquals_1 = (!Objects.equal(this.boardpart, "none"));
      if (_notEquals_1) {
        _builder.append("set_property board_part $boardpart [current_project]");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("set_property target_language Verilog [current_project]");
    _builder.newLine();
    _builder.newLine();
    _builder.append("add_files $hdl_files_path");
    _builder.newLine();
    _builder.append("import_files -force");
    _builder.newLine();
    _builder.newLine();
    {
      for(final String lib : this.libraries) {
        _builder.append("set files [glob -tails -directory $ipdir/$ip_name.srcs/sources_1/imports/hdl/lib/");
        _builder.append(lib);
        _builder.append("/ *]");
        _builder.newLineIfNotEmpty();
        _builder.append("foreach f $files {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("set name $f");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("set_property library ");
        _builder.append(lib, "\t");
        _builder.append(" [get_files  $ipdir/$ip_name.srcs/sources_1/imports/hdl/lib/");
        _builder.append(lib, "\t");
        _builder.append("/$f]");
        _builder.newLineIfNotEmpty();
        _builder.append("        ");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("if {[llength [glob -nocomplain -dir $hdl_files_path *.dat]] != 0} {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("foreach dat_file [glob -dir $hdl_files_path *.dat] {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("import_file $dat_file");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("if {[llength [glob -nocomplain -dir $hdl_files_path *.mem]] != 0} {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("foreach mem_file [glob -dir $hdl_files_path *.mem] {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("import_file $mem_file");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("if {[llength [glob -nocomplain -dir $hdl_files_path *.tcl]] != 0} {");
    _builder.newLine();
    _builder.append("\t ");
    _builder.append("foreach tcl_file [glob -dir $hdl_files_path *.tcl] {");
    _builder.newLine();
    _builder.append("\t     ");
    _builder.append("source $tcl_file");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    _builder.newLine();
    _builder.append("set_property top $ip_name [current_fileset]");
    _builder.newLine();
    _builder.newLine();
    _builder.append("ipx::package_project -root_dir $acc_ip_dir -vendor user.org -library user -taxonomy AXI_Peripheral -import_files -set_current true");
    _builder.newLine();
    _builder.newLine();
    _builder.append("ipx::remove_address_block reg0 [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]");
    _builder.newLine();
    _builder.append("ipx::add_address_block s00_axi_reg [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]");
    _builder.newLine();
    _builder.append("set_property usage register [ipx::get_address_blocks s00_axi_reg -of_objects [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]]");
    _builder.newLine();
    _builder.append("ipx::add_address_block_parameter OFFSET_BASE_PARAM [ipx::get_address_blocks s00_axi_reg -of_objects [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]]");
    _builder.newLine();
    _builder.append("ipx::add_address_block_parameter OFFSET_HIGH_PARAM [ipx::get_address_blocks s00_axi_reg -of_objects [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]]");
    _builder.newLine();
    _builder.append("set_property value C_CFG_BASEADDR [ipx::get_address_block_parameters OFFSET_BASE_PARAM -of_objects [ipx::get_address_blocks s00_axi_reg -of_objects [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]]]");
    _builder.newLine();
    _builder.append("set_property value C_CFG_HIGHADDR [ipx::get_address_block_parameters OFFSET_HIGH_PARAM -of_objects [ipx::get_address_blocks s00_axi_reg -of_objects [ipx::get_memory_maps s00_axi -of_objects [ipx::current_core]]]]\t");
    _builder.newLine();
    {
      boolean _isMemoryMapped = this.isMemoryMapped();
      if (_isMemoryMapped) {
        _builder.append("ipx::remove_address_block reg0 [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("ipx::add_address_block s01_axi_mem [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property usage memory [ipx::get_address_blocks s01_axi_mem -of_objects [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]]");
        _builder.newLine();
        _builder.append("ipx::add_address_block_parameter OFFSET_BASE_PARAM [ipx::get_address_blocks s01_axi_mem -of_objects [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]]");
        _builder.newLine();
        _builder.append("ipx::add_address_block_parameter OFFSET_HIGH_PARAM [ipx::get_address_blocks s01_axi_mem -of_objects [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]]");
        _builder.newLine();
        _builder.append("set_property value C_MEM_BASEADDR [ipx::get_address_block_parameters OFFSET_BASE_PARAM -of_objects [ipx::get_address_blocks s01_axi_mem -of_objects [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]]]");
        _builder.newLine();
        _builder.append("set_property value C_MEM_HIGHADDR [ipx::get_address_block_parameters OFFSET_HIGH_PARAM -of_objects [ipx::get_address_blocks s01_axi_mem -of_objects [ipx::get_memory_maps s01_axi -of_objects [ipx::current_core]]]]");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ID_WIDTH\'))>0 [ipx::get_ports s01_axi_awid -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_AWUSER_WIDTH\'))>0 [ipx::get_ports s01_axi_awuser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_WUSER_WIDTH\'))>0 [ipx::get_ports s01_axi_wuser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ID_WIDTH\'))>0 [ipx::get_ports s01_axi_bid -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_BUSER_WIDTH\'))>0 [ipx::get_ports s01_axi_buser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency {spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ID_WIDTH\')) >0} [ipx::get_ports s01_axi_arid -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ARUSER_WIDTH\')) [ipx::get_ports s01_axi_aruser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ARUSER_WIDTH\'))>0 [ipx::get_ports s01_axi_aruser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_ID_WIDTH\'))>0 [ipx::get_ports s01_axi_rid -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.append("set_property enablement_dependency spirit:decode(id(\'MODELPARAM_VALUE.C_S01_AXI_RUSER_WIDTH\'))>0 [ipx::get_ports s01_axi_ruser -of_objects [ipx::current_core]]");
        _builder.newLine();
        _builder.newLine();
        _builder.newLine();
        _builder.newLine();
        _builder.append("file copy -force $iproot/bd $ipdir");
        _builder.newLine();
        _builder.append("set bd_pkg_dir bd");
        _builder.newLine();
        _builder.append("set bd_group [ipx::add_file_group -type xilinx_blockdiagram {} [ipx::current_core]]");
        _builder.newLine();
        _builder.append("ipx::add_file $bd_pkg_dir/bd.tcl $bd_group\t\t");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("file copy -force $iproot/drivers $acc_ip_dir");
    _builder.newLine();
    _builder.append("set drivers_dir drivers");
    _builder.newLine();
    _builder.append("ipx::add_file_group -type software_driver {} [ipx::current_core]");
    _builder.newLine();
    _builder.append("ipx::add_file $drivers_dir/src/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.c [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]");
    _builder.newLineIfNotEmpty();
    _builder.append("set_property type cSource [ipx::get_files $drivers_dir/src/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.c -of_objects [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]]");
    _builder.newLineIfNotEmpty();
    _builder.append("ipx::add_file $drivers_dir/src/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.h [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]");
    _builder.newLineIfNotEmpty();
    _builder.append("set_property type cSource [ipx::get_files $drivers_dir/src/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.h -of_objects [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]]");
    _builder.newLineIfNotEmpty();
    _builder.append("ipx::add_file $drivers_dir/src/Makefile [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]");
    _builder.newLine();
    _builder.append("set_property type unknown [ipx::get_files $drivers_dir/src/Makefile -of_objects [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]]");
    _builder.newLine();
    _builder.append("ipx::add_file $drivers_dir/data/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.tcl [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]");
    _builder.newLineIfNotEmpty();
    _builder.append("set_property type tclSource [ipx::get_files $drivers_dir/data/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.tcl -of_objects [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]]");
    _builder.newLineIfNotEmpty();
    _builder.append("ipx::add_file $drivers_dir/data/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.mdd [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]");
    _builder.newLineIfNotEmpty();
    _builder.append("set_property type mdd [ipx::get_files $drivers_dir/data/");
    _builder.append(this.coupling);
    _builder.append("_accelerator.mdd -of_objects [ipx::get_file_groups xilinx_softwaredriver -of_objects [ipx::current_core]]]");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.newLine();
    _builder.append("set_property core_revision 3 [ipx::current_core]");
    _builder.newLine();
    _builder.append("ipx::create_xgui_files [ipx::current_core]");
    _builder.newLine();
    _builder.append("ipx::update_checksums [ipx::current_core]");
    _builder.newLine();
    _builder.append("ipx::save_core [ipx::current_core]");
    _builder.newLine();
    _builder.append("set_property  ip_repo_paths $ipdir [current_project]");
    _builder.newLine();
    _builder.append("update_ip_catalog");
    _builder.newLine();
    _builder.append("close_project");
    _builder.newLine();
    return _builder;
  }
  
  protected String getLongId(final int id) {
    if ((id < 10)) {
      String _string = Integer.valueOf(id).toString();
      return ("0" + _string);
    } else {
      return Integer.valueOf(id).toString();
    }
  }
  
  protected int mapInOut(final Network network) {
    int _xblockexpression = (int) 0;
    {
      int index = 0;
      HashMap<Port, Integer> _hashMap = new HashMap<Port, Integer>();
      this.inputMap = _hashMap;
      HashMap<Port, Integer> _hashMap_1 = new HashMap<Port, Integer>();
      this.outputMap = _hashMap_1;
      this.fifoNum = 0;
      EList<Port> _inputs = network.getInputs();
      for (final Port input : _inputs) {
        {
          this.inputMap.put(input, Integer.valueOf(index));
          index = (index + 1);
        }
      }
      index = 0;
      EList<Port> _outputs = network.getOutputs();
      for (final Port output : _outputs) {
        {
          this.outputMap.put(output, Integer.valueOf(index));
          index = (index + 1);
        }
      }
      int _xifexpression = (int) 0;
      int _size = this.inputMap.size();
      int _size_1 = this.outputMap.size();
      boolean _greaterEqualsThan = (_size >= _size_1);
      if (_greaterEqualsThan) {
        _xifexpression = this.fifoNum = this.inputMap.size();
      } else {
        _xifexpression = this.fifoNum = this.outputMap.size();
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
}
