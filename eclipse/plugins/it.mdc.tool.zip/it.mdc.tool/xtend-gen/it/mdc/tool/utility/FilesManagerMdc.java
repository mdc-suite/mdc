package it.mdc.tool.utility;

import com.google.common.base.Objects;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.Collections;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import net.sf.orcc.util.FilesManager;
import net.sf.orcc.util.Result;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

/**
 * Utility class to manipulate files. It brings everything needed to extract files
 * from a jar plugin to the filesystem, check if 2 files are identical, read/write
 * files, etc.
 */
@SuppressWarnings("all")
public class FilesManagerMdc extends FilesManager {
  private static final int BUFFER_SIZE = 1024;
  
  /**
   * <p>Copy the file or the folder at given <em>path</em> to the given
   * <em>target folder</em>.</p>
   * 
   * <p>It is important to understand that the resource (file or folder) at the given path
   * will be copied <b>into</b> the target folder. For example,
   * <code>extract("/path/to/file.txt", "/home/johndoe")</code> will copy <em>file.txt</em>
   * into <em>/home/johndoe</em>, and <code>extract("/path/to/MyFolder", "/home/johndoe")</code>
   * will create <em>MyFolder</em> directory in <em>/home/johndoe</em> and copy all files
   * from the source folder into it.
   * </p>
   * 
   * @param path The path of the source (folder or file) to copy
   * @param targetFolder The directory where to copy the source element
   * @return A Result object counting exactly how many files have been really
   * 		written, and how many haven't because they were already up-to-date
   * @throws FileNotFoundException If not resource have been found at the given path
   */
  public static Result extract(final String path, final String targetFolder) {
    try {
      Result _xblockexpression = null;
      {
        String _sanitize = FilesManager.sanitize(targetFolder);
        final File targetF = new File(_sanitize);
        final URL url = FilesManagerMdc.getUrl(path);
        boolean _equals = Objects.equal(url, null);
        if (_equals) {
          throw new FileNotFoundException(path);
        }
        Result _xifexpression = null;
        boolean _equals_1 = url.getProtocol().equals("jar");
        if (_equals_1) {
          Result _xblockexpression_1 = null;
          {
            final String[] splittedURL = url.getFile().split("!");
            String _head = IterableExtensions.<String>head(((Iterable<String>)Conversions.doWrapArray(splittedURL)));
            final URI fileUri = new URI(_head);
            File _file = new File(fileUri);
            final JarFile jar = new JarFile(_file);
            _xblockexpression_1 = FilesManagerMdc.jarExtract(jar, IterableExtensions.<String>last(((Iterable<String>)Conversions.doWrapArray(splittedURL))), targetF);
          }
          _xifexpression = _xblockexpression_1;
        } else {
          URI _uRI = FilesManagerMdc.getUrl(path).toURI();
          File _file = new File(_uRI);
          _xifexpression = FilesManagerMdc.fsExtract(_file, targetF);
        }
        _xblockexpression = _xifexpression;
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  /**
   * Copy the given <i>source</i> directory and its content into
   * the given <em>targetFolder</em> directory.
   * 
   * @param source
   * 			The source path of an existing file
   * @param targetFolder
   * 			Path to the folder where source will be copied
   */
  private static Result fsDirectoryExtract(final File source, final File targetFolder) {
    Assert.isTrue(source.isDirectory());
    boolean _exists = targetFolder.exists();
    boolean _not = (!_exists);
    if (_not) {
      Assert.isTrue(targetFolder.mkdirs());
    } else {
      Assert.isTrue(targetFolder.isDirectory());
    }
    final Result result = Result.newInstance();
    File[] _listFiles = source.listFiles();
    for (final File file : _listFiles) {
      result.merge(
        FilesManagerMdc.fsExtract(file, targetFolder));
    }
    return result;
  }
  
  /**
   * Copy the given <i>source</i> file to the given <em>targetFile</em>
   * path.
   * 
   * @param source
   * 			An existing File instance
   * @param targetFolder
   * 			The target folder to copy the file
   */
  private static Result fsExtract(final File source, final File targetFolder) {
    try {
      Result _xblockexpression = null;
      {
        boolean _exists = source.exists();
        boolean _not = (!_exists);
        if (_not) {
          String _path = source.getPath();
          throw new FileNotFoundException(_path);
        }
        String _name = source.getName();
        final File target = new File(targetFolder, _name);
        Result _xifexpression = null;
        boolean _isFile = source.isFile();
        if (_isFile) {
          Result _xifexpression_1 = null;
          boolean _isContentEqual = FilesManager.isContentEqual(source, target);
          if (_isContentEqual) {
            _xifexpression_1 = Result.newCachedInstance();
          } else {
            _xifexpression_1 = FilesManagerMdc.streamExtract(new FileInputStream(source), target);
          }
          _xifexpression = _xifexpression_1;
        } else {
          Result _xifexpression_2 = null;
          boolean _isDirectory = source.isDirectory();
          if (_isDirectory) {
            _xifexpression_2 = FilesManagerMdc.fsDirectoryExtract(source, target);
          }
          _xifexpression = _xifexpression_2;
        }
        _xblockexpression = _xifexpression;
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  /**
   * Extract all files in the given <em>entry</em> from the given <em>jar</em> into
   * the <em>target folder</em>.
   */
  private static Result jarDirectoryExtract(final JarFile jar, final JarEntry entry, final File targetFolder) {
    final String prefix = entry.getName();
    final Function1<JarEntry, Boolean> _function = new Function1<JarEntry, Boolean>() {
      @Override
      public Boolean apply(final JarEntry it) {
        return Boolean.valueOf(it.getName().startsWith(prefix));
      }
    };
    final Iterable<JarEntry> entries = IterableExtensions.<JarEntry>filter(Collections.<JarEntry>list(jar.entries()), _function);
    final Result result = Result.newInstance();
    for (final JarEntry e : entries) {
      String _substring = e.getName().substring(prefix.length());
      File _file = new File(targetFolder, _substring);
      result.merge(
        FilesManagerMdc.jarFileExtract(jar, e, _file));
    }
    return result;
  }
  
  /**
   * Starting point for extraction of a file/folder resource from a jar.
   */
  private static Result jarExtract(final JarFile jar, final String path, final File targetFolder) {
    Result _xblockexpression = null;
    {
      String _xifexpression = null;
      boolean _startsWith = path.startsWith("/");
      if (_startsWith) {
        _xifexpression = path.substring(1);
      } else {
        _xifexpression = path;
      }
      final String updatedPath = _xifexpression;
      final JarEntry entry = jar.getJarEntry(updatedPath);
      String _xifexpression_1 = null;
      boolean _endsWith = entry.getName().endsWith("/");
      if (_endsWith) {
        String _name = entry.getName();
        int _length = entry.getName().length();
        int _minus = (_length - 1);
        _xifexpression_1 = _name.substring(0, _minus);
      } else {
        _xifexpression_1 = entry.getName();
      }
      final String name = _xifexpression_1;
      String _xifexpression_2 = null;
      int _lastIndexOf = name.lastIndexOf("/");
      boolean _notEquals = (_lastIndexOf != (-1));
      if (_notEquals) {
        _xifexpression_2 = name.substring(name.lastIndexOf("/"));
      } else {
        _xifexpression_2 = name;
      }
      final String fileName = _xifexpression_2;
      Result _xifexpression_3 = null;
      boolean _isDirectory = entry.isDirectory();
      if (_isDirectory) {
        File _file = new File(targetFolder, fileName);
        _xifexpression_3 = FilesManagerMdc.jarDirectoryExtract(jar, entry, _file);
      } else {
        Result _xblockexpression_1 = null;
        {
          final Function1<JarEntry, Boolean> _function = new Function1<JarEntry, Boolean>() {
            @Override
            public Boolean apply(final JarEntry it) {
              return Boolean.valueOf(name.startsWith(updatedPath));
            }
          };
          final Iterable<JarEntry> entries = IterableExtensions.<JarEntry>filter(Collections.<JarEntry>list(jar.entries()), _function);
          Result _xifexpression_4 = null;
          int _size = IterableExtensions.size(entries);
          boolean _greaterThan = (_size > 1);
          if (_greaterThan) {
            File _file_1 = new File(targetFolder, fileName);
            _xifexpression_4 = FilesManagerMdc.jarDirectoryExtract(jar, entry, _file_1);
          } else {
            File _file_2 = new File(targetFolder, fileName);
            _xifexpression_4 = FilesManagerMdc.jarFileExtract(jar, entry, _file_2);
          }
          _xblockexpression_1 = _xifexpression_4;
        }
        _xifexpression_3 = _xblockexpression_1;
      }
      _xblockexpression = _xifexpression_3;
    }
    return _xblockexpression;
  }
  
  /**
   * Extract the file <em>entry</em> from the given <em>jar</em> into the <em>target
   * file</em>.
   */
  private static Result jarFileExtract(final JarFile jar, final JarEntry entry, final File targetFile) {
    try {
      Result _xblockexpression = null;
      {
        targetFile.getParentFile().mkdirs();
        boolean _isDirectory = entry.isDirectory();
        if (_isDirectory) {
          targetFile.mkdir();
          return Result.newInstance();
        }
        Result _xifexpression = null;
        boolean _isContentEqual = FilesManager.isContentEqual(jar.getInputStream(entry), targetFile);
        if (_isContentEqual) {
          _xifexpression = Result.newCachedInstance();
        } else {
          _xifexpression = FilesManagerMdc.streamExtract(jar.getInputStream(entry), targetFile);
        }
        _xblockexpression = _xifexpression;
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  /**
   * Copy the content represented by the given <em>inputStream</em> into the
   * <em>target file</em>. No checking is performed for equality between input
   * stream and target file. Data are always written.
   * 
   * @return A Result object with information about extraction status
   */
  private static Result streamExtract(final InputStream inputStream, final File targetFile) {
    try {
      boolean _exists = targetFile.getParentFile().exists();
      boolean _not = (!_exists);
      if (_not) {
        targetFile.getParentFile().mkdirs();
      }
      final BufferedInputStream bufferedInput = new BufferedInputStream(inputStream);
      FileOutputStream _fileOutputStream = new FileOutputStream(targetFile);
      final BufferedOutputStream outputStream = new BufferedOutputStream(_fileOutputStream);
      final byte[] buffer = new byte[FilesManagerMdc.BUFFER_SIZE];
      int readLength = 0;
      while (((readLength = bufferedInput.read(buffer)) != (-1))) {
        outputStream.write(buffer, 0, readLength);
      }
      bufferedInput.close();
      outputStream.close();
      return Result.newOkInstance();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  /**
   * Search on the file system for a file or folder corresponding to the
   * given path. If not found, search on the current classpath. If this method
   * returns an URL, it always represents an existing file.
   * 
   * @param path
   * 			A path
   * @return
   * 			An URL for an existing file, or null
   */
  public static URL getUrl(final String path) {
    try {
      URL _xblockexpression = null;
      {
        final String sanitizedPath = FilesManager.sanitize(path);
        final File file = new File(sanitizedPath);
        boolean _exists = file.exists();
        if (_exists) {
          return file.toURI().toURL();
        }
        final Bundle bundle = FrameworkUtil.getBundle(FilesManager.class);
        URL _xifexpression = null;
        boolean _notEquals = (!Objects.equal(bundle, null));
        if (_notEquals) {
          URL _xblockexpression_1 = null;
          {
            final Bundle[] bundles = bundle.getBundleContext().getBundles();
            final Function1<Bundle, Boolean> _function = new Function1<Bundle, Boolean>() {
              @Override
              public Boolean apply(final Bundle it) {
                return Boolean.valueOf((it.getSymbolicName().contains("orcc") || it.getSymbolicName().contains("mdc")));
              }
            };
            final Function1<Bundle, URL> _function_1 = new Function1<Bundle, URL>() {
              @Override
              public URL apply(final Bundle it) {
                return it.getEntry(path);
              }
            };
            final Function1<URL, Boolean> _function_2 = new Function1<URL, Boolean>() {
              @Override
              public Boolean apply(final URL it) {
                return Boolean.valueOf((!Objects.equal(it, null)));
              }
            };
            _xblockexpression_1 = IterableExtensions.<URL>findFirst(IterableExtensions.<Bundle, URL>map(IterableExtensions.<Bundle>filter(((Iterable<Bundle>)Conversions.doWrapArray(bundles)), _function), _function_1), _function_2);
          }
          _xifexpression = _xblockexpression_1;
        } else {
          _xifexpression = FilesManager.class.getResource(path);
        }
        final URL url = _xifexpression;
        URL _xifexpression_1 = null;
        String _protocol = null;
        if (url!=null) {
          _protocol=url.getProtocol();
        }
        String _lowerCase = null;
        if (_protocol!=null) {
          _lowerCase=_protocol.toLowerCase();
        }
        boolean _contains = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList("bundle", "bundleresource", "bundleentry")).contains(_lowerCase);
        if (_contains) {
          _xifexpression_1 = FileLocator.resolve(url);
        } else {
          _xifexpression_1 = url;
        }
        _xblockexpression = _xifexpression_1;
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
