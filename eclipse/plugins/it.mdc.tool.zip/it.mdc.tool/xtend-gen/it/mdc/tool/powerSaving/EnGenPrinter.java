package it.mdc.tool.powerSaving;

import it.mdc.tool.core.ConfigManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IntegerRange;

/**
 * A Verilog Logic Regions Enable Generator printer
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class EnGenPrinter {
  /**
   * Map of instances for each LR
   */
  private Map<String, Set<String>> logicRegions;
  
  /**
   * Map with one ID for each LR
   */
  private Map<String, Integer> logicRegionID;
  
  /**
   * List of input networks
   */
  private List<String> networks;
  
  /**
   * Config Manager description
   */
  private ConfigManager configManager;
  
  private Map<String, Set<String>> networksInstances;
  
  /**
   * Set of switchable LRs
   */
  private Set<String> powerSets;
  
  /**
   * Map with one ID for each switchable LR
   */
  private Map<String, Integer> powerSetsIndex;
  
  /**
   * Map of LRs for each network
   */
  private Map<String, Set<String>> netRegions;
  
  /**
   * For each Logic Regions in this map, the key value is true if the LR is sequential, and false if LR is purely combinatorial
   */
  private Map<String, Boolean> logicRegionsSeqMap;
  
  public CharSequence headerComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Enable Generator module ");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.append("\t\t");
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printBody() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("reg [");
    int _size = this.powerSetsIndex.size();
    int _minus = (_size - 1);
    _builder.append(_minus);
    _builder.append(" : 0] clocks_en;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("// case ID");
    _builder.newLine();
    _builder.append("always@(posedge clock_in)");
    _builder.newLine();
    _builder.append("case(ID)");
    _builder.newLine();
    {
      for(final String network : this.networks) {
        _builder.append("8\'d");
        int _networkId = this.configManager.getNetworkId(network);
        _builder.append(_networkId);
        _builder.append(":\tbegin   // ");
        _builder.append(network);
        _builder.newLineIfNotEmpty();
        {
          for(final String lr : this.powerSets) {
            {
              Boolean _get = this.logicRegionsSeqMap.get(lr);
              if ((_get).booleanValue()) {
                _builder.append("clocks_en[");
                Integer _get_1 = this.powerSetsIndex.get(lr);
                _builder.append(_get_1);
                _builder.append("] = ");
                {
                  boolean _contains = this.netRegions.get(network).contains(lr);
                  if (_contains) {
                    _builder.append("1");
                  } else {
                    _builder.append("0");
                  }
                }
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("\t\t");
        _builder.append("end");
        _builder.newLine();
      }
    }
    _builder.append("default:\tclocks_en=");
    int _size_1 = this.powerSetsIndex.size();
    _builder.append(_size_1);
    _builder.append("\'d");
    int _size_2 = this.powerSetsIndex.size();
    int _doubleLessThan = (1 << _size_2);
    int _minus_1 = (_doubleLessThan - 1);
    _builder.append(_minus_1);
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("endcase");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printSignals() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("// Input");
    _builder.newLine();
    _builder.append("input clock_in;");
    _builder.newLine();
    _builder.append("input [7 : 0] ID;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// Ouptut(s)");
    _builder.newLine();
    _builder.append("output [");
    int _size = this.powerSetsIndex.size();
    int _minus = (_size - 1);
    _builder.append(_minus);
    _builder.append(" : 0] clocks_en;");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printInterface(final Network network) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("module enable_generator(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("clocks_en,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("clock_in,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("ID");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printEnGen(final Network network, final ConfigManager configManager, final Map<String, Set<String>> clockSets, final Map<String, Set<String>> networksInstances, final Map<String, Integer> clockDomainsIndex, final Set<String> powerSets, final Map<String, Set<String>> netRegions, final Map<String, Integer> powerSetsIndex, final Map<String, Boolean> logicRegionsSeqMap) {
    CharSequence _xblockexpression = null;
    {
      this.configManager = configManager;
      ArrayList<String> _arrayList = new ArrayList<String>();
      this.networks = _arrayList;
      this.networks.addAll(networksInstances.keySet());
      this.logicRegions = clockSets;
      this.logicRegionID = clockDomainsIndex;
      this.networksInstances = networksInstances;
      this.powerSets = powerSets;
      this.netRegions = netRegions;
      this.powerSetsIndex = powerSetsIndex;
      this.logicRegionsSeqMap = logicRegionsSeqMap;
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _headerComments = this.headerComments();
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printInterface = this.printInterface(network);
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printSignals = this.printSignals();
      _builder.append(_printSignals);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printBody = this.printBody();
      _builder.append(_printBody);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public void sortClockSetIDs() {
    Map<String, String> setsMap = new HashMap<String, String>();
    int _size = this.logicRegions.size();
    int _minus = (_size - 1);
    IntegerRange _upTo = new IntegerRange(0, _minus);
    for (final int index : _upTo) {
      boolean _containsKey = this.logicRegions.containsKey(Integer.valueOf(index));
      boolean _not = (!_containsKey);
      if (_not) {
        Set<String> _keySet = this.logicRegions.keySet();
        for (final String otherIndex : _keySet) {
          int _parseInt = Integer.parseInt(otherIndex);
          int _size_1 = this.logicRegions.size();
          boolean _lessThan = (_parseInt < _size_1);
          boolean _not_1 = (!_lessThan);
          if (_not_1) {
            setsMap.put(String.valueOf(index), otherIndex);
            Set<String> _keySet_1 = this.networksInstances.keySet();
            for (final String net : _keySet_1) {
              boolean _contains = this.networksInstances.get(net).contains(otherIndex);
              if (_contains) {
                this.networksInstances.get(net).remove(otherIndex);
                this.networksInstances.get(net).add(String.valueOf(index));
              }
            }
          }
        }
      }
    }
    Set<String> _keySet_2 = setsMap.keySet();
    for (final String index_1 : _keySet_2) {
      {
        this.logicRegions.put(index_1, this.logicRegions.get(setsMap.get(index_1)));
        this.logicRegions.remove(setsMap.get(index_1));
      }
    }
  }
}
