package it.mdc.tool.prototyping;

import it.mdc.tool.core.platformComposer.ProtocolManager;
import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Actor;
import net.sf.orcc.df.Connection;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import net.sf.orcc.graph.Vertex;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Vivado AXI IP Wrapper Printer
 * 
 * @author Tiziana Fanni
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class WrapperPrinter {
  protected ProtocolManager protocolManager;
  
  private Map<Port, Integer> inputMap;
  
  private Map<Port, Integer> outputMap;
  
  private Map<Port, Integer> portMap;
  
  private List<Integer> signals;
  
  private List<SboxLut> luts;
  
  private int portSize;
  
  private int dataSize = 32;
  
  private int outputCounterBits = CoprocessorSpec.LEGACY_OUTPUT_COUNTER_BITS;
  
  private int controlAddressBits = 0;
  
  public int setKv260Profile() {
    int _xblockexpression = (int) 0;
    {
      this.outputCounterBits = CoprocessorSpec.OUTPUT_COUNTER_BITS;
      _xblockexpression = this.controlAddressBits = 16;
    }
    return _xblockexpression;
  }
  
  private Map<String, List<Port>> netPorts;
  
  private boolean dedicatedInterfaces = false;
  
  private String coupling = "";
  
  private boolean enableMonitoring;
  
  private List<String> monList;
  
  public void computeNetsPorts(final Map<String, Map<String, String>> networkVertexMap) {
    LinkedHashMap<String, List<Port>> _linkedHashMap = new LinkedHashMap<String, List<Port>>();
    this.netPorts = _linkedHashMap;
    Set<String> _keySet = networkVertexMap.keySet();
    for (final String net : _keySet) {
      List<Integer> _sort = IterableExtensions.<Integer>sort(this.portMap.values());
      for (final int id : _sort) {
        Set<Port> _keySet_1 = this.portMap.keySet();
        for (final Port port : _keySet_1) {
          boolean _equals = this.portMap.get(port).equals(Integer.valueOf(id));
          if (_equals) {
            boolean _contains = networkVertexMap.get(net).values().contains(port.getName());
            if (_contains) {
              boolean _containsKey = this.netPorts.containsKey(net);
              if (_containsKey) {
                this.netPorts.get(net).add(port);
              } else {
                List<Port> ports = new ArrayList<Port>();
                ports.add(port);
                this.netPorts.put(net, ports);
              }
            }
          }
        }
      }
    }
  }
  
  public int computeSizePointer() {
    boolean _equals = this.coupling.equals("mm");
    if (_equals) {
      if (this.enableMonitoring) {
        int _size = this.portMap.size();
        int _size_1 = this.monList.size();
        int _plus = (_size + _size_1);
        double _log10 = Math.log10(_plus);
        double _log10_1 = Math.log10(2);
        double _divide = (_log10 / _log10_1);
        double _plus_1 = (_divide + 0.5);
        return Math.round(((float) _plus_1));
      } else {
        double _log10_2 = Math.log10(this.portMap.size());
        double _log10_3 = Math.log10(2);
        double _divide_1 = (_log10_2 / _log10_3);
        double _plus_2 = (_divide_1 + 0.5);
        return Math.round(((float) _plus_2));
      }
    } else {
      double _log10_4 = Math.log10(this.outputMap.size());
      double _log10_5 = Math.log10(2);
      double _divide_2 = (_log10_4 / _log10_5);
      double _plus_3 = (_divide_2 + 0.5);
      return Math.round(((float) _plus_3));
    }
  }
  
  public int getDefaultValue(final String portValue) {
    int defaultValue = 0;
    boolean _hasParameter = this.hasParameter(portValue);
    if (_hasParameter) {
      String[] _split = portValue.split("_");
      int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
      int _minus = (_size - 1);
      defaultValue = Integer.parseInt(_split[_minus]);
    } else {
      defaultValue = Integer.parseInt(portValue.split("_")[2]);
    }
    return defaultValue;
  }
  
  public String getDirection(final String portValue) {
    String direction = portValue;
    boolean _contains = portValue.contains("_");
    if (_contains) {
      direction = portValue.split("_")[0];
    }
    return direction;
  }
  
  public Map<Port, Integer> getInputMap() {
    return this.inputMap;
  }
  
  public String getLongId(final int id) {
    if ((id < 10)) {
      String _string = Integer.valueOf(id).toString();
      return ("0" + _string);
    } else {
      return Integer.valueOf(id).toString();
    }
  }
  
  public Map<Port, Integer> getOutputMap() {
    return this.outputMap;
  }
  
  public String getParameter(final String portValue) {
    String parameter = "";
    int i = 2;
    int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
    boolean _equals = (_size == 4);
    if (_equals) {
      parameter = portValue.split("_")[2];
    } else {
      while ((i < (((List<String>)Conversions.doWrapArray(portValue.split("_"))).size() - 1))) {
        {
          boolean _equals_1 = parameter.equals("");
          if (_equals_1) {
            String _get = portValue.split("_")[i];
            String _plus = (parameter + _get);
            parameter = _plus;
          } else {
            String _get_1 = portValue.split("_")[i];
            String _plus_1 = ((parameter + "_") + _get_1);
            parameter = _plus_1;
          }
          i = (i + 1);
        }
      }
    }
    return parameter;
  }
  
  public Integer getPortIdFromName(final String name) {
    Set<Port> _keySet = this.portMap.keySet();
    for (final Port port : _keySet) {
      boolean _equals = port.getName().equals(name);
      if (_equals) {
        return this.portMap.get(port);
      }
    }
    return null;
  }
  
  public Map<Port, Integer> getPortMap() {
    return this.portMap;
  }
  
  public String getReverseDirection(final String portValue) {
    String direction = this.getDirection(portValue);
    boolean _equals = direction.equals("in");
    if (_equals) {
      direction = "out";
    } else {
      direction = "in";
    }
    return direction;
  }
  
  public String getSuffix(final Map<String, String> idNameMap, final String id) {
    boolean _containsKey = idNameMap.containsKey(id);
    if (_containsKey) {
      boolean _equals = idNameMap.get(id).equals("");
      if (_equals) {
        return "";
      } else {
        String _get = idNameMap.get(id);
        return ("_" + _get);
      }
    }
    return null;
  }
  
  public boolean hasParameter(final String portValue) {
    boolean result = false;
    int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
    boolean _greaterThan = (_size > 3);
    if (_greaterThan) {
      result = true;
    }
    return result;
  }
  
  public ProtocolManager initWrapperPrinter(final String coupling, final Boolean enableMonitoring, final List<String> monList, final List<SboxLut> luts, final ProtocolManager protocolManager) {
    ProtocolManager _xblockexpression = null;
    {
      this.coupling = coupling;
      this.enableMonitoring = (enableMonitoring).booleanValue();
      this.monList = monList;
      this.luts = luts;
      _xblockexpression = this.protocolManager = protocolManager;
    }
    return _xblockexpression;
  }
  
  public int mapInOut(final Network network) {
    int _xblockexpression = (int) 0;
    {
      int index = 0;
      int size = 0;
      LinkedHashMap<Port, Integer> _linkedHashMap = new LinkedHashMap<Port, Integer>();
      this.inputMap = _linkedHashMap;
      LinkedHashMap<Port, Integer> _linkedHashMap_1 = new LinkedHashMap<Port, Integer>();
      this.outputMap = _linkedHashMap_1;
      LinkedHashMap<Port, Integer> _linkedHashMap_2 = new LinkedHashMap<Port, Integer>();
      this.portMap = _linkedHashMap_2;
      EList<Port> _inputs = network.getInputs();
      for (final Port input : _inputs) {
        {
          this.inputMap.put(input, Integer.valueOf(index));
          this.portMap.put(input, Integer.valueOf(index));
          index = (index + 1);
        }
      }
      index = 0;
      EList<Port> _outputs = network.getOutputs();
      for (final Port output : _outputs) {
        {
          this.outputMap.put(output, Integer.valueOf(index));
          int _size = this.inputMap.size();
          int _plus = (index + _size);
          this.portMap.put(output, Integer.valueOf(_plus));
          index = (index + 1);
        }
      }
      size = Math.max(this.inputMap.size(), this.outputMap.size());
      double _log10 = Math.log10(size);
      double _log10_1 = Math.log10(2);
      double _divide = (_log10 / _log10_1);
      double _plus = (_divide + 0.5);
      _xblockexpression = this.portSize = Math.round(((float) _plus));
    }
    return _xblockexpression;
  }
  
  public void mapSignals() {
    int size = Math.max(this.inputMap.size(), this.outputMap.size());
    int index = 1;
    ArrayList<Integer> _arrayList = new ArrayList<Integer>(size);
    this.signals = _arrayList;
    while ((index <= size)) {
      {
        this.signals.add((index - 1), Integer.valueOf(index));
        index = (index + 1);
      }
    }
  }
  
  public CharSequence printHdlSource(final Network network, final String module) {
    CharSequence _xifexpression = null;
    boolean _equals = module.equals("TOP");
    if (_equals) {
      _xifexpression = this.printTop(network);
    } else {
      CharSequence _xifexpression_1 = null;
      boolean _equals_1 = module.equals("CFG_REGS");
      if (_equals_1) {
        _xifexpression_1 = this.printRegs();
      } else {
        CharSequence _xifexpression_2 = null;
        boolean _equals_2 = module.equals("TBENCH");
        if (_equals_2) {
          _xifexpression_2 = this.printTestBench();
        }
        _xifexpression_1 = _xifexpression_2;
      }
      _xifexpression = _xifexpression_1;
    }
    return _xifexpression;
  }
  
  public CharSequence printRegs() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      int log2_regnumb = this.computeSizePointer();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// This file has been automatically generated by:");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Configuration Registers module");
      _builder.newLine();
      _builder.append("// on ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// More info available at http://sites.unica.it/rpct// ");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------\t");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("module config_registers #(");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Width of S_AXI data bus");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("parameter integer C_S_AXI_DATA_WIDTH\t= 32,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Width of S_AXI address bus");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("parameter integer C_S_AXI_ADDR_WIDTH\t= ");
      _builder.append((log2_regnumb + 2), "\t");
      _builder.newLineIfNotEmpty();
      _builder.append(")");
      _builder.newLine();
      _builder.append("(");
      _builder.newLine();
      {
        boolean _equals = this.coupling.equals("mm");
        if (_equals) {
          _builder.append("\t");
          _builder.append("input done,");
          _builder.newLine();
          {
            if (this.enableMonitoring) {
              {
                for(final String monitor : this.monList) {
                  _builder.append("\t");
                  _builder.append("// Monitor ");
                  int _indexOf = this.monList.indexOf(monitor);
                  _builder.append(_indexOf, "\t");
                  _builder.append(": ");
                  _builder.append(monitor, "\t");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("input [C_S_AXI_DATA_WIDTH - 1 : 0] ");
                  _builder.append(monitor, "\t");
                  _builder.append(",");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("output clear_monitor_");
                  int _indexOf_1 = this.monList.indexOf(monitor);
                  _builder.append(_indexOf_1, "\t");
                  _builder.append(",");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.append("\t");
          _builder.append("// Config Regs");
          _builder.newLine();
          {
            Set<Port> _keySet = this.portMap.keySet();
            for(final Port port : _keySet) {
              _builder.append("\t");
              _builder.append("output reg [C_S_AXI_DATA_WIDTH-1:0]    slv_reg");
              Integer _get = this.portMap.get(port);
              int _plus = ((_get).intValue() + 1);
              _builder.append(_plus, "\t");
              _builder.append(",");
              _builder.newLineIfNotEmpty();
            }
          }
          {
            if (this.enableMonitoring) {
              _builder.append("\t");
              _builder.append("// Monitoring Config Registers");
              _builder.newLine();
              {
                for(final String monitor_1 : this.monList) {
                  _builder.append("\t");
                  _builder.append("output reg [C_S_AXI_DATA_WIDTH-1:0]    slv_reg");
                  int _size = this.portMap.size();
                  int _plus_1 = (_size + 1);
                  int _indexOf_2 = this.monList.indexOf(monitor_1);
                  int _plus_2 = (_plus_1 + _indexOf_2);
                  _builder.append(_plus_2, "\t");
                  _builder.append(",");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.append("\t");
          _builder.append("output start,");
          _builder.newLine();
        } else {
          _builder.append("\t");
          {
            Set<Port> _keySet_1 = this.outputMap.keySet();
            for(final Port output : _keySet_1) {
              _builder.append("output reg [C_S_AXI_DATA_WIDTH-1:0]    slv_reg");
              Integer _get_1 = this.outputMap.get(output);
              int _plus_3 = ((_get_1).intValue() + 1);
              _builder.append(_plus_3, "\t");
              _builder.append(",");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.append("output reg [C_S_AXI_DATA_WIDTH-1:0]    slv_reg0,");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Global Clock Signal");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_ACLK,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Global Reset Signal. This Signal is Active LOW");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_ARESETN,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write address (issued by master, acceped by Slave)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [C_S_AXI_ADDR_WIDTH-1 : 0] S_AXI_AWADDR,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write channel Protection type. This signal indicates the");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// privilege and security level of the transaction, and whether");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// the transaction is a data access or an instruction access.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [2 : 0] S_AXI_AWPROT,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write address valid. This signal indicates that the master signaling");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// valid write address and control information.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_AWVALID,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write address ready. This signal indicates that the slave is ready");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// to accept an address and associated control signals.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire  S_AXI_AWREADY,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write data (issued by master, acceped by Slave) ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [C_S_AXI_DATA_WIDTH-1 : 0] S_AXI_WDATA,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write strobes. This signal indicates which byte lanes hold");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// valid data. There is one write strobe bit for each eight");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// bits of the write data bus.    ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [(C_S_AXI_DATA_WIDTH/8)-1 : 0] S_AXI_WSTRB,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write valid. This signal indicates that valid write");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// data and strobes are available.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_WVALID,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write ready. This signal indicates that the slave");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// can accept the write data.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire  S_AXI_WREADY,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write response. This signal indicates the status");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// of the write transaction.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire [1 : 0] S_AXI_BRESP,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write response valid. This signal indicates that the channel");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// is signaling a valid write response.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire  S_AXI_BVALID,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Response ready. This signal indicates that the master");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// can accept a write response.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_BREADY,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read address (issued by master, acceped by Slave)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [C_S_AXI_ADDR_WIDTH-1 : 0] S_AXI_ARADDR,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Protection type. This signal indicates the privilege");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// and security level of the transaction, and whether the");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// transaction is a data access or an instruction access.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire [2 : 0] S_AXI_ARPROT,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read address valid. This signal indicates that the channel");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// is signaling valid read address and control information.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_ARVALID,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read address ready. This signal indicates that the slave is");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ready to accept an address and associated control signals.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire  S_AXI_ARREADY,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read data (issued by slave)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire [C_S_AXI_DATA_WIDTH-1 : 0] S_AXI_RDATA,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read response. This signal indicates the status of the");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// read transfer.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire [1 : 0] S_AXI_RRESP,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read valid. This signal indicates that the channel is");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// signaling the required read data.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("output wire  S_AXI_RVALID,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Read ready. This signal indicates that the master can");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// accept the read data and response information.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("input wire  S_AXI_RREADY");
      _builder.newLine();
      _builder.append(");");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// AXI4LITE signals");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [C_S_AXI_ADDR_WIDTH-1 : 0] \taxi_awaddr;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg  \taxi_awready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg  \taxi_wready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [1 : 0] \taxi_bresp;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg  \taxi_bvalid;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [C_S_AXI_ADDR_WIDTH-1 : 0] \taxi_araddr;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg  \taxi_arready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [C_S_AXI_DATA_WIDTH-1 : 0] \taxi_rdata;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [1 : 0] \taxi_rresp;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg  \taxi_rvalid;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Example-specific design signals");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// local parameter for addressing 32 bit / 64 bit C_S_AXI_DATA_WIDTH");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ADDR_LSB is used for addressing 32/64 bit registers/memories");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ADDR_LSB = 2 for 32 bits (n downto 2)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// ADDR_LSB = 3 for 64 bits (n downto 3)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("localparam integer ADDR_LSB = (C_S_AXI_DATA_WIDTH/32) + 1;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("localparam integer OPT_MEM_ADDR_BITS = ");
      _builder.append(log2_regnumb, "\t");
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//----------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//-- Signals for user logic register space example");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//------------------------------------------------");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("wire\t slv_reg_rden;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("wire\t slv_reg_wren;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("reg [C_S_AXI_DATA_WIDTH-1:0]\t reg_data_out;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("integer\t byte_index;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// I/O Connections assignments");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_AWREADY\t= axi_awready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_WREADY\t= axi_wready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_BRESP\t= axi_bresp;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_BVALID\t= axi_bvalid;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_ARREADY\t= axi_arready;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_RDATA\t= axi_rdata;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_RRESP\t= axi_rresp;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign S_AXI_RVALID\t= axi_rvalid;");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement axi_awready generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// axi_awready is asserted for one S_AXI_ACLK clock cycle when both");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_awready is");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// de-asserted when reset is low.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_awready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// slave is ready to accept write address when ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// there is a valid write address and write data");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// on the write address and data bus. This design ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// expects no outstanding transactions. ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_awready <= 1\'b1;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("else           ");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_awready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement axi_awaddr latching");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// This process is used to latch the address when both ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// S_AXI_AWVALID and S_AXI_WVALID are valid. ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_awaddr <= 0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// Write Address latching ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_awaddr <= S_AXI_AWADDR;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement axi_wready generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// axi_wready is asserted for one S_AXI_ACLK clock cycle when both");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// S_AXI_AWVALID and S_AXI_WVALID are asserted. axi_wready is ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// de-asserted when reset is low. ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_wready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (~axi_wready && S_AXI_WVALID && S_AXI_AWVALID)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// slave is ready to accept write data when ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// there is a valid write address and write data");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// on the write address and data bus. This design ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// expects no outstanding transactions. ");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_wready <= 1\'b1;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_wready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("// Implement memory mapped register select and write logic generation");
      _builder.newLine();
      _builder.append("// The write data is accepted and written to memory mapped registers when");
      _builder.newLine();
      _builder.append("// axi_awready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted. Write strobes are used to");
      _builder.newLine();
      _builder.append("// select byte enables of slave registers while writing.");
      _builder.newLine();
      _builder.append("// These registers are cleared when reset (active low) is applied.");
      _builder.newLine();
      _builder.append("// Slave register write enable is asserted when valid address and data are available");
      _builder.newLine();
      _builder.append("// and the slave is ready to accept the write address and write data.");
      _builder.newLine();
      _builder.append("assign slv_reg_wren = axi_wready && S_AXI_WVALID && axi_awready && S_AXI_AWVALID;");
      _builder.newLine();
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("begin");
      _builder.newLine();
      _builder.append("  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("    ");
      _builder.append("slv_reg0 <=  32\'d4; //inizialize the accelerator as ready");
      _builder.newLine();
      {
        boolean _equals_1 = this.coupling.equals("mm");
        if (_equals_1) {
          {
            Set<Port> _keySet_2 = this.portMap.keySet();
            for(final Port port_1 : _keySet_2) {
              _builder.append("      ");
              _builder.append("slv_reg");
              Integer _get_2 = this.portMap.get(port_1);
              int _plus_4 = ((_get_2).intValue() + 1);
              _builder.append(_plus_4, "      ");
              _builder.append(" <= 0;");
              _builder.newLineIfNotEmpty();
            }
          }
          {
            if (this.enableMonitoring) {
              {
                for(final String monitor_2 : this.monList) {
                  _builder.append("slv_reg");
                  int _size_1 = this.portMap.size();
                  int _plus_5 = (_size_1 + 1);
                  int _indexOf_3 = this.monList.indexOf(monitor_2);
                  int _plus_6 = (_plus_5 + _indexOf_3);
                  _builder.append(_plus_6);
                  _builder.append(" <= 0;");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
        } else {
          {
            Set<Port> _keySet_3 = this.outputMap.keySet();
            for(final Port output_1 : _keySet_3) {
              _builder.append("      ");
              _builder.append("slv_reg");
              Integer _get_3 = this.outputMap.get(output_1);
              int _plus_7 = ((_get_3).intValue() + 1);
              _builder.append(_plus_7, "      ");
              _builder.append(" <= 0;");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("else begin");
      _builder.newLine();
      {
        boolean _equals_2 = this.coupling.equals("mm");
        if (_equals_2) {
          _builder.append("\t");
          _builder.append("if (done)");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("\t");
          _builder.append("slv_reg0 <= {slv_reg0[31:3],1\'b1,slv_reg0[1:0]};");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("else");
          _builder.newLine();
        }
      }
      _builder.append("\t");
      _builder.append("if (slv_reg_wren)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("case ( axi_awaddr[ADDR_LSB+OPT_MEM_ADDR_BITS-1:ADDR_LSB] )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(log2_regnumb, "\t");
      _builder.append("\'h0:");
      _builder.newLineIfNotEmpty();
      _builder.append("\t");
      _builder.append("for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("if ( S_AXI_WSTRB[byte_index] == 1 ) begin");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Respective byte enables are asserted as per write strobes ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Slave register 0");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("slv_reg0[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      {
        boolean _equals_3 = this.coupling.equals("mm");
        if (_equals_3) {
          {
            Set<Port> _keySet_4 = this.portMap.keySet();
            for(final Port port_2 : _keySet_4) {
              _builder.append("\t\t");
              _builder.append(log2_regnumb);
              _builder.append("\'h");
              Integer _get_4 = this.portMap.get(port_2);
              int _plus_8 = ((_get_4).intValue() + 1);
              _builder.append(_plus_8);
              _builder.append(":");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("if ( S_AXI_WSTRB[byte_index] == 1 ) begin");
              _builder.newLine();
              _builder.append("    \t");
              _builder.append("// Respective byte enables are asserted as per write strobes");
              _builder.newLine();
              _builder.append("    \t");
              _builder.append("// Slave register ");
              Integer _get_5 = this.portMap.get(port_2);
              int _plus_9 = ((_get_5).intValue() + 1);
              _builder.append(_plus_9, "    \t");
              _builder.newLineIfNotEmpty();
              _builder.append("    \t");
              _builder.append("slv_reg");
              Integer _get_6 = this.portMap.get(port_2);
              int _plus_10 = ((_get_6).intValue() + 1);
              _builder.append(_plus_10, "    \t");
              _builder.append("[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];");
              _builder.newLineIfNotEmpty();
              _builder.append("    \t");
              _builder.append("end");
              _builder.newLine();
            }
          }
          {
            if (this.enableMonitoring) {
              {
                for(final String monitor_3 : this.monList) {
                  _builder.append("    \t");
                  _builder.append(log2_regnumb);
                  _builder.append("\'h");
                  int _size_2 = this.portMap.size();
                  int _plus_11 = (_size_2 + 1);
                  int _indexOf_4 = this.monList.indexOf(monitor_3);
                  int _plus_12 = (_plus_11 + _indexOf_4);
                  _builder.append(_plus_12);
                  _builder.append(":\t");
                  _builder.newLineIfNotEmpty();
                  _builder.append("\t");
                  _builder.append("for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )");
                  _builder.newLine();
                  _builder.append("\t\t");
                  _builder.append("if ( S_AXI_WSTRB[byte_index] == 1 ) begin");
                  _builder.newLine();
                  _builder.append("    \t\t");
                  _builder.append("// Respective byte enables are asserted as per write strobes");
                  _builder.newLine();
                  _builder.append("    \t\t");
                  _builder.append("// Slave register ");
                  int _size_3 = this.portMap.size();
                  int _plus_13 = (_size_3 + 1);
                  int _indexOf_5 = this.monList.indexOf(monitor_3);
                  int _plus_14 = (_plus_13 + _indexOf_5);
                  _builder.append(_plus_14, "    \t\t");
                  _builder.newLineIfNotEmpty();
                  _builder.append("    \t\t");
                  _builder.append("slv_reg");
                  int _size_4 = this.portMap.size();
                  int _plus_15 = (_size_4 + 1);
                  int _indexOf_6 = this.monList.indexOf(monitor_3);
                  int _plus_16 = (_plus_15 + _indexOf_6);
                  _builder.append(_plus_16, "    \t\t");
                  _builder.append("[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];");
                  _builder.newLineIfNotEmpty();
                  _builder.append("    \t");
                  _builder.append("end");
                  _builder.newLine();
                }
              }
            }
          }
        } else {
          {
            Set<Port> _keySet_5 = this.outputMap.keySet();
            for(final Port output_2 : _keySet_5) {
              _builder.append("\t\t");
              _builder.append(log2_regnumb);
              _builder.append("\'h");
              Integer _get_7 = this.outputMap.get(output_2);
              int _plus_17 = ((_get_7).intValue() + 1);
              _builder.append(_plus_17);
              _builder.append(":");
              _builder.newLineIfNotEmpty();
              _builder.append("\t\t");
              _builder.append("for ( byte_index = 0; byte_index <= (C_S_AXI_DATA_WIDTH/8)-1; byte_index = byte_index+1 )");
              _builder.newLine();
              _builder.append("\t\t\t");
              _builder.append("if ( S_AXI_WSTRB[byte_index] == 1 ) begin");
              _builder.newLine();
              _builder.append("    \t\t");
              _builder.append("// Respective byte enables are asserted as per write strobes");
              _builder.newLine();
              _builder.append("    \t\t");
              _builder.append("// Slave register ");
              Integer _get_8 = this.outputMap.get(output_2);
              int _plus_18 = ((_get_8).intValue() + 1);
              _builder.append(_plus_18, "    \t\t");
              _builder.newLineIfNotEmpty();
              _builder.append("    \t\t");
              _builder.append("slv_reg");
              Integer _get_9 = this.outputMap.get(output_2);
              int _plus_19 = ((_get_9).intValue() + 1);
              _builder.append(_plus_19, "    \t\t");
              _builder.append("[(byte_index*8) +: 8] <= S_AXI_WDATA[(byte_index*8) +: 8];");
              _builder.newLineIfNotEmpty();
              _builder.append("    \t\t");
              _builder.append("end");
              _builder.newLine();
              _builder.append("    \t");
              _builder.newLine();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.append("default : begin");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("slv_reg0 <= slv_reg0;");
      _builder.newLine();
      {
        boolean _equals_4 = this.coupling.equals("mm");
        if (_equals_4) {
          {
            Set<Port> _keySet_6 = this.portMap.keySet();
            for(final Port port_3 : _keySet_6) {
              _builder.append("\t");
              _builder.append("slv_reg");
              Integer _get_10 = this.portMap.get(port_3);
              int _plus_20 = ((_get_10).intValue() + 1);
              _builder.append(_plus_20, "\t");
              _builder.append(" <= slv_reg");
              Integer _get_11 = this.portMap.get(port_3);
              int _plus_21 = ((_get_11).intValue() + 1);
              _builder.append(_plus_21, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          {
            for(final String monitor_4 : this.monList) {
              _builder.append("\t");
              _builder.append("slv_reg");
              int _size_5 = this.portMap.size();
              int _plus_22 = (_size_5 + 1);
              int _indexOf_7 = this.monList.indexOf(monitor_4);
              int _plus_23 = (_plus_22 + _indexOf_7);
              _builder.append(_plus_23, "\t");
              _builder.append(" <= slv_reg");
              int _size_6 = this.portMap.size();
              int _plus_24 = (_size_6 + 1);
              int _indexOf_8 = this.monList.indexOf(monitor_4);
              int _plus_25 = (_plus_24 + _indexOf_8);
              _builder.append(_plus_25, "\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
        } else {
          {
            Set<Port> _keySet_7 = this.outputMap.keySet();
            for(final Port output_3 : _keySet_7) {
              _builder.append("slv_reg");
              Integer _get_12 = this.outputMap.get(output_3);
              int _plus_26 = ((_get_12).intValue() + 1);
              _builder.append(_plus_26);
              _builder.append(" <= slv_reg");
              Integer _get_13 = this.outputMap.get(output_3);
              int _plus_27 = ((_get_13).intValue() + 1);
              _builder.append(_plus_27);
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("endcase");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("  ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign start = (slv_reg_wren) && (axi_awaddr[ADDR_LSB+OPT_MEM_ADDR_BITS-1:ADDR_LSB]==0) &&");
      _builder.newLine();
      _builder.append("\t\t\t\t\t");
      _builder.append("(S_AXI_WSTRB[0]==1) && (S_AXI_WDATA[0]==1\'b1);");
      _builder.newLine();
      _builder.append("\t\t\t\t\t");
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          {
            for(final String monitor_5 : this.monList) {
              _builder.append("\t");
              _builder.append("// clear of monitor ");
              _builder.append(monitor_5, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("assign clear_monitor_");
              int _indexOf_9 = this.monList.indexOf(monitor_5);
              _builder.append(_indexOf_9, "\t");
              _builder.append(" = (slv_reg_wren) && (axi_awaddr[ADDR_LSB+OPT_MEM_ADDR_BITS-1:ADDR_LSB]==");
              int _size_7 = this.portMap.size();
              int _plus_28 = (_size_7 + 1);
              int _indexOf_10 = this.monList.indexOf(monitor_5);
              int _plus_29 = (_plus_28 + _indexOf_10);
              _builder.append(_plus_29, "\t");
              _builder.append(") && ");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("\t\t\t\t\t\t");
              _builder.append("(S_AXI_WSTRB[0]==1) && (S_AXI_WDATA[31]==1\'b1);");
              _builder.newLine();
            }
          }
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement write response logic generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// The write response and response valid signals are asserted by the slave ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// when axi_wready, S_AXI_WVALID, axi_wready and S_AXI_WVALID are asserted.  ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// This marks the acceptance of address and indicates the status of ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// write transaction.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_bvalid  <= 0;");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_bresp   <= 2\'b0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (axi_awready && S_AXI_AWVALID && ~axi_bvalid && axi_wready && S_AXI_WVALID)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// indicates a valid write response is available");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_bvalid <= 1\'b1;");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_bresp  <= 2\'b0; // \'OKAY\' response ");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end                   // work error responses in future");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("if (S_AXI_BREADY && axi_bvalid) ");
      _builder.newLine();
      _builder.append("\t            ");
      _builder.append("//check if bready is asserted while bvalid is high) ");
      _builder.newLine();
      _builder.append("\t            ");
      _builder.append("//(there is a possibility that bready is always asserted high)   ");
      _builder.newLine();
      _builder.append("\t            ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t              ");
      _builder.append("axi_bvalid <= 1\'b0; ");
      _builder.newLine();
      _builder.append("\t            ");
      _builder.append("end  ");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement axi_arready generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// axi_arready is asserted for one S_AXI_ACLK clock cycle when");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// S_AXI_ARVALID is asserted. axi_awready is ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// de-asserted when reset (active low) is asserted. ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// The read address is also latched when S_AXI_ARVALID is ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// asserted. axi_araddr is reset to zero on reset assertion.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_arready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_araddr  <= 32\'b0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (~axi_arready && S_AXI_ARVALID)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// indicates that the slave has acceped the valid read address");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_arready <= 1\'b1;");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// Read address latching");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_araddr  <= S_AXI_ARADDR;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_arready <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement axi_arvalid generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// axi_rvalid is asserted for one S_AXI_ACLK clock cycle when both ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// S_AXI_ARVALID and axi_arready are asserted. The slave registers ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// data are available on the axi_rdata bus at this instance. The ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// assertion of axi_rvalid marks the validity of read data on the ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// bus and axi_rresp indicates the status of read transaction.axi_rvalid ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// is deasserted on reset (active low). axi_rresp and axi_rdata are ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// cleared to zero on reset (active low).  ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_rvalid <= 0;");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_rresp  <= 0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (axi_arready && S_AXI_ARVALID && ~axi_rvalid)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// Valid read data is available at the read data bus");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_rvalid <= 1\'b1;");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_rresp  <= 2\'b0; // \'OKAY\' response");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end   ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("else if (axi_rvalid && S_AXI_RREADY)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("// Read data is accepted by the master");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_rvalid <= 1\'b0;");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end                ");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Implement memory mapped register select and read logic generation");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Slave register read enable is asserted when valid address is available");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// and the slave is ready to accept the read address.");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("assign slv_reg_rden = axi_arready & S_AXI_ARVALID & ~axi_rvalid;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @(*)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("// Address decoding for reading registers");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("case ( axi_araddr[ADDR_LSB+OPT_MEM_ADDR_BITS-1:ADDR_LSB] )");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append(log2_regnumb, "\t\t");
      _builder.append("\'h0   : reg_data_out <= slv_reg0;");
      _builder.newLineIfNotEmpty();
      {
        boolean _equals_5 = this.coupling.equals("mm");
        if (_equals_5) {
          {
            Set<Port> _keySet_8 = this.portMap.keySet();
            for(final Port port_4 : _keySet_8) {
              _builder.append("\t\t");
              _builder.append(log2_regnumb, "\t\t");
              _builder.append("\'h");
              Integer _get_14 = this.portMap.get(port_4);
              int _plus_30 = ((_get_14).intValue() + 1);
              _builder.append(_plus_30, "\t\t");
              _builder.append("   : reg_data_out <= slv_reg");
              Integer _get_15 = this.portMap.get(port_4);
              int _plus_31 = ((_get_15).intValue() + 1);
              _builder.append(_plus_31, "\t\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          {
            if (this.enableMonitoring) {
              {
                for(final String monitor_6 : this.monList) {
                  _builder.append("\t\t");
                  _builder.append(log2_regnumb, "\t\t");
                  _builder.append("\'h");
                  int _size_8 = this.portMap.size();
                  int _plus_32 = (_size_8 + 1);
                  int _indexOf_11 = this.monList.indexOf(monitor_6);
                  int _plus_33 = (_plus_32 + _indexOf_11);
                  _builder.append(_plus_33, "\t\t");
                  _builder.append("   : reg_data_out <= ");
                  _builder.append(monitor_6, "\t\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.append("\t\t");
        } else {
          {
            Set<Port> _keySet_9 = this.outputMap.keySet();
            for(final Port output_4 : _keySet_9) {
              _builder.append(log2_regnumb, "\t\t");
              _builder.append("\'h");
              Integer _get_16 = this.outputMap.get(output_4);
              int _plus_34 = ((_get_16).intValue() + 1);
              _builder.append(_plus_34, "\t\t");
              _builder.append("   : reg_data_out <= slv_reg");
              Integer _get_17 = this.outputMap.get(output_4);
              int _plus_35 = ((_get_17).intValue() + 1);
              _builder.append(_plus_35, "\t\t");
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("\t\t");
      _builder.append("default : reg_data_out <= 0;");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("endcase");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Output register or memory read data");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("always @( posedge S_AXI_ACLK )");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("if ( S_AXI_ARESETN == 1\'b0 )");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("axi_rdata  <= 0;");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end ");
      _builder.newLine();
      _builder.append("\t  ");
      _builder.append("else");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("begin    ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("// When there is a valid read address (S_AXI_ARVALID) with ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("// acceptance of read address by the slave (axi_arready), ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("// output the read dada ");
      _builder.newLine();
      _builder.append("\t      ");
      _builder.append("if (slv_reg_rden)");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("begin");
      _builder.newLine();
      _builder.append("\t          ");
      _builder.append("axi_rdata <= reg_data_out;     // register read data");
      _builder.newLine();
      _builder.append("\t        ");
      _builder.append("end   ");
      _builder.newLine();
      _builder.append("\t    ");
      _builder.append("end");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("end");
      _builder.newLine();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printTestBench() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("`timescale 1ns / 1ps");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// This file has been automatically generated by:");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// TIL Test Bench module");
      _builder.newLine();
      _builder.append("// on ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// More info available at http://sites.unica.it/rpct/\t\t");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------\t");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("module tb_copr;");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Parameters");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("parameter SIZEID = 8;\t\t\t\t// size of Kernel ID signal");
      _builder.newLine();
      _builder.append("parameter SIZEADDRESS = 12;\t\t\t// size of the local memory address signal");
      _builder.newLine();
      _builder.append("parameter SIZECOUNT = 12;\t\t\t// size of the size counters");
      _builder.newLine();
      _builder.append("parameter SIZEPORT = ");
      _builder.append(this.portSize);
      _builder.append(";\t// bits needed to codify the number of ports");
      _builder.newLineIfNotEmpty();
      _builder.append("parameter SIZEDATA = ");
      _builder.append(this.dataSize);
      _builder.append(";\t// size of the data signal");
      _builder.newLineIfNotEmpty();
      _builder.append("parameter SIZEBURST = 8;\t\t\t// size of the burst counter");
      _builder.newLine();
      _builder.append("parameter SIZESIGNAL = 1; \t\t\t// size of the control signals");
      _builder.newLine();
      _builder.append("parameter FIFO_DEPTH = 4; \t\t\t\t//\tFIFO depth");
      _builder.newLine();
      _builder.append("parameter f_ptr_width = 5; \t\t\t//\tbecause depth =16 + OVERFLOW");
      _builder.newLine();
      _builder.append("parameter f_half_full_value = 8;\t//");
      _builder.newLine();
      _builder.append("parameter f_almost_full_value = 14;\t//");
      _builder.newLine();
      _builder.append("parameter f_almost_empty_value = 2;\t//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Input Reg(s)");
      _builder.newLine();
      _builder.append("reg clk;");
      _builder.newLine();
      _builder.append("reg rst;");
      _builder.newLine();
      _builder.append("reg [SIZEDATA-1 : 0] \t\tdatain;\t\t// local memory - data in");
      _builder.newLine();
      _builder.append("reg [SIZEADDRESS-1 : 0] \taddressrd;\t// local memory - read address");
      _builder.newLine();
      _builder.append("reg [SIZEADDRESS-1 : 0] \taddresswr; \t// local memory - write address");
      _builder.newLine();
      _builder.append("reg \t\t\t\t\t\tenablerd;\t// local memory - enable read port");
      _builder.newLine();
      _builder.append("reg\t\t\t\t\t\t\tenablewr;   // local memory - enable write port");
      _builder.newLine();
      _builder.append("reg \t\t\t\t\t\twrite;      // local memory - write enable");
      _builder.newLine();
      _builder.append("reg [SIZEID-1 : 0] \t\t\tkernelIDin; // kernel ID");
      _builder.newLine();
      _builder.append("reg \t\t\t\t\t\tkernelIDen;");
      _builder.newLine();
      {
        Set<Port> _keySet = this.portMap.keySet();
        for(final Port port : _keySet) {
          _builder.append("reg [SIZEDATA-1 : 0] \t\tconfin_");
          Integer _get = this.portMap.get(port);
          _builder.append(_get);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("reg \t\t\t\t\t\ten_");
          Integer _get_1 = this.portMap.get(port);
          _builder.append(_get_1);
          _builder.append(";");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("// Output Wire(s)");
      _builder.newLine();
      _builder.append("wire [SIZEDATA-1 : 0] \t\tdataout;");
      _builder.newLine();
      _builder.append("wire [SIZEID-1 : 0] \t\tkernelIDout;");
      _builder.newLine();
      _builder.append("//wire \t\t\t\t\t\tfinish;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("integer i;");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Unit Under Test Instantiation");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("coprocessor #(");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZEID(SIZEID),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZEADDRESS(SIZEADDRESS),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZECOUNT(SIZECOUNT),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZEPORT(SIZEPORT),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZEDATA(SIZEDATA),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZEBURST(SIZEBURST),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".SIZESIGNAL(SIZESIGNAL),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".FIFO_DEPTH(FIFO_DEPTH)//,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//.f_ptr_width(f_ptr_width)//,");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//.f_half_full_value(f_ptr_width), ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//.f_almost_full_value(f_almost_full_value),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//.f_almost_empty_value(f_almost_empty_value) ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(")");
      _builder.newLine();
      _builder.append("uut (");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".clk(clk),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".rst(rst),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".datain(datain),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".addressrd(addressrd),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".addresswr(addresswr),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".enablerd(enablerd),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".enablewr(enablewr),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".write(write),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".kernelIDin(kernelIDin),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".kernelIDen(kernelIDen),");
      _builder.newLine();
      _builder.append("\t");
      _builder.append(".kernelIDout(kernelIDout),");
      _builder.newLine();
      {
        Set<Port> _keySet_1 = this.portMap.keySet();
        for(final Port port_1 : _keySet_1) {
          _builder.append("\t");
          _builder.append(".confin_");
          Integer _get_2 = this.portMap.get(port_1);
          _builder.append(_get_2, "\t");
          _builder.append("(confin_");
          Integer _get_3 = this.portMap.get(port_1);
          _builder.append(_get_3, "\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append(".en_");
          Integer _get_4 = this.portMap.get(port_1);
          _builder.append(_get_4, "\t");
          _builder.append("(en_");
          Integer _get_5 = this.portMap.get(port_1);
          _builder.append(_get_5, "\t");
          _builder.append("),");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.append(".dataout(dataout)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("//.finish(finish)");
      _builder.newLine();
      _builder.append(");");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// Clock Always");
      _builder.newLine();
      _builder.append("always ");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#5 clk = ~clk;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// Input(s) Setting");
      _builder.newLine();
      _builder.append("initial begin");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Initialize Input(s)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("clk = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("rst = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("datain = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("addressrd = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("addresswr = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("enablerd = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("enablewr = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("write = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("kernelIDin = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("kernelIDen = 0;");
      _builder.newLine();
      {
        Set<Port> _keySet_2 = this.portMap.keySet();
        for(final Port port_2 : _keySet_2) {
          _builder.append("\t");
          _builder.append("confin_");
          Integer _get_6 = this.portMap.get(port_2);
          _builder.append(_get_6, "\t");
          _builder.append(" = 0;");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.append("en_");
          Integer _get_7 = this.portMap.get(port_2);
          _builder.append(_get_7, "\t");
          _builder.append(" = 0;");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.append("// Reset System");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#12\trst = 1;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#10\trst = 0;");
      _builder.newLine();
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Write Data into Memory");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#10\tenablewr = 1;\t// enable writing port");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("write = 1;\t\t// enable write");
      _builder.newLine();
      {
        Set<Port> _keySet_3 = this.inputMap.keySet();
        for(final Port input : _keySet_3) {
          _builder.append("\t\t");
          _builder.append("for(i=0;i<4;i=i+1)");
          _builder.newLine();
          _builder.append("\t\t");
          _builder.append("begin");
          _builder.newLine();
          _builder.append("\t\t");
          _builder.append("datain = ");
          Integer _get_8 = this.inputMap.get(input);
          int _multiply = ((_get_8).intValue() * 10);
          _builder.append(_multiply, "\t\t");
          _builder.append("+i;\t\t// written data ");
          Integer _get_9 = this.inputMap.get(input);
          int _multiply_1 = ((_get_9).intValue() * 10);
          _builder.append(_multiply_1, "\t\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.append("addresswr = ");
          Integer _get_10 = this.inputMap.get(input);
          int _multiply_2 = ((_get_10).intValue() * 10);
          _builder.append(_multiply_2, "\t\t");
          _builder.append("+i;\t// write address ");
          Integer _get_11 = this.inputMap.get(input);
          int _minus = ((_get_11).intValue() - 1);
          _builder.append(_minus, "\t\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.append("#10;");
          _builder.newLine();
          _builder.append("\t\t");
          _builder.append("end");
          _builder.newLine();
        }
      }
      _builder.append("\t\t");
      _builder.append("enablewr = 0; \t// disable writing port");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("write = 0;\t\t// disable write");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Setting Configuration Registers");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#10");
      _builder.newLine();
      {
        Set<Port> _keySet_4 = this.portMap.keySet();
        for(final Port port_3 : _keySet_4) {
          _builder.append("\t\t");
          _builder.append("confin_");
          Integer _get_12 = this.portMap.get(port_3);
          _builder.append(_get_12, "\t\t");
          _builder.append(" = (1<<(SIZEADDRESS+SIZECOUNT))\t// burst port ");
          Integer _get_13 = this.portMap.get(port_3);
          _builder.append(_get_13, "\t\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.append("\t\t\t\t\t\t\t\t");
          _builder.append("| (4<<SIZEADDRESS)\t\t\t// size port ");
          Integer _get_14 = this.portMap.get(port_3);
          _builder.append(_get_14, "\t\t\t\t\t\t\t\t\t\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.append("\t\t\t\t\t\t\t\t");
          _builder.append("| ");
          Integer _get_15 = this.portMap.get(port_3);
          _builder.append(_get_15, "\t\t\t\t\t\t\t\t\t\t");
          _builder.append(" *10;\t// baseaddr port ");
          Integer _get_16 = this.portMap.get(port_3);
          _builder.append(_get_16, "\t\t\t\t\t\t\t\t\t\t");
          _builder.newLineIfNotEmpty();
          _builder.append("\t\t");
          _builder.append("en_");
          Integer _get_17 = this.portMap.get(port_3);
          _builder.append(_get_17, "\t\t");
          _builder.append(" = 1;");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.append("#10");
      _builder.newLine();
      {
        Set<Port> _keySet_5 = this.portMap.keySet();
        for(final Port port_4 : _keySet_5) {
          _builder.append("\t\t");
          _builder.append("en_");
          Integer _get_18 = this.portMap.get(port_4);
          _builder.append(_get_18, "\t\t");
          _builder.append(" = 0;");
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("\t");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("// Setting Kernel ID (Start Computation)");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#10\tkernelIDin = 1;\t// kernel ID 1");
      _builder.newLine();
      _builder.append("\t\t");
      _builder.append("kernelIDen = 1;");
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#10 kernelIDen = 0;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("\t");
      _builder.append("#200 $stop;");
      _builder.newLine();
      _builder.append("end");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("endmodule\t\t");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printTop(final Network network) {
    CharSequence _xblockexpression = null;
    {
      this.mapInOut(network);
      this.mapSignals();
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _printTopHeaderComments = this.printTopHeaderComments();
      _builder.append(_printTopHeaderComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopInterface = this.printTopInterface(network);
      _builder.append(_printTopInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopSignals = this.printTopSignals();
      _builder.append(_printTopSignals);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          _builder.append("//monitoring");
          _builder.newLine();
          _builder.newLine();
          {
            for(final String monitor : this.monList) {
              _builder.append("// Monitor ");
              int _indexOf = this.monList.indexOf(monitor);
              _builder.append(_indexOf);
              _builder.append(": ");
              _builder.append(monitor);
              _builder.newLineIfNotEmpty();
              _builder.append("wire clear_monitor_");
              int _indexOf_1 = this.monList.indexOf(monitor);
              _builder.append(_indexOf_1);
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              _builder.append("reg [31 : 0]  ");
              _builder.append(monitor);
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.newLine();
          {
            boolean _contains = this.monList.contains("count_clock_cycles");
            if (_contains) {
              _builder.append("reg en_clock_count;");
              _builder.newLine();
              _builder.append("reg state, next_state;  ");
              _builder.newLine();
            }
          }
        }
      }
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopBody = this.printTopBody(network);
      _builder.append(_printTopBody);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printTopBody(final Network network) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Configuration Registers");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Instantiation of Configuration Registers");
    _builder.newLine();
    _builder.append("config_registers # ( ");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".C_S_AXI_DATA_WIDTH(C_S00_AXI_DATA_WIDTH),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".C_S_AXI_ADDR_WIDTH(C_S00_AXI_ADDR_WIDTH)");
    _builder.newLine();
    _builder.append(") i_config_registers (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ACLK(s00_axi_aclk),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ARESETN(s00_axi_aresetn),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_AWADDR(s00_axi_awaddr),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_AWPROT(s00_axi_awprot),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_AWVALID(s00_axi_awvalid),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_AWREADY(s00_axi_awready),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_WDATA(s00_axi_wdata),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_WSTRB(s00_axi_wstrb),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_WVALID(s00_axi_wvalid),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_WREADY(s00_axi_wready),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_BRESP(s00_axi_bresp),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_BVALID(s00_axi_bvalid),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_BREADY(s00_axi_bready),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ARADDR(s00_axi_araddr),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ARPROT(s00_axi_arprot),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ARVALID(s00_axi_arvalid),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_ARREADY(s00_axi_arready),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_RDATA(s00_axi_rdata),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_RRESP(s00_axi_rresp),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_RVALID(s00_axi_rvalid),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".S_AXI_RREADY(s00_axi_rready),");
    _builder.newLine();
    _builder.append("\t");
    {
      boolean _equals = this.coupling.equals("mm");
      if (_equals) {
        _builder.append(".done(done),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".start(start),");
        _builder.newLine();
        {
          if (this.enableMonitoring) {
            {
              for(final String monitor : this.monList) {
                _builder.append("\t");
                _builder.append(".clear_monitor_");
                int _indexOf = this.monList.indexOf(monitor);
                _builder.append(_indexOf, "\t");
                _builder.append("(clear_monitor_");
                int _indexOf_1 = this.monList.indexOf(monitor);
                _builder.append(_indexOf_1, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".");
                _builder.append(monitor, "\t");
                _builder.append("(");
                _builder.append(monitor, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        {
          Set<Port> _keySet = this.portMap.keySet();
          for(final Port port : _keySet) {
            _builder.append("\t");
            _builder.append(".slv_reg");
            Integer _get = this.portMap.get(port);
            int _plus = ((_get).intValue() + 1);
            _builder.append(_plus, "\t");
            _builder.append("(slv_reg");
            Integer _get_1 = this.portMap.get(port);
            int _plus_1 = ((_get_1).intValue() + 1);
            _builder.append(_plus_1, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          if (this.enableMonitoring) {
            {
              for(final String monitor_1 : this.monList) {
                _builder.append("\t");
                _builder.append(".slv_reg");
                int _size = this.portMap.keySet().size();
                int _plus_2 = (_size + 1);
                int _indexOf_2 = this.monList.indexOf(monitor_1);
                int _plus_3 = (_plus_2 + _indexOf_2);
                _builder.append(_plus_3, "\t");
                _builder.append("(slv_reg");
                int _size_1 = this.portMap.keySet().size();
                int _plus_4 = (_size_1 + 1);
                int _indexOf_3 = this.monList.indexOf(monitor_1);
                int _plus_5 = (_plus_4 + _indexOf_3);
                _builder.append(_plus_5, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      } else {
        {
          Set<Port> _keySet_1 = this.outputMap.keySet();
          for(final Port output : _keySet_1) {
            _builder.append("\t\t.slv_reg");
            Integer _get_2 = this.outputMap.get(output);
            int _plus_6 = ((_get_2).intValue() + 1);
            _builder.append(_plus_6);
            _builder.append("(slv_reg");
            Integer _get_3 = this.outputMap.get(output);
            int _plus_7 = ((_get_3).intValue() + 1);
            _builder.append(_plus_7);
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("    ");
    _builder.append(".slv_reg0(slv_reg0)");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.newLine();
    {
      boolean _equals_1 = this.coupling.equals("mm");
      if (_equals_1) {
        _builder.append("// Local Memories");
        _builder.newLine();
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        _builder.append("// Instantiation of Local Memories");
        _builder.newLine();
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        {
          if (this.dedicatedInterfaces) {
            {
              Set<Port> _keySet_2 = this.portMap.keySet();
              for(final Port port_1 : _keySet_2) {
                _builder.append("// local memory ");
                Integer _get_4 = this.portMap.get(port_1);
                int _plus_8 = ((_get_4).intValue() + 1);
                _builder.append(_plus_8);
                _builder.newLineIfNotEmpty();
                _builder.append("S01_AXI_ipif # (");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".C_S_AXI_ID_WIDTH(C_S");
                Integer _get_5 = this.portMap.get(port_1);
                int _plus_9 = ((_get_5).intValue() + 1);
                String _longId = this.getLongId(_plus_9);
                _builder.append(_longId, "\t");
                _builder.append("_AXI_ID_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_DATA_WIDTH(C_S");
                Integer _get_6 = this.portMap.get(port_1);
                int _plus_10 = ((_get_6).intValue() + 1);
                String _longId_1 = this.getLongId(_plus_10);
                _builder.append(_longId_1, "\t");
                _builder.append("_AXI_DATA_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_ADDR_WIDTH(C_S");
                Integer _get_7 = this.portMap.get(port_1);
                int _plus_11 = ((_get_7).intValue() + 1);
                String _longId_2 = this.getLongId(_plus_11);
                _builder.append(_longId_2, "\t");
                _builder.append("_AXI_ADDR_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_AWUSER_WIDTH(C_S");
                Integer _get_8 = this.portMap.get(port_1);
                int _plus_12 = ((_get_8).intValue() + 1);
                String _longId_3 = this.getLongId(_plus_12);
                _builder.append(_longId_3, "\t");
                _builder.append("_AXI_AWUSER_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_ARUSER_WIDTH(C_S");
                Integer _get_9 = this.portMap.get(port_1);
                int _plus_13 = ((_get_9).intValue() + 1);
                String _longId_4 = this.getLongId(_plus_13);
                _builder.append(_longId_4, "\t");
                _builder.append("_AXI_ARUSER_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_WUSER_WIDTH(C_S");
                Integer _get_10 = this.portMap.get(port_1);
                int _plus_14 = ((_get_10).intValue() + 1);
                String _longId_5 = this.getLongId(_plus_14);
                _builder.append(_longId_5, "\t");
                _builder.append("_AXI_WUSER_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_RUSER_WIDTH(C_S");
                Integer _get_11 = this.portMap.get(port_1);
                int _plus_15 = ((_get_11).intValue() + 1);
                String _longId_6 = this.getLongId(_plus_15);
                _builder.append(_longId_6, "\t");
                _builder.append("_AXI_RUSER_WIDTH),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".C_S_AXI_BUSER_WIDTH(C_S");
                Integer _get_12 = this.portMap.get(port_1);
                int _plus_16 = ((_get_12).intValue() + 1);
                String _longId_7 = this.getLongId(_plus_16);
                _builder.append(_longId_7, "\t");
                _builder.append("_AXI_BUSER_WIDTH)");
                _builder.newLineIfNotEmpty();
                _builder.append(") i_local_memory_");
                Integer _get_13 = this.portMap.get(port_1);
                int _plus_17 = ((_get_13).intValue() + 1);
                _builder.append(_plus_17);
                _builder.append(" (");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ACLK(s");
                Integer _get_14 = this.portMap.get(port_1);
                int _plus_18 = ((_get_14).intValue() + 1);
                String _longId_8 = this.getLongId(_plus_18);
                _builder.append(_longId_8, "\t");
                _builder.append("_axi_aclk),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARESETN(s");
                Integer _get_15 = this.portMap.get(port_1);
                int _plus_19 = ((_get_15).intValue() + 1);
                String _longId_9 = this.getLongId(_plus_19);
                _builder.append(_longId_9, "\t");
                _builder.append("_axi_aresetn),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWID(s");
                Integer _get_16 = this.portMap.get(port_1);
                int _plus_20 = ((_get_16).intValue() + 1);
                String _longId_10 = this.getLongId(_plus_20);
                _builder.append(_longId_10, "\t");
                _builder.append("_axi_awid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWADDR(s");
                Integer _get_17 = this.portMap.get(port_1);
                int _plus_21 = ((_get_17).intValue() + 1);
                String _longId_11 = this.getLongId(_plus_21);
                _builder.append(_longId_11, "\t");
                _builder.append("_axi_awaddr),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWLEN(s");
                Integer _get_18 = this.portMap.get(port_1);
                int _plus_22 = ((_get_18).intValue() + 1);
                String _longId_12 = this.getLongId(_plus_22);
                _builder.append(_longId_12, "\t");
                _builder.append("_axi_awlen),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWSIZE(s");
                Integer _get_19 = this.portMap.get(port_1);
                int _plus_23 = ((_get_19).intValue() + 1);
                String _longId_13 = this.getLongId(_plus_23);
                _builder.append(_longId_13, "\t");
                _builder.append("_axi_awsize),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWBURST(s");
                Integer _get_20 = this.portMap.get(port_1);
                int _plus_24 = ((_get_20).intValue() + 1);
                String _longId_14 = this.getLongId(_plus_24);
                _builder.append(_longId_14, "\t");
                _builder.append("_axi_awburst),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWLOCK(s");
                Integer _get_21 = this.portMap.get(port_1);
                int _plus_25 = ((_get_21).intValue() + 1);
                String _longId_15 = this.getLongId(_plus_25);
                _builder.append(_longId_15, "\t");
                _builder.append("_axi_awlock),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWCACHE(s");
                Integer _get_22 = this.portMap.get(port_1);
                int _plus_26 = ((_get_22).intValue() + 1);
                String _longId_16 = this.getLongId(_plus_26);
                _builder.append(_longId_16, "\t");
                _builder.append("_axi_awcache),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWPROT(s");
                Integer _get_23 = this.portMap.get(port_1);
                int _plus_27 = ((_get_23).intValue() + 1);
                String _longId_17 = this.getLongId(_plus_27);
                _builder.append(_longId_17, "\t");
                _builder.append("_axi_awprot),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWQOS(s");
                Integer _get_24 = this.portMap.get(port_1);
                int _plus_28 = ((_get_24).intValue() + 1);
                String _longId_18 = this.getLongId(_plus_28);
                _builder.append(_longId_18, "\t");
                _builder.append("_axi_awqos),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWREGION(s");
                Integer _get_25 = this.portMap.get(port_1);
                int _plus_29 = ((_get_25).intValue() + 1);
                String _longId_19 = this.getLongId(_plus_29);
                _builder.append(_longId_19, "\t");
                _builder.append("_axi_awregion),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWUSER(s");
                Integer _get_26 = this.portMap.get(port_1);
                int _plus_30 = ((_get_26).intValue() + 1);
                String _longId_20 = this.getLongId(_plus_30);
                _builder.append(_longId_20, "\t");
                _builder.append("_axi_awuser),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWVALID(s");
                Integer _get_27 = this.portMap.get(port_1);
                int _plus_31 = ((_get_27).intValue() + 1);
                String _longId_21 = this.getLongId(_plus_31);
                _builder.append(_longId_21, "\t");
                _builder.append("_axi_awvalid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_AWREADY(s");
                Integer _get_28 = this.portMap.get(port_1);
                int _plus_32 = ((_get_28).intValue() + 1);
                String _longId_22 = this.getLongId(_plus_32);
                _builder.append(_longId_22, "\t");
                _builder.append("_axi_awready),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WDATA(s");
                Integer _get_29 = this.portMap.get(port_1);
                int _plus_33 = ((_get_29).intValue() + 1);
                String _longId_23 = this.getLongId(_plus_33);
                _builder.append(_longId_23, "\t");
                _builder.append("_axi_wdata),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WSTRB(s");
                Integer _get_30 = this.portMap.get(port_1);
                int _plus_34 = ((_get_30).intValue() + 1);
                String _longId_24 = this.getLongId(_plus_34);
                _builder.append(_longId_24, "\t");
                _builder.append("_axi_wstrb),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WLAST(s");
                Integer _get_31 = this.portMap.get(port_1);
                int _plus_35 = ((_get_31).intValue() + 1);
                String _longId_25 = this.getLongId(_plus_35);
                _builder.append(_longId_25, "\t");
                _builder.append("_axi_wlast),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WUSER(s");
                Integer _get_32 = this.portMap.get(port_1);
                int _plus_36 = ((_get_32).intValue() + 1);
                String _longId_26 = this.getLongId(_plus_36);
                _builder.append(_longId_26, "\t");
                _builder.append("_axi_wuser),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WVALID(s");
                Integer _get_33 = this.portMap.get(port_1);
                int _plus_37 = ((_get_33).intValue() + 1);
                String _longId_27 = this.getLongId(_plus_37);
                _builder.append(_longId_27, "\t");
                _builder.append("_axi_wvalid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_WREADY(s");
                Integer _get_34 = this.portMap.get(port_1);
                int _plus_38 = ((_get_34).intValue() + 1);
                String _longId_28 = this.getLongId(_plus_38);
                _builder.append(_longId_28, "\t");
                _builder.append("_axi_wready),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_BID(s");
                Integer _get_35 = this.portMap.get(port_1);
                int _plus_39 = ((_get_35).intValue() + 1);
                String _longId_29 = this.getLongId(_plus_39);
                _builder.append(_longId_29, "\t");
                _builder.append("_axi_bid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_BRESP(s");
                Integer _get_36 = this.portMap.get(port_1);
                int _plus_40 = ((_get_36).intValue() + 1);
                String _longId_30 = this.getLongId(_plus_40);
                _builder.append(_longId_30, "\t");
                _builder.append("_axi_bresp),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_BUSER(s");
                Integer _get_37 = this.portMap.get(port_1);
                int _plus_41 = ((_get_37).intValue() + 1);
                String _longId_31 = this.getLongId(_plus_41);
                _builder.append(_longId_31, "\t");
                _builder.append("_axi_buser),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_BVALID(s");
                Integer _get_38 = this.portMap.get(port_1);
                int _plus_42 = ((_get_38).intValue() + 1);
                String _longId_32 = this.getLongId(_plus_42);
                _builder.append(_longId_32, "\t");
                _builder.append("_axi_bvalid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_BREADY(s");
                Integer _get_39 = this.portMap.get(port_1);
                int _plus_43 = ((_get_39).intValue() + 1);
                String _longId_33 = this.getLongId(_plus_43);
                _builder.append(_longId_33, "\t");
                _builder.append("_axi_bready),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARID(s");
                Integer _get_40 = this.portMap.get(port_1);
                int _plus_44 = ((_get_40).intValue() + 1);
                String _longId_34 = this.getLongId(_plus_44);
                _builder.append(_longId_34, "\t");
                _builder.append("_axi_arid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARADDR(s");
                Integer _get_41 = this.portMap.get(port_1);
                int _plus_45 = ((_get_41).intValue() + 1);
                String _longId_35 = this.getLongId(_plus_45);
                _builder.append(_longId_35, "\t");
                _builder.append("_axi_araddr),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARLEN(s");
                Integer _get_42 = this.portMap.get(port_1);
                int _plus_46 = ((_get_42).intValue() + 1);
                String _longId_36 = this.getLongId(_plus_46);
                _builder.append(_longId_36, "\t");
                _builder.append("_axi_arlen),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARSIZE(s");
                Integer _get_43 = this.portMap.get(port_1);
                int _plus_47 = ((_get_43).intValue() + 1);
                String _longId_37 = this.getLongId(_plus_47);
                _builder.append(_longId_37, "\t");
                _builder.append("_axi_arsize),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARBURST(s");
                Integer _get_44 = this.portMap.get(port_1);
                int _plus_48 = ((_get_44).intValue() + 1);
                String _longId_38 = this.getLongId(_plus_48);
                _builder.append(_longId_38, "\t");
                _builder.append("_axi_arburst),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARLOCK(s");
                Integer _get_45 = this.portMap.get(port_1);
                int _plus_49 = ((_get_45).intValue() + 1);
                String _longId_39 = this.getLongId(_plus_49);
                _builder.append(_longId_39, "\t");
                _builder.append("_axi_arlock),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARCACHE(s");
                Integer _get_46 = this.portMap.get(port_1);
                int _plus_50 = ((_get_46).intValue() + 1);
                String _longId_40 = this.getLongId(_plus_50);
                _builder.append(_longId_40, "\t");
                _builder.append("_axi_arcache),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARPROT(s");
                Integer _get_47 = this.portMap.get(port_1);
                int _plus_51 = ((_get_47).intValue() + 1);
                String _longId_41 = this.getLongId(_plus_51);
                _builder.append(_longId_41, "\t");
                _builder.append("_axi_arprot),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARQOS(s");
                Integer _get_48 = this.portMap.get(port_1);
                int _plus_52 = ((_get_48).intValue() + 1);
                String _longId_42 = this.getLongId(_plus_52);
                _builder.append(_longId_42, "\t");
                _builder.append("_axi_arqos),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARREGION(s");
                Integer _get_49 = this.portMap.get(port_1);
                int _plus_53 = ((_get_49).intValue() + 1);
                String _longId_43 = this.getLongId(_plus_53);
                _builder.append(_longId_43, "\t");
                _builder.append("_axi_arregion),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARUSER(s");
                Integer _get_50 = this.portMap.get(port_1);
                int _plus_54 = ((_get_50).intValue() + 1);
                String _longId_44 = this.getLongId(_plus_54);
                _builder.append(_longId_44, "\t");
                _builder.append("_axi_aruser),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARVALID(s");
                Integer _get_51 = this.portMap.get(port_1);
                int _plus_55 = ((_get_51).intValue() + 1);
                String _longId_45 = this.getLongId(_plus_55);
                _builder.append(_longId_45, "\t");
                _builder.append("_axi_arvalid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_ARREADY(s");
                Integer _get_52 = this.portMap.get(port_1);
                int _plus_56 = ((_get_52).intValue() + 1);
                String _longId_46 = this.getLongId(_plus_56);
                _builder.append(_longId_46, "\t");
                _builder.append("_axi_arready),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RID(s");
                Integer _get_53 = this.portMap.get(port_1);
                int _plus_57 = ((_get_53).intValue() + 1);
                String _longId_47 = this.getLongId(_plus_57);
                _builder.append(_longId_47, "\t");
                _builder.append("_axi_rid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RDATA(s");
                Integer _get_54 = this.portMap.get(port_1);
                int _plus_58 = ((_get_54).intValue() + 1);
                String _longId_48 = this.getLongId(_plus_58);
                _builder.append(_longId_48, "\t");
                _builder.append("_axi_rdata),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RRESP(s");
                Integer _get_55 = this.portMap.get(port_1);
                int _plus_59 = ((_get_55).intValue() + 1);
                String _longId_49 = this.getLongId(_plus_59);
                _builder.append(_longId_49, "\t");
                _builder.append("_axi_rresp),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RLAST(s");
                Integer _get_56 = this.portMap.get(port_1);
                int _plus_60 = ((_get_56).intValue() + 1);
                String _longId_50 = this.getLongId(_plus_60);
                _builder.append(_longId_50, "\t");
                _builder.append("_axi_rlast),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RUSER(s");
                Integer _get_57 = this.portMap.get(port_1);
                int _plus_61 = ((_get_57).intValue() + 1);
                String _longId_51 = this.getLongId(_plus_61);
                _builder.append(_longId_51, "\t");
                _builder.append("_axi_ruser),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RVALID(s");
                Integer _get_58 = this.portMap.get(port_1);
                int _plus_62 = ((_get_58).intValue() + 1);
                String _longId_52 = this.getLongId(_plus_62);
                _builder.append(_longId_52, "\t");
                _builder.append("_axi_rvalid),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".S_AXI_RREADY(s");
                Integer _get_59 = this.portMap.get(port_1);
                int _plus_63 = ((_get_59).intValue() + 1);
                String _longId_53 = this.getLongId(_plus_63);
                _builder.append(_longId_53, "\t");
                _builder.append("_axi_rready),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".rden(accelerator_mem_");
                Integer _get_60 = this.portMap.get(port_1);
                int _plus_64 = ((_get_60).intValue() + 1);
                _builder.append(_plus_64, "\t");
                _builder.append("_rden),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".wren(accelerator_mem_");
                Integer _get_61 = this.portMap.get(port_1);
                int _plus_65 = ((_get_61).intValue() + 1);
                _builder.append(_plus_65, "\t");
                _builder.append("_wren),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".address(accelerator_mem_");
                Integer _get_62 = this.portMap.get(port_1);
                int _plus_66 = ((_get_62).intValue() + 1);
                _builder.append(_plus_66, "\t");
                _builder.append("_address),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_in(accelerator_mem_");
                Integer _get_63 = this.portMap.get(port_1);
                int _plus_67 = ((_get_63).intValue() + 1);
                _builder.append(_plus_67, "\t");
                _builder.append("_data_in),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_out(accelerator_mem_");
                Integer _get_64 = this.portMap.get(port_1);
                int _plus_68 = ((_get_64).intValue() + 1);
                _builder.append(_plus_68, "\t");
                _builder.append("_data_out)");
                _builder.newLineIfNotEmpty();
                _builder.append(");");
                _builder.newLine();
              }
            }
          } else {
            _builder.append("S01_AXI_ipif # (");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_ID_WIDTH(C_S01_AXI_ID_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_DATA_WIDTH(C_S01_AXI_DATA_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_ADDR_WIDTH(C_S01_AXI_ADDR_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_AWUSER_WIDTH(C_S01_AXI_AWUSER_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_ARUSER_WIDTH(C_S01_AXI_ARUSER_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_WUSER_WIDTH(C_S01_AXI_WUSER_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_RUSER_WIDTH(C_S01_AXI_RUSER_WIDTH),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".C_S_AXI_BUSER_WIDTH(C_S01_AXI_BUSER_WIDTH)");
            _builder.newLine();
            _builder.append(") i_axi_full_ipif (");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ACLK(s01_axi_aclk),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARESETN(s01_axi_aresetn),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWID(s01_axi_awid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWADDR(s01_axi_awaddr),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWLEN(s01_axi_awlen),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWSIZE(s01_axi_awsize),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWBURST(s01_axi_awburst),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWLOCK(s01_axi_awlock),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWCACHE(s01_axi_awcache),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWPROT(s01_axi_awprot),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWQOS(s01_axi_awqos),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWREGION(s01_axi_awregion),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWUSER(s01_axi_awuser),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWVALID(s01_axi_awvalid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_AWREADY(s01_axi_awready),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WDATA(s01_axi_wdata),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WSTRB(s01_axi_wstrb),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WLAST(s01_axi_wlast),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WUSER(s01_axi_wuser),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WVALID(s01_axi_wvalid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_WREADY(s01_axi_wready),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_BID(s01_axi_bid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_BRESP(s01_axi_bresp),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_BUSER(s01_axi_buser),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_BVALID(s01_axi_bvalid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_BREADY(s01_axi_bready),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARID(s01_axi_arid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARADDR(s01_axi_araddr),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARLEN(s01_axi_arlen),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARSIZE(s01_axi_arsize),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARBURST(s01_axi_arburst),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARLOCK(s01_axi_arlock),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARCACHE(s01_axi_arcache),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARPROT(s01_axi_arprot),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARQOS(s01_axi_arqos),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARREGION(s01_axi_arregion),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARUSER(s01_axi_aruser),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARVALID(s01_axi_arvalid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_ARREADY(s01_axi_arready),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RID(s01_axi_rid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RDATA(s01_axi_rdata),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RRESP(s01_axi_rresp),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RLAST(s01_axi_rlast),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RUSER(s01_axi_ruser),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RVALID(s01_axi_rvalid),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".S_AXI_RREADY(s01_axi_rready),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".rden(s01_axi_rden),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".wren(s01_axi_wren),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".address(s01_axi_address),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".data_in(s01_axi_data_in),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".data_out(s01_axi_data_out)");
            _builder.newLine();
            _builder.append(");");
            _builder.newLine();
            {
              Set<Port> _keySet_3 = this.portMap.keySet();
              for(final Port port_2 : _keySet_3) {
                _builder.append("// local memory ");
                Integer _get_65 = this.portMap.get(port_2);
                int _plus_69 = ((_get_65).intValue() + 1);
                _builder.append(_plus_69);
                _builder.append(" (");
                String _name = port_2.getName();
                _builder.append(_name);
                _builder.append(")");
                _builder.newLineIfNotEmpty();
                _builder.append("local_memory # (");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".SIZE_WORD(");
                int _dataSize = this.protocolManager.getDataSize(port_2);
                _builder.append(_dataSize, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".SIZE_MEM(SIZE_MEM_");
                Integer _get_66 = this.portMap.get(port_2);
                int _plus_70 = ((_get_66).intValue() + 1);
                _builder.append(_plus_70, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".SIZE_ADDR(SIZE_ADDR_");
                Integer _get_67 = this.portMap.get(port_2);
                int _plus_71 = ((_get_67).intValue() + 1);
                _builder.append(_plus_71, "\t");
                _builder.append(")");
                _builder.newLineIfNotEmpty();
                _builder.append(") i_local_memory_");
                Integer _get_68 = this.portMap.get(port_2);
                int _plus_72 = ((_get_68).intValue() + 1);
                _builder.append(_plus_72);
                _builder.append(" (");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".aclk_a(s01_axi_aclk),");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".ce_a(ce_");
                Integer _get_69 = this.portMap.get(port_2);
                int _plus_73 = ((_get_69).intValue() + 1);
                _builder.append(_plus_73, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".rden_a(s01_axi_rden),");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".wren_a(s01_axi_wren),");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".address_a(s01_axi_address-BASE_ADDR_MEM_");
                Integer _get_70 = this.portMap.get(port_2);
                int _plus_74 = ((_get_70).intValue() + 1);
                _builder.append(_plus_74, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_in_a(s01_axi_data_in");
                {
                  int _dataSize_1 = this.protocolManager.getDataSize(port_2);
                  boolean _lessThan = (_dataSize_1 < 32);
                  if (_lessThan) {
                    _builder.append("[");
                    int _dataSize_2 = this.protocolManager.getDataSize(port_2);
                    _builder.append(_dataSize_2, "\t");
                    _builder.append("-1:0]");
                  }
                }
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_out_a(data_out_");
                Integer _get_71 = this.portMap.get(port_2);
                int _plus_75 = ((_get_71).intValue() + 1);
                _builder.append(_plus_75, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".aclk_b(s01_axi_aclk),");
                _builder.newLine();
                _builder.append("\t");
                _builder.append(".ce_b(");
                {
                  boolean _containsKey = this.inputMap.containsKey(port_2);
                  if (_containsKey) {
                    _builder.append("rd");
                  } else {
                    _builder.append("wr");
                  }
                }
                _builder.append("en_mem_");
                Integer _get_72 = this.portMap.get(port_2);
                int _plus_76 = ((_get_72).intValue() + 1);
                _builder.append(_plus_76, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".rden_b(rden_mem_");
                Integer _get_73 = this.portMap.get(port_2);
                int _plus_77 = ((_get_73).intValue() + 1);
                _builder.append(_plus_77, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".wren_b(wren_mem_");
                Integer _get_74 = this.portMap.get(port_2);
                int _plus_78 = ((_get_74).intValue() + 1);
                _builder.append(_plus_78, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".address_b(address_mem_");
                Integer _get_75 = this.portMap.get(port_2);
                int _plus_79 = ((_get_75).intValue() + 1);
                _builder.append(_plus_79, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_in_b(data_in_mem_");
                Integer _get_76 = this.portMap.get(port_2);
                int _plus_80 = ((_get_76).intValue() + 1);
                _builder.append(_plus_80, "\t");
                _builder.append("),");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".data_out_b(data_out_mem_");
                Integer _get_77 = this.portMap.get(port_2);
                int _plus_81 = ((_get_77).intValue() + 1);
                _builder.append(_plus_81, "\t");
                _builder.append(")");
                _builder.newLineIfNotEmpty();
                _builder.append(");");
                _builder.newLine();
                _builder.newLine();
                _builder.append("assign ce_");
                Integer _get_78 = this.portMap.get(port_2);
                int _plus_82 = ((_get_78).intValue() + 1);
                _builder.append(_plus_82);
                _builder.append(" = (s01_axi_rden || s01_axi_wren)");
                _builder.newLineIfNotEmpty();
                _builder.append("&& (s01_axi_address >= BASE_ADDR_MEM_");
                Integer _get_79 = this.portMap.get(port_2);
                int _plus_83 = ((_get_79).intValue() + 1);
                _builder.append(_plus_83);
                _builder.append(")");
                _builder.newLineIfNotEmpty();
                {
                  Integer _get_80 = this.portMap.get(port_2);
                  int _plus_84 = ((_get_80).intValue() + 1);
                  int _size_2 = this.portMap.size();
                  boolean _lessThan_1 = (_plus_84 < _size_2);
                  if (_lessThan_1) {
                    _builder.append("&& (s01_axi_address < BASE_ADDR_MEM_");
                    Integer _get_81 = this.portMap.get(port_2);
                    int _plus_85 = ((_get_81).intValue() + 2);
                    _builder.append(_plus_85);
                    _builder.append(")");
                  }
                }
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.newLine();
            _builder.append("always@(");
            {
              Set<Port> _keySet_4 = this.portMap.keySet();
              boolean _hasElements = false;
              for(final Port port_3 : _keySet_4) {
                if (!_hasElements) {
                  _hasElements = true;
                } else {
                  _builder.appendImmediate(" or ", "");
                }
                _builder.append("ce_");
                Integer _get_82 = this.portMap.get(port_3);
                int _plus_86 = ((_get_82).intValue() + 1);
                _builder.append(_plus_86);
                _builder.append(" or data_out_");
                Integer _get_83 = this.portMap.get(port_3);
                int _plus_87 = ((_get_83).intValue() + 1);
                _builder.append(_plus_87);
              }
            }
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            {
              Set<Port> _keySet_5 = this.portMap.keySet();
              boolean _hasElements_1 = false;
              for(final Port port_4 : _keySet_5) {
                if (!_hasElements_1) {
                  _hasElements_1 = true;
                } else {
                  _builder.appendImmediate(" else ", "\t\t");
                }
                _builder.append("\t\t");
                _builder.append("if (ce_");
                Integer _get_84 = this.portMap.get(port_4);
                int _plus_88 = ((_get_84).intValue() + 1);
                _builder.append(_plus_88, "\t\t");
                _builder.append(")");
                _builder.newLineIfNotEmpty();
                _builder.append("\t\t");
                _builder.append("\t");
                _builder.append("s01_axi_data_out = {");
                {
                  int _dataSize_3 = this.protocolManager.getDataSize(port_4);
                  boolean _lessThan_2 = (_dataSize_3 < 32);
                  if (_lessThan_2) {
                    _builder.append("{");
                    int _dataSize_4 = this.protocolManager.getDataSize(port_4);
                    int _minus = (32 - _dataSize_4);
                    _builder.append(_minus, "\t\t\t");
                    _builder.append("{1\'b0}},");
                  }
                }
                _builder.append("data_out_");
                Integer _get_85 = this.portMap.get(port_4);
                int _plus_89 = ((_get_85).intValue() + 1);
                _builder.append(_plus_89, "\t\t\t");
                _builder.append("};");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("\t\t");
            _builder.append("else");
            _builder.newLine();
            _builder.append("\t\t\t");
            _builder.append("s01_axi_data_out = 0;");
            _builder.newLine();
          }
        }
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        _builder.newLine();
        {
          if (this.enableMonitoring) {
            _builder.append("// ----------------------------------------------------------------------------");
            _builder.newLine();
            _builder.append("// Monitoring Logic");
            _builder.newLine();
            _builder.append("// ----------------------------------------------------------------------------");
            _builder.newLine();
            {
              for(final String monitor_2 : this.monList) {
                {
                  boolean _contains = monitor_2.contains("count_full_");
                  if (_contains) {
                    _builder.append("// TO FIX");
                    _builder.newLine();
                    _builder.append("// monitoring total full of  FIFO  ");
                    String _replace = monitor_2.replace("count_full_", "");
                    _builder.append(_replace);
                    _builder.append("_full");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t");
                    _builder.append("always@(posedge s00_axi_aclk or negedge s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("if(!s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append(monitor_2, "\t        ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("end ");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("if(clear_monitor_");
                    int _indexOf_4 = this.monList.indexOf(monitor_2);
                    _builder.append(_indexOf_4, "\t        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("else if(");
                    String _replace_1 = monitor_2.replace("count_full_", "");
                    _builder.append(_replace_1, "\t        ");
                    _builder.append("_full)");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" + 1;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("else ");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("end");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.newLine();
                  }
                }
                {
                  boolean _equals_2 = monitor_2.equals("count_clock_cycles");
                  if (_equals_2) {
                    _builder.append("// monitoring clock cycles");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("always@(posedge s00_axi_aclk or negedge s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("if(!s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("state <= 0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append(monitor_2, "\t        ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("end ");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("state <= next_state;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("if(clear_monitor_");
                    int _indexOf_5 = this.monList.indexOf(monitor_2);
                    _builder.append(_indexOf_5, "\t        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("else if(en_clock_count)");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" + 1;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("else ");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "\t            ");
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                    _builder.append("\t        ");
                    _builder.append("end");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.newLine();
                    _builder.append("\t ");
                    _builder.append("// state transitions (to enable monitoring only from start to done signals)");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("always@(state or start or done)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("case(state)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("//wait ");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("1\'b0: if(start) ");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append("next_state = 1\'b1;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append("next_state = 1\'b0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("// count");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("1\'b1: if(done)");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append("next_state = 1\'b0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("\t            ");
                    _builder.append("next_state = 1\'b1;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("default: next_state = 1\'b0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("endcase ");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.newLine();
                    _builder.append("\t ");
                    _builder.append("// enabling monitoring");
                    _builder.newLine();
                    _builder.append("\t    ");
                    _builder.append("always@(state)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("case(state)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("//wait (clock count disabled)");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("1\'b0: en_clock_count = 0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("1\'b1: en_clock_count = 1;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("default: en_clock_count = 0;");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.append("endcase ");
                    _builder.newLine();
                    _builder.append("\t        ");
                    _builder.newLine();
                  }
                }
                {
                  boolean _contains_1 = monitor_2.contains("count_in_tokens_");
                  if (_contains_1) {
                    _builder.append("// monitoring input tokens (of port ");
                    String _replace_2 = monitor_2.replace("count_in_tokens_", "");
                    _builder.append(_replace_2);
                    _builder.append(")\t\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("always@(posedge s00_axi_aclk or negedge s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("    ");
                    _builder.append("if(!s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append(monitor_2, "        ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("end ");
                    _builder.newLine();
                    _builder.append("    ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("if(clear_monitor_");
                    int _indexOf_6 = this.monList.indexOf(monitor_2);
                    _builder.append(_indexOf_6, "        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("else if(rden_mem_");
                    Integer _portIdFromName = this.getPortIdFromName(monitor_2.replace("count_in_tokens_", ""));
                    int _plus_90 = ((_portIdFromName).intValue() + 1);
                    _builder.append(_plus_90, "        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" + 1;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("else ");
                    _builder.newLine();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("end");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.newLine();
                  }
                }
                {
                  boolean _contains_2 = monitor_2.contains("count_out_tokens_");
                  if (_contains_2) {
                    _builder.append("// monitoring output tokens (of port ");
                    String _replace_3 = monitor_2.replace("count_out_tokens_", "");
                    _builder.append(_replace_3);
                    _builder.append(")\t\t");
                    _builder.newLineIfNotEmpty();
                    _builder.append("always@(posedge s00_axi_aclk or negedge s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("    ");
                    _builder.append("if(!s00_axi_aresetn)");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append(monitor_2, "        ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("end ");
                    _builder.newLine();
                    _builder.append("    ");
                    _builder.append("else");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("begin");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.append("if(clear_monitor_");
                    int _indexOf_7 = this.monList.indexOf(monitor_2);
                    _builder.append(_indexOf_7, "        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= 0;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("else if(wren_mem_");
                    Integer _portIdFromName_1 = this.getPortIdFromName(monitor_2.replace("count_out_tokens_", ""));
                    int _plus_91 = ((_portIdFromName_1).intValue() + 1);
                    _builder.append(_plus_91, "        ");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" + 1;");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("else ");
                    _builder.newLine();
                    _builder.append("            ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(" <= ");
                    _builder.append(monitor_2, "            ");
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                    _builder.append("        ");
                    _builder.append("end");
                    _builder.newLine();
                    _builder.append("        ");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
        _builder.newLine();
        _builder.append("// Coprocessor Front-End(s)");
        _builder.newLine();
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        {
          Set<Port> _keySet_6 = this.inputMap.keySet();
          for(final Port input : _keySet_6) {
            _builder.append("front_end i_front_end_");
            String _name_1 = input.getName();
            _builder.append(_name_1);
            _builder.append("(");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aclk(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_86 = this.portMap.get(input);
                int _plus_92 = ((_get_86).intValue() + 1);
                String _longId_54 = this.getLongId(_plus_92);
                _builder.append(_longId_54, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aclk),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aresetn(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_87 = this.portMap.get(input);
                int _plus_93 = ((_get_87).intValue() + 1);
                String _longId_55 = this.getLongId(_plus_93);
                _builder.append(_longId_55, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aresetn),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".start(start),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".zero(slv_reg");
            Integer _get_88 = this.portMap.get(input);
            int _plus_94 = ((_get_88).intValue() + 1);
            _builder.append(_plus_94, "\t");
            _builder.append("[SIZE_ADDR_");
            Integer _get_89 = this.portMap.get(input);
            int _plus_95 = ((_get_89).intValue() + 1);
            _builder.append(_plus_95, "\t");
            _builder.append("-1:0]=={SIZE_ADDR_");
            Integer _get_90 = this.portMap.get(input);
            int _plus_96 = ((_get_90).intValue() + 1);
            _builder.append(_plus_96, "\t");
            _builder.append("{1\'b1}}),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".last(last_");
            String _name_2 = input.getName();
            _builder.append(_name_2, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".full(");
            {
              boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFullChannelWrapCommSignalID());
              if (_isNegMatchingWrapMapping) {
                _builder.append("!");
              }
            }
            String _name_3 = input.getName();
            _builder.append(_name_3, "\t");
            _builder.append("_full),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en(en_");
            String _name_4 = input.getName();
            _builder.append(_name_4, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".rden(rden_mem_");
            Integer _get_91 = this.portMap.get(input);
            int _plus_97 = ((_get_91).intValue() + 1);
            _builder.append(_plus_97, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".wr(");
            String _name_5 = input.getName();
            _builder.append(_name_5, "\t");
            _builder.append("_push),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".done(done_");
            String _name_6 = input.getName();
            _builder.append(_name_6, "\t");
            _builder.append(")\t");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
            _builder.newLine();
            _builder.append("counter #(\t\t\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".SIZE(SIZE_ADDR_");
            Integer _get_92 = this.portMap.get(input);
            int _plus_98 = ((_get_92).intValue() + 1);
            _builder.append(_plus_98, "\t");
            _builder.append(") ) ");
            _builder.newLineIfNotEmpty();
            _builder.append("i_counter_");
            String _name_7 = input.getName();
            _builder.append(_name_7);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aclk(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_93 = this.portMap.get(input);
                int _plus_99 = ((_get_93).intValue() + 1);
                String _longId_56 = this.getLongId(_plus_99);
                _builder.append(_longId_56, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aclk),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aresetn(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_94 = this.portMap.get(input);
                int _plus_100 = ((_get_94).intValue() + 1);
                String _longId_57 = this.getLongId(_plus_100);
                _builder.append(_longId_57, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aresetn),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".clr(slv_reg0[2]),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en(en_");
            String _name_8 = input.getName();
            _builder.append(_name_8, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".max(slv_reg");
            Integer _get_95 = this.portMap.get(input);
            int _plus_101 = ((_get_95).intValue() + 1);
            _builder.append(_plus_101, "\t");
            _builder.append("[SIZE_ADDR_");
            Integer _get_96 = this.portMap.get(input);
            int _plus_102 = ((_get_96).intValue() + 1);
            _builder.append(_plus_102, "\t");
            _builder.append("-1:0]),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".count(count_");
            String _name_9 = input.getName();
            _builder.append(_name_9, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".last(last_");
            String _name_10 = input.getName();
            _builder.append(_name_10, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
            _builder.newLine();
            _builder.append("assign address_mem_");
            Integer _get_97 = this.portMap.get(input);
            int _plus_103 = ((_get_97).intValue() + 1);
            _builder.append(_plus_103);
            _builder.append(" = count_");
            String _name_11 = input.getName();
            _builder.append(_name_11);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("assign wren_mem_");
            Integer _get_98 = this.portMap.get(input);
            int _plus_104 = ((_get_98).intValue() + 1);
            _builder.append(_plus_104);
            _builder.append(" = 1\'b0;");
            _builder.newLineIfNotEmpty();
            _builder.append("assign data_in_mem_");
            Integer _get_99 = this.portMap.get(input);
            int _plus_105 = ((_get_99).intValue() + 1);
            _builder.append(_plus_105);
            _builder.append(" = {");
            int _dataSize_5 = this.protocolManager.getDataSize(input);
            _builder.append(_dataSize_5);
            _builder.append("{1\'b0}};");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t\t");
        _builder.newLine();
        _builder.append("assign done_input = ");
        {
          Set<Port> _keySet_7 = this.inputMap.keySet();
          boolean _hasElements_2 = false;
          for(final Port input_1 : _keySet_7) {
            if (!_hasElements_2) {
              _hasElements_2 = true;
            } else {
              _builder.appendImmediate(" && ", "");
            }
            _builder.append("done_");
            String _name_12 = input_1.getName();
            _builder.append(_name_12);
          }
        }
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("// Multi-Dataflow Reconfigurable Datapath");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    CharSequence _printTopDatapath = this.printTopDatapath(network);
    _builder.append(_printTopDatapath);
    _builder.newLineIfNotEmpty();
    {
      boolean _equals_3 = this.coupling.equals("mm");
      if (_equals_3) {
        {
          Set<Port> _keySet_8 = this.inputMap.keySet();
          for(final Port input_2 : _keySet_8) {
            _builder.append("assign ");
            String _name_13 = input_2.getName();
            _builder.append(_name_13);
            _builder.append("_data = data_out_mem_");
            Integer _get_100 = this.portMap.get(input_2);
            int _plus_106 = ((_get_100).intValue() + 1);
            _builder.append(_plus_106);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          Set<Port> _keySet_9 = this.outputMap.keySet();
          for(final Port output_1 : _keySet_9) {
            _builder.append("assign data_in_mem_");
            Integer _get_101 = this.portMap.get(output_1);
            int _plus_107 = ((_get_101).intValue() + 1);
            _builder.append(_plus_107);
            _builder.append(" = ");
            String _name_14 = output_1.getName();
            _builder.append(_name_14);
            _builder.append("_data;");
            _builder.newLineIfNotEmpty();
          }
        }
      } else {
        {
          Set<Port> _keySet_10 = this.inputMap.keySet();
          for(final Port input_3 : _keySet_10) {
            _builder.append("assign s");
            String _longId_58 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_58);
            _builder.append("_axis_tready = ");
            {
              boolean _isNegMatchingWrapMapping_1 = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getFullChannelWrapCommSignalID());
              boolean _not = (!_isNegMatchingWrapMapping_1);
              if (_not) {
                _builder.append("!");
              }
            }
            String _name_15 = input_3.getName();
            _builder.append(_name_15);
            _builder.append("_full;");
            _builder.newLineIfNotEmpty();
            _builder.append("assign ");
            String _name_16 = input_3.getName();
            _builder.append(_name_16);
            _builder.append("_data = s");
            String _longId_59 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_59);
            _builder.append("_axis_tdata");
            {
              int _dataSize_6 = this.protocolManager.getDataSize(input_3);
              boolean _lessThan_3 = (_dataSize_6 < 32);
              if (_lessThan_3) {
                _builder.append(" [");
                int _dataSize_7 = this.protocolManager.getDataSize(input_3);
                int _minus_1 = (_dataSize_7 - 1);
                _builder.append(_minus_1);
                _builder.append(" : 0]");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("//assign = s");
            String _longId_60 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_60);
            _builder.append("_axis_tkeep;");
            _builder.newLineIfNotEmpty();
            _builder.append("//assign = s");
            String _longId_61 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_61);
            _builder.append("_axis_tlast;");
            _builder.newLineIfNotEmpty();
            _builder.append("assign ");
            String _name_17 = input_3.getName();
            _builder.append(_name_17);
            _builder.append("_push = s");
            String _longId_62 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_62);
            _builder.append("_axis_tvalid & s");
            String _longId_63 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_63);
            _builder.append("_axis_tready;");
            _builder.newLineIfNotEmpty();
            _builder.append("//assign = s");
            String _longId_64 = this.getLongId((this.inputMap.get(input_3)).intValue());
            _builder.append(_longId_64);
            _builder.append("_axis_data_count;");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          Set<Port> _keySet_11 = this.outputMap.keySet();
          for(final Port output_2 : _keySet_11) {
            _builder.append("assign m");
            String _longId_65 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_65);
            _builder.append("_axis_tvalid = ");
            String _name_18 = output_2.getName();
            _builder.append(_name_18);
            _builder.append("_push;");
            _builder.newLineIfNotEmpty();
            _builder.append("assign m");
            String _longId_66 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_66);
            _builder.append("_axis_tdata = ");
            {
              int _dataSize_8 = this.protocolManager.getDataSize(output_2);
              boolean _lessThan_4 = (_dataSize_8 < 32);
              if (_lessThan_4) {
                _builder.append("{{");
                int _dataSize_9 = this.protocolManager.getDataSize(output_2);
                int _minus_2 = (32 - _dataSize_9);
                _builder.append(_minus_2);
                _builder.append("{1\'b0}},");
              }
            }
            String _name_19 = output_2.getName();
            _builder.append(_name_19);
            _builder.append("_data");
            {
              int _dataSize_10 = this.protocolManager.getDataSize(output_2);
              boolean _lessThan_5 = (_dataSize_10 < 32);
              if (_lessThan_5) {
                _builder.append("}");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("assign m");
            String _longId_67 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_67);
            _builder.append("_axis_tkeep = {(C_M");
            String _longId_68 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_68);
            _builder.append("_AXIS_TDATA_WIDTH/8){1\'b1}};");
            _builder.newLineIfNotEmpty();
            _builder.append("//assign m");
            String _longId_69 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_69);
            _builder.append("_axis_tlast = 1\'b0;");
            _builder.newLineIfNotEmpty();
            _builder.append("assign ");
            String _name_20 = output_2.getName();
            _builder.append(_name_20);
            _builder.append("_full = !m");
            String _longId_70 = this.getLongId((this.outputMap.get(output_2)).intValue());
            _builder.append(_longId_70);
            _builder.append("_axis_tready;");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("// ----------------------------------------------------------------------------\t");
    _builder.newLine();
    _builder.newLine();
    {
      boolean _equals_4 = this.coupling.equals("mm");
      if (_equals_4) {
        _builder.append("// Coprocessor Back-End(s)");
        _builder.newLine();
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        {
          Set<Port> _keySet_12 = this.outputMap.keySet();
          for(final Port output_3 : _keySet_12) {
            _builder.append("back_end i_back_end_");
            String _name_21 = output_3.getName();
            _builder.append(_name_21);
            _builder.append("(");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aclk(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_102 = this.portMap.get(output_3);
                int _plus_108 = ((_get_102).intValue() + 1);
                String _longId_71 = this.getLongId(_plus_108);
                _builder.append(_longId_71, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aclk),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aresetn(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_103 = this.portMap.get(output_3);
                int _plus_109 = ((_get_103).intValue() + 1);
                String _longId_72 = this.getLongId(_plus_109);
                _builder.append(_longId_72, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aresetn),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".start(start),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".zero(slv_reg");
            Integer _get_104 = this.portMap.get(output_3);
            int _plus_110 = ((_get_104).intValue() + 1);
            _builder.append(_plus_110, "\t");
            _builder.append("[SIZE_ADDR_");
            Integer _get_105 = this.portMap.get(output_3);
            int _plus_111 = ((_get_105).intValue() + 1);
            _builder.append(_plus_111, "\t");
            _builder.append("-1:0]=={SIZE_ADDR_");
            Integer _get_106 = this.portMap.get(output_3);
            int _plus_112 = ((_get_106).intValue() + 1);
            _builder.append(_plus_112, "\t");
            _builder.append("{1\'b1}}),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".last(last_");
            String _name_22 = output_3.getName();
            _builder.append(_name_22, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".wr(");
            String _name_23 = output_3.getName();
            _builder.append(_name_23, "\t");
            _builder.append("_push),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".wren(wren_mem_");
            Integer _get_107 = this.portMap.get(output_3);
            int _plus_113 = ((_get_107).intValue() + 1);
            _builder.append(_plus_113, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en(en_");
            String _name_24 = output_3.getName();
            _builder.append(_name_24, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".full(");
            String _name_25 = output_3.getName();
            _builder.append(_name_25, "\t");
            _builder.append("_full),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".done(done_");
            String _name_26 = output_3.getName();
            _builder.append(_name_26, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
            _builder.newLine();
            _builder.append("counter #(\t\t\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".SIZE(SIZE_ADDR_");
            Integer _get_108 = this.portMap.get(output_3);
            int _plus_114 = ((_get_108).intValue() + 1);
            _builder.append(_plus_114, "\t");
            _builder.append(") ) ");
            _builder.newLineIfNotEmpty();
            _builder.append("i_counter_");
            String _name_27 = output_3.getName();
            _builder.append(_name_27);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aclk(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_109 = this.portMap.get(output_3);
                int _plus_115 = ((_get_109).intValue() + 1);
                String _longId_73 = this.getLongId(_plus_115);
                _builder.append(_longId_73, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aclk),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aresetn(s");
            {
              if (this.dedicatedInterfaces) {
                Integer _get_110 = this.portMap.get(output_3);
                int _plus_116 = ((_get_110).intValue() + 1);
                String _longId_74 = this.getLongId(_plus_116);
                _builder.append(_longId_74, "\t");
              } else {
                _builder.append("01");
              }
            }
            _builder.append("_axi_aresetn),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".clr(slv_reg0[2]),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en(en_");
            String _name_28 = output_3.getName();
            _builder.append(_name_28, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".max(slv_reg");
            Integer _get_111 = this.portMap.get(output_3);
            int _plus_117 = ((_get_111).intValue() + 1);
            _builder.append(_plus_117, "\t");
            _builder.append("[SIZE_ADDR_");
            Integer _get_112 = this.portMap.get(output_3);
            int _plus_118 = ((_get_112).intValue() + 1);
            _builder.append(_plus_118, "\t");
            _builder.append("-1:0]),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".count(count_");
            String _name_29 = output_3.getName();
            _builder.append(_name_29, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".last(last_");
            String _name_30 = output_3.getName();
            _builder.append(_name_30, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
            _builder.newLine();
            _builder.append("assign address_mem_");
            Integer _get_113 = this.portMap.get(output_3);
            int _plus_119 = ((_get_113).intValue() + 1);
            _builder.append(_plus_119);
            _builder.append(" = count_");
            String _name_31 = output_3.getName();
            _builder.append(_name_31);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("assign rden_mem_");
            Integer _get_114 = this.portMap.get(output_3);
            int _plus_120 = ((_get_114).intValue() + 1);
            _builder.append(_plus_120);
            _builder.append(" = 1\'b0;");
            _builder.newLineIfNotEmpty();
            _builder.newLine();
          }
        }
        _builder.append("assign done_output = ");
        {
          Set<Port> _keySet_13 = this.outputMap.keySet();
          boolean _hasElements_3 = false;
          for(final Port output_4 : _keySet_13) {
            if (!_hasElements_3) {
              _hasElements_3 = true;
            } else {
              _builder.appendImmediate(" && ", "");
            }
            _builder.append("done_");
            String _name_32 = output_4.getName();
            _builder.append(_name_32);
          }
        }
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("assign done = done_input && done_output;");
        _builder.newLine();
        _builder.newLine();
      } else {
        _builder.newLine();
        {
          Set<Port> _keySet_14 = this.outputMap.keySet();
          for(final Port output_5 : _keySet_14) {
            _builder.append("// Output Counter(s)");
            _builder.newLine();
            _builder.append("// ----------------------------------------------------------------------------");
            _builder.newLine();
            _builder.append("counter #(\t\t\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".SIZE(SIZE_COUNT_");
            Integer _get_115 = this.portMap.get(output_5);
            int _plus_121 = ((_get_115).intValue() + 1);
            _builder.append(_plus_121, "\t");
            _builder.append(") ) ");
            _builder.newLineIfNotEmpty();
            _builder.append("i_counter_");
            String _name_33 = output_5.getName();
            _builder.append(_name_33);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".aclk(s00_axi_aclk),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".aresetn(s00_axi_aresetn),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".clr(slv_reg0[2]),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Advance the packet counter only on an accepted AXI-Stream beat.");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en(m");
            String _longId_75 = this.getLongId((this.outputMap.get(output_5)).intValue());
            _builder.append(_longId_75, "\t");
            _builder.append("_axis_tvalid & m");
            String _longId_76 = this.getLongId((this.outputMap.get(output_5)).intValue());
            _builder.append(_longId_76, "\t");
            _builder.append("_axis_tready),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".max(slv_reg");
            Integer _get_116 = this.outputMap.get(output_5);
            int _plus_122 = ((_get_116).intValue() + 1);
            _builder.append(_plus_122, "\t");
            _builder.append("[SIZE_COUNT_");
            Integer _get_117 = this.portMap.get(output_5);
            int _plus_123 = ((_get_117).intValue() + 1);
            _builder.append(_plus_123, "\t");
            _builder.append("-1:0]),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".count(),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".last(m");
            String _longId_77 = this.getLongId((this.outputMap.get(output_5)).intValue());
            _builder.append(_longId_77, "\t");
            _builder.append("_axis_tlast)");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printTopDatapath(final Network network) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// to adapt profiling");
    _builder.newLine();
    _builder.append("multi_dataflow reconf_dpath (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Multi-Dataflow Input(s)");
    _builder.newLine();
    {
      Set<Port> _keySet = this.inputMap.keySet();
      for(final Port input : _keySet) {
        {
          Set<String> _keySet_1 = this.protocolManager.getInFirstModCommSignals().keySet();
          for(final String commSigId : _keySet_1) {
            _builder.append("\t");
            _builder.append(".");
            String _name = input.getName();
            _builder.append(_name, "\t");
            String _suffix = this.getSuffix(this.protocolManager.getInFirstModCommSignals(), commSigId);
            _builder.append(_suffix, "\t");
            _builder.append("(");
            String _name_1 = input.getName();
            _builder.append(_name_1, "\t");
            _builder.append("_");
            String _matchingWrapMapping = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("// Multi-Dataflow Output(s)");
    _builder.newLine();
    {
      Set<Port> _keySet_2 = this.outputMap.keySet();
      for(final Port output : _keySet_2) {
        {
          Set<String> _keySet_3 = this.protocolManager.getOutLastModCommSignals().keySet();
          for(final String commSigId_1 : _keySet_3) {
            _builder.append("\t");
            _builder.append(".");
            String _name_2 = output.getName();
            _builder.append(_name_2, "\t");
            String _suffix_1 = this.getSuffix(this.protocolManager.getOutLastModCommSignals(), commSigId_1);
            _builder.append(_suffix_1, "\t");
            _builder.append("(");
            {
              boolean _isNegMatchingWrapMapping = this.protocolManager.isNegMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
              if (_isNegMatchingWrapMapping) {
                _builder.append("!");
              }
            }
            String _name_3 = output.getName();
            _builder.append(_name_3, "\t");
            _builder.append("_");
            String _matchingWrapMapping_1 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping_1, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("// Monitoring");
    _builder.newLine();
    {
      EList<Connection> _connections = network.getConnections();
      for(final Connection connection : _connections) {
        {
          boolean _hasAttribute = connection.hasAttribute("monitor_in");
          if (_hasAttribute) {
            {
              Set<String> _keySet_4 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_2 : _keySet_4) {
                {
                  boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId_2);
                  if (_isInputSide) {
                    _builder.append("\t");
                    _builder.append(".");
                    String _targetSignal = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId_2);
                    _builder.append(_targetSignal, "\t");
                    _builder.append("(");
                    String _targetSignal_1 = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId_2);
                    _builder.append(_targetSignal_1, "\t");
                    _builder.append("),");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("// System Signal(s)");
    _builder.newLine();
    {
      ArrayList<String> _clockSysSignals = this.protocolManager.getClockSysSignals();
      for(final String clockSignal : _clockSysSignals) {
        _builder.append("\t");
        _builder.append(".");
        _builder.append(clockSignal, "\t");
        _builder.append("(s00_axi_aclk)");
        {
          boolean _not = (!(this.protocolManager.getResetSysSignals().isEmpty() && this.luts.isEmpty()));
          if (_not) {
            _builder.append(",");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<String> _keySet_5 = this.protocolManager.getResetSysSignals().keySet();
      for(final String resetSignal : _keySet_5) {
        _builder.append("\t");
        _builder.append(".");
        _builder.append(resetSignal, "\t");
        _builder.append("(");
        {
          boolean _equals = this.protocolManager.getResetSysSignals().get(resetSignal).equals("HIGH");
          if (_equals) {
            _builder.append("!");
          }
        }
        _builder.append("s00_axi_aresetn)");
        {
          boolean _isEmpty = this.luts.isEmpty();
          boolean _not_1 = (!_isEmpty);
          if (_not_1) {
            _builder.append(",");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    {
      boolean _isEmpty_1 = this.luts.isEmpty();
      boolean _not_2 = (!_isEmpty_1);
      if (_not_2) {
        _builder.append("// Multi-Dataflow Kernel ID");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".ID(slv_reg0[31:24])");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append(");");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printTopHeaderComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// This file has been automatically generated by:");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Template Interface Layer module - Memory-Mapped type");
      _builder.newLine();
      _builder.append("// on ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// More info available at http://sites.unica.it/rpct/");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printTopInterface(final Network network) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module ");
    _builder.append(this.coupling);
    _builder.append("_accelerator#");
    _builder.newLineIfNotEmpty();
    _builder.append("(");
    _builder.newLine();
    {
      boolean _equals = this.coupling.equals("mm");
      if (_equals) {
        {
          if (this.dedicatedInterfaces) {
            {
              Set<Port> _keySet = this.portMap.keySet();
              for(final Port port : _keySet) {
                _builder.append("\t");
                _builder.append("// Parameters of Axi Slave Bus Interface S");
                Integer _get = this.portMap.get(port);
                int _plus = ((_get).intValue() + 1);
                _builder.append(_plus, "\t");
                _builder.append("_AXI");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_1 = this.portMap.get(port);
                int _plus_1 = ((_get_1).intValue() + 1);
                String _longId = this.getLongId(_plus_1);
                _builder.append(_longId, "\t");
                _builder.append("_AXI_ID_WIDTH\t= 1,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_2 = this.portMap.get(port);
                int _plus_2 = ((_get_2).intValue() + 1);
                String _longId_1 = this.getLongId(_plus_2);
                _builder.append(_longId_1, "\t");
                _builder.append("_AXI_DATA_WIDTH\t= 32,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_3 = this.portMap.get(port);
                int _plus_3 = ((_get_3).intValue() + 1);
                String _longId_2 = this.getLongId(_plus_3);
                _builder.append(_longId_2, "\t");
                _builder.append("_AXI_ADDR_WIDTH\t= 16,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_4 = this.portMap.get(port);
                int _plus_4 = ((_get_4).intValue() + 1);
                String _longId_3 = this.getLongId(_plus_4);
                _builder.append(_longId_3, "\t");
                _builder.append("_AXI_AWUSER_WIDTH\t= 0,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_5 = this.portMap.get(port);
                int _plus_5 = ((_get_5).intValue() + 1);
                String _longId_4 = this.getLongId(_plus_5);
                _builder.append(_longId_4, "\t");
                _builder.append("_AXI_ARUSER_WIDTH\t= 0,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_6 = this.portMap.get(port);
                int _plus_6 = ((_get_6).intValue() + 1);
                String _longId_5 = this.getLongId(_plus_6);
                _builder.append(_longId_5, "\t");
                _builder.append("_AXI_WUSER_WIDTH\t= 0,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_7 = this.portMap.get(port);
                int _plus_7 = ((_get_7).intValue() + 1);
                String _longId_6 = this.getLongId(_plus_7);
                _builder.append(_longId_6, "\t");
                _builder.append("_AXI_RUSER_WIDTH\t= 0,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("parameter integer C_S");
                Integer _get_8 = this.portMap.get(port);
                int _plus_8 = ((_get_8).intValue() + 1);
                String _longId_7 = this.getLongId(_plus_8);
                _builder.append(_longId_7, "\t");
                _builder.append("_AXI_BUSER_WIDTH\t= 0,");
                _builder.newLineIfNotEmpty();
              }
            }
          } else {
            _builder.append("\t");
            _builder.append("// Parameters of Axi Slave Bus Interface S01_AXI");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_ID_WIDTH\t= 1,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_DATA_WIDTH\t= 32,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_ADDR_WIDTH\t= 16,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_AWUSER_WIDTH\t= 0,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_ARUSER_WIDTH\t= 0,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_WUSER_WIDTH\t= 0,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_RUSER_WIDTH\t= 0,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("parameter integer C_S01_AXI_BUSER_WIDTH\t= 0,");
            _builder.newLine();
          }
        }
      } else {
        _builder.append("\t");
        {
          Set<Port> _keySet_1 = this.inputMap.keySet();
          for(final Port input : _keySet_1) {
            _builder.append("// Parameters of Axi Slave Bus Interface S");
            String _longId_8 = this.getLongId((this.inputMap.get(input)).intValue());
            _builder.append(_longId_8, "\t");
            _builder.append("_AXIS");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("parameter integer C_S");
            String _longId_9 = this.getLongId((this.inputMap.get(input)).intValue());
            _builder.append(_longId_9, "\t");
            _builder.append("_AXIS_TDATA_WIDTH\t= ");
            _builder.append(CoprocessorSpec.STREAM_WORD_BITS, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.newLine();
        _builder.append("\t");
        {
          Set<Port> _keySet_2 = this.outputMap.keySet();
          for(final Port output : _keySet_2) {
            _builder.append("// Parameters of Axi Master Bus Interface M");
            String _longId_10 = this.getLongId((this.outputMap.get(output)).intValue());
            _builder.append(_longId_10, "\t");
            _builder.append("_AXIS");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("parameter integer C_M");
            String _longId_11 = this.getLongId((this.outputMap.get(output)).intValue());
            _builder.append(_longId_11, "\t");
            _builder.append("_AXIS_TDATA_WIDTH\t= ");
            _builder.append(CoprocessorSpec.STREAM_WORD_BITS, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("parameter integer C_M");
            String _longId_12 = this.getLongId((this.outputMap.get(output)).intValue());
            _builder.append(_longId_12, "\t");
            _builder.append("_AXIS_START_COUNT\t= 32,");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Parameters of Axi Slave Bus Interface S00_AXI");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("parameter integer C_S00_AXI_DATA_WIDTH\t= 32,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("parameter integer C_S00_AXI_ADDR_WIDTH\t= ");
    {
      if ((this.controlAddressBits > 0)) {
        _builder.append(this.controlAddressBits, "\t");
      } else {
        int _computeSizePointer = this.computeSizePointer();
        int _plus_9 = (_computeSizePointer + 2);
        _builder.append(_plus_9, "\t");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append(")");
    _builder.newLine();
    _builder.append("(");
    _builder.newLine();
    {
      boolean _equals_1 = this.coupling.equals("mm");
      if (_equals_1) {
        {
          if (this.dedicatedInterfaces) {
            {
              Set<Port> _keySet_3 = this.portMap.keySet();
              for(final Port port_1 : _keySet_3) {
                _builder.append("\t");
                _builder.append("// Ports of Axi Slave Bus Interface S");
                Integer _get_9 = this.portMap.get(port_1);
                int _plus_10 = ((_get_9).intValue() + 1);
                String _longId_13 = this.getLongId(_plus_10);
                _builder.append(_longId_13, "\t");
                _builder.append("_AXI");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_10 = this.portMap.get(port_1);
                int _plus_11 = ((_get_10).intValue() + 1);
                String _longId_14 = this.getLongId(_plus_11);
                _builder.append(_longId_14, "\t");
                _builder.append("_axi_aclk,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_11 = this.portMap.get(port_1);
                int _plus_12 = ((_get_11).intValue() + 1);
                String _longId_15 = this.getLongId(_plus_12);
                _builder.append(_longId_15, "\t");
                _builder.append("_axi_aresetn,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_ID_WIDTH-1 : 0] s");
                Integer _get_12 = this.portMap.get(port_1);
                int _plus_13 = ((_get_12).intValue() + 1);
                String _longId_16 = this.getLongId(_plus_13);
                _builder.append(_longId_16, "\t");
                _builder.append("_axi_awid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_ADDR_WIDTH-1 : 0] s");
                Integer _get_13 = this.portMap.get(port_1);
                int _plus_14 = ((_get_13).intValue() + 1);
                String _longId_17 = this.getLongId(_plus_14);
                _builder.append(_longId_17, "\t");
                _builder.append("_axi_awaddr,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [7 : 0] s");
                Integer _get_14 = this.portMap.get(port_1);
                int _plus_15 = ((_get_14).intValue() + 1);
                String _longId_18 = this.getLongId(_plus_15);
                _builder.append(_longId_18, "\t");
                _builder.append("_axi_awlen,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [2 : 0] s");
                Integer _get_15 = this.portMap.get(port_1);
                int _plus_16 = ((_get_15).intValue() + 1);
                String _longId_19 = this.getLongId(_plus_16);
                _builder.append(_longId_19, "\t");
                _builder.append("_axi_awsize,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [1 : 0] s");
                Integer _get_16 = this.portMap.get(port_1);
                int _plus_17 = ((_get_16).intValue() + 1);
                String _longId_20 = this.getLongId(_plus_17);
                _builder.append(_longId_20, "\t");
                _builder.append("_axi_awburst,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_17 = this.portMap.get(port_1);
                int _plus_18 = ((_get_17).intValue() + 1);
                String _longId_21 = this.getLongId(_plus_18);
                _builder.append(_longId_21, "\t");
                _builder.append("_axi_awlock,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_18 = this.portMap.get(port_1);
                int _plus_19 = ((_get_18).intValue() + 1);
                String _longId_22 = this.getLongId(_plus_19);
                _builder.append(_longId_22, "\t");
                _builder.append("_axi_awcache,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [2 : 0] s");
                Integer _get_19 = this.portMap.get(port_1);
                int _plus_20 = ((_get_19).intValue() + 1);
                String _longId_23 = this.getLongId(_plus_20);
                _builder.append(_longId_23, "\t");
                _builder.append("_axi_awprot,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_20 = this.portMap.get(port_1);
                int _plus_21 = ((_get_20).intValue() + 1);
                String _longId_24 = this.getLongId(_plus_21);
                _builder.append(_longId_24, "\t");
                _builder.append("_axi_awqos,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_21 = this.portMap.get(port_1);
                int _plus_22 = ((_get_21).intValue() + 1);
                String _longId_25 = this.getLongId(_plus_22);
                _builder.append(_longId_25, "\t");
                _builder.append("_axi_awregion,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_AWUSER_WIDTH-1 : 0] s");
                Integer _get_22 = this.portMap.get(port_1);
                int _plus_23 = ((_get_22).intValue() + 1);
                String _longId_26 = this.getLongId(_plus_23);
                _builder.append(_longId_26, "\t");
                _builder.append("_axi_awuser,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_23 = this.portMap.get(port_1);
                int _plus_24 = ((_get_23).intValue() + 1);
                String _longId_27 = this.getLongId(_plus_24);
                _builder.append(_longId_27, "\t");
                _builder.append("_axi_awvalid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_24 = this.portMap.get(port_1);
                int _plus_25 = ((_get_24).intValue() + 1);
                String _longId_28 = this.getLongId(_plus_25);
                _builder.append(_longId_28, "\t");
                _builder.append("_axi_awready,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_DATA_WIDTH-1 : 0] s");
                Integer _get_25 = this.portMap.get(port_1);
                int _plus_26 = ((_get_25).intValue() + 1);
                String _longId_29 = this.getLongId(_plus_26);
                _builder.append(_longId_29, "\t");
                _builder.append("_axi_wdata,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [(C_S01_AXI_DATA_WIDTH/8)-1 : 0] s");
                Integer _get_26 = this.portMap.get(port_1);
                int _plus_27 = ((_get_26).intValue() + 1);
                String _longId_30 = this.getLongId(_plus_27);
                _builder.append(_longId_30, "\t");
                _builder.append("_axi_wstrb,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_27 = this.portMap.get(port_1);
                int _plus_28 = ((_get_27).intValue() + 1);
                String _longId_31 = this.getLongId(_plus_28);
                _builder.append(_longId_31, "\t");
                _builder.append("_axi_wlast,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_WUSER_WIDTH-1 : 0] s");
                Integer _get_28 = this.portMap.get(port_1);
                int _plus_29 = ((_get_28).intValue() + 1);
                String _longId_32 = this.getLongId(_plus_29);
                _builder.append(_longId_32, "\t");
                _builder.append("_axi_wuser,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_29 = this.portMap.get(port_1);
                int _plus_30 = ((_get_29).intValue() + 1);
                String _longId_33 = this.getLongId(_plus_30);
                _builder.append(_longId_33, "\t");
                _builder.append("_axi_wvalid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_30 = this.portMap.get(port_1);
                int _plus_31 = ((_get_30).intValue() + 1);
                String _longId_34 = this.getLongId(_plus_31);
                _builder.append(_longId_34, "\t");
                _builder.append("_axi_wready,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [C_S01_AXI_ID_WIDTH-1 : 0] s");
                Integer _get_31 = this.portMap.get(port_1);
                int _plus_32 = ((_get_31).intValue() + 1);
                String _longId_35 = this.getLongId(_plus_32);
                _builder.append(_longId_35, "\t");
                _builder.append("_axi_bid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [1 : 0] s");
                Integer _get_32 = this.portMap.get(port_1);
                int _plus_33 = ((_get_32).intValue() + 1);
                String _longId_36 = this.getLongId(_plus_33);
                _builder.append(_longId_36, "\t");
                _builder.append("_axi_bresp,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [C_S01_AXI_BUSER_WIDTH-1 : 0] s");
                Integer _get_33 = this.portMap.get(port_1);
                int _plus_34 = ((_get_33).intValue() + 1);
                String _longId_37 = this.getLongId(_plus_34);
                _builder.append(_longId_37, "\t");
                _builder.append("_axi_buser,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_34 = this.portMap.get(port_1);
                int _plus_35 = ((_get_34).intValue() + 1);
                String _longId_38 = this.getLongId(_plus_35);
                _builder.append(_longId_38, "\t");
                _builder.append("_axi_bvalid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_35 = this.portMap.get(port_1);
                int _plus_36 = ((_get_35).intValue() + 1);
                String _longId_39 = this.getLongId(_plus_36);
                _builder.append(_longId_39, "\t");
                _builder.append("_axi_bready,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_ID_WIDTH-1 : 0] s");
                Integer _get_36 = this.portMap.get(port_1);
                int _plus_37 = ((_get_36).intValue() + 1);
                String _longId_40 = this.getLongId(_plus_37);
                _builder.append(_longId_40, "\t");
                _builder.append("_axi_arid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_ADDR_WIDTH-1 : 0] s");
                Integer _get_37 = this.portMap.get(port_1);
                int _plus_38 = ((_get_37).intValue() + 1);
                String _longId_41 = this.getLongId(_plus_38);
                _builder.append(_longId_41, "\t");
                _builder.append("_axi_araddr,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [7 : 0] s");
                Integer _get_38 = this.portMap.get(port_1);
                int _plus_39 = ((_get_38).intValue() + 1);
                String _longId_42 = this.getLongId(_plus_39);
                _builder.append(_longId_42, "\t");
                _builder.append("_axi_arlen,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [2 : 0] s");
                Integer _get_39 = this.portMap.get(port_1);
                int _plus_40 = ((_get_39).intValue() + 1);
                String _longId_43 = this.getLongId(_plus_40);
                _builder.append(_longId_43, "\t");
                _builder.append("_axi_arsize,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [1 : 0] s");
                Integer _get_40 = this.portMap.get(port_1);
                int _plus_41 = ((_get_40).intValue() + 1);
                String _longId_44 = this.getLongId(_plus_41);
                _builder.append(_longId_44, "\t");
                _builder.append("_axi_arburst,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_41 = this.portMap.get(port_1);
                int _plus_42 = ((_get_41).intValue() + 1);
                String _longId_45 = this.getLongId(_plus_42);
                _builder.append(_longId_45, "\t");
                _builder.append("_axi_arlock,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_42 = this.portMap.get(port_1);
                int _plus_43 = ((_get_42).intValue() + 1);
                String _longId_46 = this.getLongId(_plus_43);
                _builder.append(_longId_46, "\t");
                _builder.append("_axi_arcache,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [2 : 0] s");
                Integer _get_43 = this.portMap.get(port_1);
                int _plus_44 = ((_get_43).intValue() + 1);
                String _longId_47 = this.getLongId(_plus_44);
                _builder.append(_longId_47, "\t");
                _builder.append("_axi_arprot,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_44 = this.portMap.get(port_1);
                int _plus_45 = ((_get_44).intValue() + 1);
                String _longId_48 = this.getLongId(_plus_45);
                _builder.append(_longId_48, "\t");
                _builder.append("_axi_arqos,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [3 : 0] s");
                Integer _get_45 = this.portMap.get(port_1);
                int _plus_46 = ((_get_45).intValue() + 1);
                String _longId_49 = this.getLongId(_plus_46);
                _builder.append(_longId_49, "\t");
                _builder.append("_axi_arregion,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire [C_S01_AXI_ARUSER_WIDTH-1 : 0] s");
                Integer _get_46 = this.portMap.get(port_1);
                int _plus_47 = ((_get_46).intValue() + 1);
                String _longId_50 = this.getLongId(_plus_47);
                _builder.append(_longId_50, "\t");
                _builder.append("_axi_aruser,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_47 = this.portMap.get(port_1);
                int _plus_48 = ((_get_47).intValue() + 1);
                String _longId_51 = this.getLongId(_plus_48);
                _builder.append(_longId_51, "\t");
                _builder.append("_axi_arvalid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_48 = this.portMap.get(port_1);
                int _plus_49 = ((_get_48).intValue() + 1);
                String _longId_52 = this.getLongId(_plus_49);
                _builder.append(_longId_52, "\t");
                _builder.append("_axi_arready,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [C_S01_AXI_ID_WIDTH-1 : 0] s");
                Integer _get_49 = this.portMap.get(port_1);
                int _plus_50 = ((_get_49).intValue() + 1);
                String _longId_53 = this.getLongId(_plus_50);
                _builder.append(_longId_53, "\t");
                _builder.append("_axi_rid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [C_S01_AXI_DATA_WIDTH-1 : 0] s");
                Integer _get_50 = this.portMap.get(port_1);
                int _plus_51 = ((_get_50).intValue() + 1);
                String _longId_54 = this.getLongId(_plus_51);
                _builder.append(_longId_54, "\t");
                _builder.append("_axi_rdata,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [1 : 0] s");
                Integer _get_51 = this.portMap.get(port_1);
                int _plus_52 = ((_get_51).intValue() + 1);
                String _longId_55 = this.getLongId(_plus_52);
                _builder.append(_longId_55, "\t");
                _builder.append("_axi_rresp,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_52 = this.portMap.get(port_1);
                int _plus_53 = ((_get_52).intValue() + 1);
                String _longId_56 = this.getLongId(_plus_53);
                _builder.append(_longId_56, "\t");
                _builder.append("_axi_rlast,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire [C_S01_AXI_RUSER_WIDTH-1 : 0] s");
                Integer _get_53 = this.portMap.get(port_1);
                int _plus_54 = ((_get_53).intValue() + 1);
                String _longId_57 = this.getLongId(_plus_54);
                _builder.append(_longId_57, "\t");
                _builder.append("_axi_ruser,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("output wire  s");
                Integer _get_54 = this.portMap.get(port_1);
                int _plus_55 = ((_get_54).intValue() + 1);
                String _longId_58 = this.getLongId(_plus_55);
                _builder.append(_longId_58, "\t");
                _builder.append("_axi_rvalid,");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("input wire  s");
                Integer _get_55 = this.portMap.get(port_1);
                int _plus_56 = ((_get_55).intValue() + 1);
                String _longId_59 = this.getLongId(_plus_56);
                _builder.append(_longId_59, "\t");
                _builder.append("_axi_rready,");
                _builder.newLineIfNotEmpty();
              }
            }
          } else {
            _builder.append("\t");
            _builder.append("// Ports of Axi Slave Bus Interface S01_AXI");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_aclk,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_aresetn,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_ID_WIDTH-1 : 0] s01_axi_awid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_ADDR_WIDTH-1 : 0] s01_axi_awaddr,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [7 : 0] s01_axi_awlen,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [2 : 0] s01_axi_awsize,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [1 : 0] s01_axi_awburst,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_awlock,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_awcache,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [2 : 0] s01_axi_awprot,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_awqos,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_awregion,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_AWUSER_WIDTH-1 : 0] s01_axi_awuser,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_awvalid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_awready,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_DATA_WIDTH-1 : 0] s01_axi_wdata,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [(C_S01_AXI_DATA_WIDTH/8)-1 : 0] s01_axi_wstrb,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_wlast,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_WUSER_WIDTH-1 : 0] s01_axi_wuser,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_wvalid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_wready,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [C_S01_AXI_ID_WIDTH-1 : 0] s01_axi_bid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [1 : 0] s01_axi_bresp,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [C_S01_AXI_BUSER_WIDTH-1 : 0] s01_axi_buser,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_bvalid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_bready,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_ID_WIDTH-1 : 0] s01_axi_arid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_ADDR_WIDTH-1 : 0] s01_axi_araddr,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [7 : 0] s01_axi_arlen,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [2 : 0] s01_axi_arsize,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [1 : 0] s01_axi_arburst,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_arlock,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_arcache,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [2 : 0] s01_axi_arprot,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_arqos,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [3 : 0] s01_axi_arregion,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire [C_S01_AXI_ARUSER_WIDTH-1 : 0] s01_axi_aruser,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_arvalid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_arready,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [C_S01_AXI_ID_WIDTH-1 : 0] s01_axi_rid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [C_S01_AXI_DATA_WIDTH-1 : 0] s01_axi_rdata,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [1 : 0] s01_axi_rresp,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_rlast,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire [C_S01_AXI_RUSER_WIDTH-1 : 0] s01_axi_ruser,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("output wire  s01_axi_rvalid,");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("input wire  s01_axi_rready,");
            _builder.newLine();
          }
        }
      } else {
        _builder.append("\t");
        {
          Set<Port> _keySet_4 = this.inputMap.keySet();
          for(final Port input_1 : _keySet_4) {
            _builder.append("// Ports of Axi Slave Bus Interface S");
            String _longId_60 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_60, "\t");
            _builder.append("_AXIS");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  s");
            String _longId_61 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_61, "\t");
            _builder.append("_axis_aclk,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  s");
            String _longId_62 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_62, "\t");
            _builder.append("_axis_aresetn,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("output wire  s");
            String _longId_63 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_63, "\t");
            _builder.append("_axis_tready,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire [C_S");
            String _longId_64 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_64, "\t");
            _builder.append("_AXIS_TDATA_WIDTH-1 : 0] s");
            String _longId_65 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_65, "\t");
            _builder.append("_axis_tdata,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire [(C_S");
            String _longId_66 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_66, "\t");
            _builder.append("_AXIS_TDATA_WIDTH/8)-1 : 0] s");
            String _longId_67 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_67, "\t");
            _builder.append("_axis_tkeep,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  s");
            String _longId_68 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_68, "\t");
            _builder.append("_axis_tlast,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  s");
            String _longId_69 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_69, "\t");
            _builder.append("_axis_tvalid,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire [31 : 0] s");
            String _longId_70 = this.getLongId((this.inputMap.get(input_1)).intValue());
            _builder.append(_longId_70, "\t");
            _builder.append("_axis_data_count,");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        {
          Set<Port> _keySet_5 = this.outputMap.keySet();
          for(final Port output_1 : _keySet_5) {
            _builder.append("// Ports of Axi Master Bus Interface M");
            String _longId_71 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_71, "\t");
            _builder.append("_AXIS");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  m");
            String _longId_72 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_72, "\t");
            _builder.append("_axis_aclk,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  m");
            String _longId_73 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_73, "\t");
            _builder.append("_axis_aresetn,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("output wire  m");
            String _longId_74 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_74, "\t");
            _builder.append("_axis_tvalid,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("output wire [C_M");
            String _longId_75 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_75, "\t");
            _builder.append("_AXIS_TDATA_WIDTH-1 : 0] m");
            String _longId_76 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_76, "\t");
            _builder.append("_axis_tdata,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("output wire [(C_M");
            String _longId_77 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_77, "\t");
            _builder.append("_AXIS_TDATA_WIDTH/8)-1 : 0] m");
            String _longId_78 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_78, "\t");
            _builder.append("_axis_tkeep,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("output wire  m");
            String _longId_79 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_79, "\t");
            _builder.append("_axis_tlast,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("input wire  m");
            String _longId_80 = this.getLongId((this.outputMap.get(output_1)).intValue());
            _builder.append(_longId_80, "\t");
            _builder.append("_axis_tready,");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Monitoring");
    _builder.newLine();
    {
      EList<Connection> _connections = network.getConnections();
      for(final Connection connection : _connections) {
        {
          boolean _hasAttribute = connection.hasAttribute("monitor_in");
          if (_hasAttribute) {
            {
              Set<String> _keySet_6 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId : _keySet_6) {
                {
                  boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId);
                  if (_isInputSide) {
                    {
                      Vertex _target = connection.getTarget();
                      if ((_target instanceof Port)) {
                        _builder.append("\t");
                        _builder.append("output ");
                        String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId, connection.getTarget().<Port>getAdapter(Port.class));
                        _builder.append(_commSigPrintRange, "\t");
                        String _targetSignal = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId);
                        _builder.append(_targetSignal, "\t");
                        _builder.append(", // ");
                        _builder.append(connection, "\t");
                        _builder.newLineIfNotEmpty();
                      } else {
                        _builder.append("\t");
                        _builder.append("output ");
                        String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), connection.getTarget().<Actor>getAdapter(Actor.class), commSigId, connection.getTargetPort());
                        _builder.append(_commSigPrintRange_1, "\t");
                        String _targetSignal_1 = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId);
                        _builder.append(_targetSignal_1, "\t");
                        _builder.append(", // ");
                        _builder.append(connection, "\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Ports of Axi Slave Bus Interface S00_AXI");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_aclk,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_aresetn,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_awaddr,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [2 : 0] s00_axi_awprot,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_awvalid,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire  s00_axi_awready,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_wdata,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [(C_S00_AXI_DATA_WIDTH/8)-1 : 0] s00_axi_wstrb,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_wvalid,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire  s00_axi_wready,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire [1 : 0] s00_axi_bresp,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire  s00_axi_bvalid,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_bready,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_araddr,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire [2 : 0] s00_axi_arprot,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_arvalid,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire  s00_axi_arready,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_rdata,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire [1 : 0] s00_axi_rresp,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output wire  s00_axi_rvalid,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input wire  s00_axi_rready");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printTopSignals() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Parameters");
    _builder.newLine();
    {
      boolean _equals = this.coupling.equals("mm");
      if (_equals) {
        {
          Set<Port> _keySet = this.portMap.keySet();
          for(final Port port : _keySet) {
            _builder.append("// local memory ");
            Integer _get = this.portMap.get(port);
            int _plus = ((_get).intValue() + 1);
            _builder.append(_plus);
            _builder.append(" (");
            String _name = port.getName();
            _builder.append(_name);
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append("localparam SIZE_MEM_");
            Integer _get_1 = this.portMap.get(port);
            int _plus_1 = ((_get_1).intValue() + 1);
            _builder.append(_plus_1);
            _builder.append(" = 256;");
            _builder.newLineIfNotEmpty();
            _builder.append("localparam [15:0] BASE_ADDR_MEM_");
            Integer _get_2 = this.portMap.get(port);
            int _plus_2 = ((_get_2).intValue() + 1);
            _builder.append(_plus_2);
            _builder.append(" = ");
            {
              Integer _get_3 = this.portMap.get(port);
              boolean _equals_1 = ((_get_3).intValue() == 0);
              boolean _not = (!_equals_1);
              if (_not) {
                _builder.append("SIZE_MEM_");
                Integer _get_4 = this.portMap.get(port);
                _builder.append(_get_4);
                _builder.append(" + BASE_ADDR_MEM_");
                Integer _get_5 = this.portMap.get(port);
                _builder.append(_get_5);
              } else {
                _builder.append("0");
              }
            }
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("parameter SIZE_ADDR_");
            Integer _get_6 = this.portMap.get(port);
            int _plus_3 = ((_get_6).intValue() + 1);
            _builder.append(_plus_3);
            _builder.append(" = $clog2(SIZE_MEM_");
            Integer _get_7 = this.portMap.get(port);
            int _plus_4 = ((_get_7).intValue() + 1);
            _builder.append(_plus_4);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
      } else {
        {
          Set<Port> _keySet_1 = this.outputMap.keySet();
          for(final Port output : _keySet_1) {
            _builder.append("// output counter ");
            Integer _get_8 = this.portMap.get(output);
            int _plus_5 = ((_get_8).intValue() + 1);
            _builder.append(_plus_5);
            _builder.append(" (");
            String _name_1 = output.getName();
            _builder.append(_name_1);
            _builder.append(") for tlast");
            _builder.newLineIfNotEmpty();
            _builder.append("parameter SIZE_COUNT_");
            Integer _get_9 = this.portMap.get(output);
            int _plus_6 = ((_get_9).intValue() + 1);
            _builder.append(_plus_6);
            _builder.append(" = ");
            _builder.append(this.outputCounterBits);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("// Wire(s) and Reg(s)");
    _builder.newLine();
    _builder.append("wire [31 : 0] slv_reg0;");
    _builder.newLine();
    {
      boolean _equals_2 = this.coupling.equals("mm");
      if (_equals_2) {
        _builder.append("wire start;");
        _builder.newLine();
        {
          Set<Port> _keySet_2 = this.portMap.keySet();
          for(final Port port_1 : _keySet_2) {
            _builder.append("wire [31 : 0] slv_reg");
            Integer _get_10 = this.portMap.get(port_1);
            int _plus_7 = ((_get_10).intValue() + 1);
            _builder.append(_plus_7);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          if (this.enableMonitoring) {
            _builder.append("// Monitors registers");
            _builder.newLine();
            {
              for(final String monitor : this.monList) {
                _builder.append("wire [31 : 0] slv_reg");
                int _size = this.portMap.keySet().size();
                int _plus_8 = (_size + 1);
                int _indexOf = this.monList.indexOf(monitor);
                int _plus_9 = (_plus_8 + _indexOf);
                _builder.append(_plus_9);
                _builder.append("; // ");
                _builder.append(monitor);
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        {
          if (this.dedicatedInterfaces) {
          } else {
            _builder.append("wire s01_axi_rden;");
            _builder.newLine();
            _builder.append("wire s01_axi_wren;");
            _builder.newLine();
            _builder.append("wire [C_S01_AXI_ADDR_WIDTH-3 : 0] s01_axi_address;");
            _builder.newLine();
            _builder.append("wire [31 : 0] s01_axi_data_in;");
            _builder.newLine();
            _builder.append("reg [31 : 0] s01_axi_data_out;");
            _builder.newLine();
          }
        }
        _builder.append("wire done;");
        _builder.newLine();
        _builder.append("wire done_input;");
        _builder.newLine();
      }
    }
    {
      Set<Port> _keySet_3 = this.inputMap.keySet();
      for(final Port input : _keySet_3) {
        {
          Set<String> _keySet_4 = this.protocolManager.getInFirstModCommSignals().keySet();
          for(final String commSigId : _keySet_4) {
            _builder.append("wire ");
            String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId, input);
            _builder.append(_commSigPrintRange);
            String _name_2 = input.getName();
            _builder.append(_name_2);
            _builder.append("_");
            String _matchingWrapMapping = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      boolean _equals_3 = this.coupling.equals("mm");
      if (_equals_3) {
        {
          Set<Port> _keySet_5 = this.inputMap.keySet();
          for(final Port input_1 : _keySet_5) {
            _builder.append("wire en_");
            String _name_3 = input_1.getName();
            _builder.append(_name_3);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire done_");
            String _name_4 = input_1.getName();
            _builder.append(_name_4);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire last_");
            String _name_5 = input_1.getName();
            _builder.append(_name_5);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [SIZE_ADDR_");
            Integer _get_11 = this.portMap.get(input_1);
            int _plus_10 = ((_get_11).intValue() + 1);
            _builder.append(_plus_10);
            _builder.append("-1:0] count_");
            String _name_6 = input_1.getName();
            _builder.append(_name_6);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire wren_mem_");
            Integer _get_12 = this.portMap.get(input_1);
            int _plus_11 = ((_get_12).intValue() + 1);
            _builder.append(_plus_11);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire rden_mem_");
            Integer _get_13 = this.portMap.get(input_1);
            int _plus_12 = ((_get_13).intValue() + 1);
            _builder.append(_plus_12);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [SIZE_ADDR_");
            Integer _get_14 = this.portMap.get(input_1);
            int _plus_13 = ((_get_14).intValue() + 1);
            _builder.append(_plus_13);
            _builder.append("-1:0] address_mem_");
            Integer _get_15 = this.portMap.get(input_1);
            int _plus_14 = ((_get_15).intValue() + 1);
            _builder.append(_plus_14);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize = this.protocolManager.getDataSize(input_1);
            _builder.append(_dataSize);
            _builder.append("-1:0] data_in_mem_");
            Integer _get_16 = this.portMap.get(input_1);
            int _plus_15 = ((_get_16).intValue() + 1);
            _builder.append(_plus_15);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize_1 = this.protocolManager.getDataSize(input_1);
            _builder.append(_dataSize_1);
            _builder.append("-1:0] data_out_mem_");
            Integer _get_17 = this.portMap.get(input_1);
            int _plus_16 = ((_get_17).intValue() + 1);
            _builder.append(_plus_16);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize_2 = this.protocolManager.getDataSize(input_1);
            _builder.append(_dataSize_2);
            _builder.append("-1:0] data_out_");
            Integer _get_18 = this.portMap.get(input_1);
            int _plus_17 = ((_get_18).intValue() + 1);
            _builder.append(_plus_17);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire ce_");
            Integer _get_19 = this.portMap.get(input_1);
            int _plus_18 = ((_get_19).intValue() + 1);
            _builder.append(_plus_18);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      Set<Port> _keySet_6 = this.outputMap.keySet();
      for(final Port output_1 : _keySet_6) {
        {
          Set<String> _keySet_7 = this.protocolManager.getOutLastModCommSignals().keySet();
          for(final String commSigId_1 : _keySet_7) {
            _builder.append("wire ");
            String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getLastMod(), null, commSigId_1, output_1);
            _builder.append(_commSigPrintRange_1);
            String _name_7 = output_1.getName();
            _builder.append(_name_7);
            _builder.append("_");
            String _matchingWrapMapping_1 = this.protocolManager.getMatchingWrapMapping(this.protocolManager.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping_1);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      boolean _equals_4 = this.coupling.equals("mm");
      if (_equals_4) {
        _builder.append("wire done_output;");
        _builder.newLine();
        {
          Set<Port> _keySet_8 = this.outputMap.keySet();
          for(final Port output_2 : _keySet_8) {
            _builder.append("wire en_");
            String _name_8 = output_2.getName();
            _builder.append(_name_8);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire done_");
            String _name_9 = output_2.getName();
            _builder.append(_name_9);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire last_");
            String _name_10 = output_2.getName();
            _builder.append(_name_10);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [SIZE_ADDR_");
            Integer _get_20 = this.portMap.get(output_2);
            int _plus_19 = ((_get_20).intValue() + 1);
            _builder.append(_plus_19);
            _builder.append("-1:0] count_");
            String _name_11 = output_2.getName();
            _builder.append(_name_11);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire rden_mem_");
            Integer _get_21 = this.portMap.get(output_2);
            int _plus_20 = ((_get_21).intValue() + 1);
            _builder.append(_plus_20);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire wren_mem_");
            Integer _get_22 = this.portMap.get(output_2);
            int _plus_21 = ((_get_22).intValue() + 1);
            _builder.append(_plus_21);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [SIZE_ADDR_");
            Integer _get_23 = this.portMap.get(output_2);
            int _plus_22 = ((_get_23).intValue() + 1);
            _builder.append(_plus_22);
            _builder.append("-1:0] address_mem_");
            Integer _get_24 = this.portMap.get(output_2);
            int _plus_23 = ((_get_24).intValue() + 1);
            _builder.append(_plus_23);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize_3 = this.protocolManager.getDataSize(output_2);
            _builder.append(_dataSize_3);
            _builder.append("-1:0] data_in_mem_");
            Integer _get_25 = this.portMap.get(output_2);
            int _plus_24 = ((_get_25).intValue() + 1);
            _builder.append(_plus_24);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize_4 = this.protocolManager.getDataSize(output_2);
            _builder.append(_dataSize_4);
            _builder.append("-1:0] data_out_mem_");
            Integer _get_26 = this.portMap.get(output_2);
            int _plus_25 = ((_get_26).intValue() + 1);
            _builder.append(_plus_25);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire [");
            int _dataSize_5 = this.protocolManager.getDataSize(output_2);
            _builder.append(_dataSize_5);
            _builder.append("-1:0] data_out_");
            Integer _get_27 = this.portMap.get(output_2);
            int _plus_26 = ((_get_27).intValue() + 1);
            _builder.append(_plus_26);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire ce_");
            Integer _get_28 = this.portMap.get(output_2);
            int _plus_27 = ((_get_28).intValue() + 1);
            _builder.append(_plus_27);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      } else {
        {
          Set<Port> _keySet_9 = this.outputMap.keySet();
          for(final Port output_3 : _keySet_9) {
            _builder.append("wire [31 : 0] slv_reg");
            Integer _get_29 = this.outputMap.get(output_3);
            int _plus_28 = ((_get_29).intValue() + 1);
            _builder.append(_plus_28);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    return _builder;
  }
  
  public CharSequence printXML() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    _builder.newLine();
    _builder.append("<mdcInfo>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<baseAddress>0x43C00000</baseAddress>");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("<nbEvents>");
    int _size = this.monList.size();
    _builder.append(_size, "  ");
    _builder.append("</nbEvents>");
    _builder.newLineIfNotEmpty();
    {
      for(final String monitor : this.monList) {
        _builder.append("  ");
        _builder.append("<event> ");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append("<index>");
        int _size_1 = this.portMap.size();
        int _plus = (_size_1 + 1);
        int _indexOf = this.monList.indexOf(monitor);
        int _plus_1 = (_plus + _indexOf);
        _builder.append(_plus_1, "    ");
        _builder.append("</index>");
        _builder.newLineIfNotEmpty();
        {
          boolean _contains = monitor.contains("count_full_");
          if (_contains) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase = monitor.replace("count_", "").toUpperCase();
            _builder.append(_upperCase, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Total number of FIFO full of input ");
            String _replace = monitor.replace("count_full_", "");
            _builder.append(_replace, "    ");
            _builder.append(" during the execution of the accelerator</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          boolean _contains_1 = monitor.contains("count_clock_cycles");
          if (_contains_1) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_1 = monitor.replace("count_", "").toUpperCase();
            _builder.append(_upperCase_1, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of clock cycles from start to done signals.</desc>");
            _builder.newLine();
          }
        }
        {
          boolean _contains_2 = monitor.contains("count_in_tokens_");
          if (_contains_2) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_2 = monitor.replace("count_in_", "").toUpperCase();
            _builder.append(_upperCase_2, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of input tokens to the accelerator at port ");
            String _replace_1 = monitor.replace("count_in_tokens_", "");
            _builder.append(_replace_1, "    ");
            _builder.append("</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          boolean _contains_3 = monitor.contains("count_out_tokens_");
          if (_contains_3) {
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<name>MDC_");
            String _upperCase_3 = monitor.replace("count_out_", "").toUpperCase();
            _builder.append(_upperCase_3, "    ");
            _builder.append("</name>");
            _builder.newLineIfNotEmpty();
            _builder.append("  ");
            _builder.append("  ");
            _builder.append("<desc>Number of output tokens from the accelerator at port ");
            String _replace_2 = monitor.replace("count_out_tokens_", "");
            _builder.append(_replace_2, "    ");
            _builder.append("</desc>");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("  ");
        _builder.append("</event>");
        _builder.newLine();
      }
    }
    _builder.append("</mdcInfo>");
    _builder.newLine();
    return _builder;
  }
}
