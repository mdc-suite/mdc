package it.mdc.tool.core;

import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A CAL Network Configurator printer.
 * 
 * printConfig() prints the CAL file:
 * <ul>
 * <li> print header comments: headerComments();
 * <li> print interface: printInterface();
 * <li> print body: printBody().
 * </ul>
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class ConfigPrinterCal {
  private List<SboxLut> luts;
  
  private Map<Integer, String> configMap;
  
  /**
   * Print the header of the file
   */
  public CharSequence headerComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - XDF Generation");
      _builder.newLine();
      _builder.append("// Network Configurator");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Print the body of the file
   */
  public CharSequence printBody(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _equals = type.equals("STATIC");
      if (_equals) {
        _builder.append("bool SEL[");
        int _size = this.luts.size();
        _builder.append(_size);
        _builder.append("] = SEL1;");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        {
          Set<Integer> _keySet = this.configMap.keySet();
          for(final Integer id : _keySet) {
            _builder.append("// ID = ");
            _builder.append(id);
            _builder.append(" ");
            String _get = this.configMap.get(id);
            _builder.append(_get);
            _builder.newLineIfNotEmpty();
            _builder.append("bool SEL");
            _builder.append(id);
            _builder.append("[");
            int _size_1 = this.luts.size();
            _builder.append(_size_1);
            _builder.append("] = [");
            _builder.newLineIfNotEmpty();
            {
              boolean _hasElements = false;
              for(final SboxLut lut : this.luts) {
                if (!_hasElements) {
                  _hasElements = true;
                } else {
                  _builder.appendImmediate(",", "");
                }
                _builder.append("\t");
                boolean _lutValue = lut.getLutValue(this.configMap.get(id));
                _builder.append(_lutValue);
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("];");
            _builder.newLineIfNotEmpty();
            _builder.newLine();
          }
        }
      } else {
        {
          Set<Integer> _keySet_1 = this.configMap.keySet();
          for(final Integer id_1 : _keySet_1) {
            _builder.append("// ID = ");
            _builder.append(id_1);
            _builder.newLineIfNotEmpty();
            _builder.append("execute_");
            String _get_1 = this.configMap.get(id_1);
            _builder.append(_get_1);
            _builder.append(": action ");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("ID : [id] ");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.append("==>");
            _builder.newLine();
            {
              boolean _hasElements_1 = false;
              for(final SboxLut lut_1 : this.luts) {
                if (!_hasElements_1) {
                  _hasElements_1 = true;
                } else {
                  _builder.appendImmediate(",", "");
                }
                _builder.append("sel");
                Integer _count = lut_1.getCount();
                _builder.append(_count);
                _builder.append(":[");
                boolean _lutValue_1 = lut_1.getLutValue(this.configMap.get(id_1));
                _builder.append(_lutValue_1);
                _builder.append("]");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("guard id = ");
            _builder.append(id_1);
            _builder.newLineIfNotEmpty();
            _builder.append("end");
            _builder.newLine();
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the interface of the file
   */
  public CharSequence printInterface(final String type) {
    CharSequence _xblockexpression = null;
    {
      int _size = this.luts.size();
      int _minus = (_size - 1);
      SboxLut lastLut = this.luts.get(_minus);
      StringConcatenation _builder = new StringConcatenation();
      {
        boolean _equals = type.equals("STATIC");
        if (_equals) {
          _builder.append("unit Configurator:");
          _builder.newLine();
        } else {
          _builder.append("actor Configurator()");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("int(size=8) ID ");
          _builder.newLine();
          _builder.append("\t\t");
          _builder.append("==> ");
          _builder.newLine();
          {
            for(final SboxLut lut : this.luts) {
              _builder.append("\t");
              _builder.append("bool sel");
              Integer _count = lut.getCount();
              _builder.append(_count, "\t");
              {
                boolean _equals_1 = lut.equals(lastLut);
                boolean _not = (!_equals_1);
                if (_not) {
                  _builder.append(",");
                }
              }
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append(":");
          _builder.newLineIfNotEmpty();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * <ul>
   * <li> print header comments: headerComments();
   * <li> print interface: printInterface();
   * <li> print the body of the CAL sbox: printBody().
   * </ul>
   */
  public CharSequence printConfig(final String type, final String packageName, final List<SboxLut> luts, final Map<Integer, String> configMap) {
    CharSequence _xblockexpression = null;
    {
      this.luts = luts;
      this.configMap = configMap;
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _headerComments = this.headerComments();
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.append("package ");
      _builder.append(packageName);
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printInterface = this.printInterface(type);
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printBody = this.printBody(type);
      _builder.append(_printBody);
      _builder.newLineIfNotEmpty();
      _builder.append("end");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
}
