package it.mdc.tool.powerSaving;

import it.mdc.tool.core.ConfigManager;
import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A Controller enables for Power saving logic
 * 
 * @author Tiziana Fanni
 */
@SuppressWarnings("all")
public class PowerController {
  /**
   * Config Manager description
   */
  private ConfigManager configManager;
  
  /**
   * Look Up Table
   */
  private List<SboxLut> luts;
  
  /**
   * List of input networks
   */
  private List<Network> networks;
  
  /**
   * Map of instances for each LR
   */
  private Map<String, Set<String>> logicRegions;
  
  /**
   * Map of LRs for each network
   */
  private Map<String, Set<String>> netRegions;
  
  /**
   * Map with one ID for each LR
   */
  private Map<String, Integer> logicRegionID;
  
  /**
   * Set of switchable LRs
   */
  private Set<String> powerSets;
  
  /**
   * For each Logic Regions in this map, the key value is true if the LR is sequential, and false if LR is purely combinatorial
   */
  private Map<String, Boolean> logicRegionsSeqMap;
  
  public CharSequence headerComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Power Saving");
      _builder.newLine();
      _builder.append("// Power Controller generator");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public boolean computeNets() {
    return this.networks.addAll(this.luts.get(0).getNetworks());
  }
  
  public CharSequence printInterface() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module PowerController(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("ID,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("reference_count,");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      for(final String lr : this.powerSets) {
        _builder.append("\t");
        _builder.append("sw_ack");
        Integer _get = this.logicRegionID.get(lr);
        _builder.append(_get, "\t");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("status");
        Integer _get_1 = this.logicRegionID.get(lr);
        _builder.append(_get_1, "\t");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("iso_en");
        Integer _get_2 = this.logicRegionID.get(lr);
        _builder.append(_get_2, "\t");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
        {
          Boolean _get_3 = this.logicRegionsSeqMap.get(lr);
          if ((_get_3).booleanValue()) {
            _builder.append("\t");
            _builder.append("rtn_en");
            Integer _get_4 = this.logicRegionID.get(lr);
            _builder.append(_get_4, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("en_cg");
            Integer _get_5 = this.logicRegionID.get(lr);
            _builder.append(_get_5, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("pw_switch_en");
        Integer _get_6 = this.logicRegionID.get(lr);
        _builder.append(_get_6, "\t");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("rst,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("clk");
    _builder.newLine();
    _builder.append(");\t\t");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printSignals() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Input");
    _builder.newLine();
    _builder.append("input clk, rst;");
    _builder.newLine();
    _builder.append("input [7 : 0] ID;");
    _builder.newLine();
    _builder.append("input [17:0] reference_count;");
    _builder.newLine();
    _builder.newLine();
    {
      for(final String lr : this.powerSets) {
        _builder.append("input\tsw_ack");
        Integer _get = this.logicRegionID.get(lr);
        _builder.append(_get);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("// Output(s)");
    _builder.newLine();
    {
      for(final String lr_1 : this.powerSets) {
        _builder.append("output  status");
        Integer _get_1 = this.logicRegionID.get(lr_1);
        _builder.append(_get_1);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("output\tiso_en");
        Integer _get_2 = this.logicRegionID.get(lr_1);
        _builder.append(_get_2);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        {
          Boolean _get_3 = this.logicRegionsSeqMap.get(lr_1);
          if ((_get_3).booleanValue()) {
            _builder.append("output\trtn_en");
            Integer _get_4 = this.logicRegionID.get(lr_1);
            _builder.append(_get_4);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("output\ten_cg");
            Integer _get_5 = this.logicRegionID.get(lr_1);
            _builder.append(_get_5);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("output\tpw_switch_en");
        Integer _get_6 = this.logicRegionID.get(lr_1);
        _builder.append(_get_6);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  public CharSequence printBody() {
    StringConcatenation _builder = new StringConcatenation();
    {
      for(final String lr : this.powerSets) {
        _builder.append("reg en_fsm_");
        Integer _get = this.logicRegionID.get(lr);
        _builder.append(_get);
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("always@(posedge clk or posedge rst)");
    _builder.newLine();
    _builder.append("if(rst) begin");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("//FSMs enabled");
    _builder.newLine();
    {
      for(final String lr_1 : this.powerSets) {
        _builder.append("\t");
        _builder.append("en_fsm_");
        Integer _get_1 = this.logicRegionID.get(lr_1);
        _builder.append(_get_1, "\t");
        _builder.append(" = 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("end");
    _builder.newLine();
    _builder.append("else");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("case(ID)");
    _builder.newLine();
    {
      for(final Network network : this.networks) {
        _builder.append("\t");
        _builder.append("8\'d");
        int _networkId = this.configManager.getNetworkId(network.getSimpleName());
        _builder.append(_networkId, "\t");
        _builder.append(":\tbegin ");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("// ");
        String _simpleName = network.getSimpleName();
        _builder.append(_simpleName, "\t\t");
        _builder.newLineIfNotEmpty();
        {
          for(final String lr_2 : this.powerSets) {
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("en_fsm_");
            Integer _get_2 = this.logicRegionID.get(lr_2);
            _builder.append(_get_2, "\t\t");
            _builder.append(" = ");
            {
              boolean _contains = this.netRegions.get(network.getSimpleName()).contains(lr_2);
              if (_contains) {
                _builder.append("1\'b1");
              } else {
                _builder.append("1\'b0");
              }
            }
            _builder.append(";\t\t\t\t\t\t\t\t\t\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("end");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("default:\t");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("begin");
    _builder.newLine();
    {
      for(final String lr_3 : this.powerSets) {
        _builder.append("\t\t");
        _builder.append("en_fsm_");
        Integer _get_3 = this.logicRegionID.get(lr_3);
        _builder.append(_get_3, "\t\t");
        _builder.append(" = 1;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.append("end");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("endcase");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("//An FSM for each Power Domain is instantiated");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      for(final String lr_4 : this.powerSets) {
        {
          Boolean _get_4 = this.logicRegionsSeqMap.get(lr_4);
          if ((_get_4).booleanValue()) {
            _builder.append("\t");
            _builder.append("FSM_cg fsm_");
            Integer _get_5 = this.logicRegionID.get(lr_4);
            _builder.append(_get_5, "\t");
            _builder.append(" (\t\t\t");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Input Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en(en_fsm_");
            Integer _get_6 = this.logicRegionID.get(lr_4);
            _builder.append(_get_6, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".reference_count(reference_count),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".sw_ack(sw_ack");
            Integer _get_7 = this.logicRegionID.get(lr_4);
            _builder.append(_get_7, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Output Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".status(status");
            Integer _get_8 = this.logicRegionID.get(lr_4);
            _builder.append(_get_8, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en_iso(iso_en");
            Integer _get_9 = this.logicRegionID.get(lr_4);
            _builder.append(_get_9, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".rtn(rtn_en");
            Integer _get_10 = this.logicRegionID.get(lr_4);
            _builder.append(_get_10, "\t");
            _builder.append("),\t\t");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en_cg(en_cg");
            Integer _get_11 = this.logicRegionID.get(lr_4);
            _builder.append(_get_11, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en_pw_sw(pw_switch_en");
            Integer _get_12 = this.logicRegionID.get(lr_4);
            _builder.append(_get_12, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// External Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".rst(rst),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Clock Signal");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".ck(clk)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(");");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          } else {
            _builder.append("\t");
            _builder.append("FSM fsm_");
            Integer _get_13 = this.logicRegionID.get(lr_4);
            _builder.append(_get_13, "\t");
            _builder.append(" (\t\t\t");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Input Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en(en_fsm_");
            Integer _get_14 = this.logicRegionID.get(lr_4);
            _builder.append(_get_14, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Output Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".en_iso(iso_en");
            Integer _get_15 = this.logicRegionID.get(lr_4);
            _builder.append(_get_15, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en_pw_sw(pw_switch_en");
            Integer _get_16 = this.logicRegionID.get(lr_4);
            _builder.append(_get_16, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// External Signal(s)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".rst(rst),");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Clock Signal");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".ck(clk)");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(");");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  public CharSequence printPowerController(final Network network, final List<SboxLut> luts, final Map<String, Set<String>> logicRegions, final Map<String, Set<String>> netRegions, final Map<String, Integer> logicRegionID, final ConfigManager configManager, final Set<String> powerSets, final Map<String, Boolean> logicRegionsSeqMap) {
    CharSequence _xblockexpression = null;
    {
      this.logicRegions = logicRegions;
      this.netRegions = netRegions;
      this.logicRegionID = logicRegionID;
      this.luts = luts;
      this.configManager = configManager;
      this.powerSets = powerSets;
      this.logicRegionsSeqMap = logicRegionsSeqMap;
      ArrayList<Network> _arrayList = new ArrayList<Network>();
      this.networks = _arrayList;
      this.computeNets();
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _headerComments = this.headerComments();
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      CharSequence _printInterface = this.printInterface();
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      CharSequence _printSignals = this.printSignals();
      _builder.append(_printSignals);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      CharSequence _printBody = this.printBody();
      _builder.append(_printBody);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
}
