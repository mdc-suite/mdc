package it.mdc.tool.core.platformComposer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A Verilog Network Configurator printer
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class SBoxPrinterGeneric {
  private String pred;
  
  private String succ;
  
  /**
   * Protocol signals flags
   */
  private static final String ACTOR = "actor";
  
  private static final String PRED = "predecessor";
  
  private static final String SUCC = "successor";
  
  private static final String CH = "channel";
  
  private static final String KIND = "kind";
  
  private static final String DIR = "dir";
  
  private static final String SIZE = "size";
  
  private Map<String, Map<String, Map<String, String>>> modCommSignals;
  
  public CharSequence headerComments(final String type) {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Sbox ");
      _builder.append(type);
      _builder.append(" module ");
      _builder.newLineIfNotEmpty();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public String getSourceSig(final String module, final String commSigId) {
    Set<String> _keySet = this.modCommSignals.get(this.succ).keySet();
    for (final String srcCommSigId : _keySet) {
      boolean _equals = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.CH).equals(this.modCommSignals.get(this.succ).get(srcCommSigId).get(SBoxPrinterGeneric.CH));
      if (_equals) {
        return this.modCommSignals.get(this.succ).get(srcCommSigId).get(SBoxPrinterGeneric.CH);
      }
    }
    return null;
  }
  
  public CharSequence printBody(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Set<String> _keySet = this.modCommSignals.get(this.pred).keySet();
      for(final String commSigId : _keySet) {
        {
          if ((this.isInputSide(this.pred, commSigId) && this.modCommSignals.get(this.pred).get(commSigId).get(SBoxPrinterGeneric.DIR).equals("direct"))) {
            _builder.append("assign out1");
            String _channelSuffix = this.getChannelSuffix(this.pred, commSigId);
            _builder.append(_channelSuffix);
            _builder.append(" = sel ? ");
            {
              boolean _equals = type.equals("1x2");
              if (_equals) {
                _builder.append("{");
                String _commSigSize = this.getCommSigSize(this.pred, commSigId);
                _builder.append(_commSigSize);
                _builder.append("{1\'b0}}");
              } else {
                _builder.append("in2");
                String _channelSuffix_1 = this.getChannelSuffix(this.succ, commSigId);
                _builder.append(_channelSuffix_1);
              }
            }
            _builder.append(" : in1");
            String _channelSuffix_2 = this.getChannelSuffix(this.succ, commSigId);
            _builder.append(_channelSuffix_2);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            {
              boolean _equals_1 = type.equals("1x2");
              if (_equals_1) {
                _builder.append("assign out2");
                String _channelSuffix_3 = this.getChannelSuffix(this.pred, commSigId);
                _builder.append(_channelSuffix_3);
                _builder.append(" = sel ? in1");
                String _channelSuffix_4 = this.getChannelSuffix(this.succ, commSigId);
                _builder.append(_channelSuffix_4);
                _builder.append(" : {");
                String _commSigSize_1 = this.getCommSigSize(this.pred, commSigId);
                _builder.append(_commSigSize_1);
                _builder.append("{1\'b0}};");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    {
      Set<String> _keySet_1 = this.modCommSignals.get(this.succ).keySet();
      for(final String commSigId_1 : _keySet_1) {
        {
          if ((this.isOutputSide(this.succ, commSigId_1) && this.modCommSignals.get(this.succ).get(commSigId_1).get(SBoxPrinterGeneric.DIR).equals("reverse"))) {
            _builder.append("assign in1");
            String _channelSuffix_5 = this.getChannelSuffix(this.succ, commSigId_1);
            _builder.append(_channelSuffix_5);
            _builder.append(" = sel ? ");
            {
              boolean _equals_2 = type.equals("2x1");
              if (_equals_2) {
                _builder.append("{");
                String _commSigSize_2 = this.getCommSigSize(this.succ, commSigId_1);
                _builder.append(_commSigSize_2);
                _builder.append("{1\'b0}}");
              } else {
                _builder.append("out2");
                String _channelSuffix_6 = this.getChannelSuffix(this.pred, commSigId_1);
                _builder.append(_channelSuffix_6);
              }
            }
            _builder.append(" : out1");
            String _channelSuffix_7 = this.getChannelSuffix(this.pred, commSigId_1);
            _builder.append(_channelSuffix_7);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            {
              boolean _equals_3 = type.equals("2x1");
              if (_equals_3) {
                _builder.append("assign in2");
                String _channelSuffix_8 = this.getChannelSuffix(this.succ, commSigId_1);
                _builder.append(_channelSuffix_8);
                _builder.append(" = sel ? out1");
                String _channelSuffix_9 = this.getChannelSuffix(this.pred, commSigId_1);
                _builder.append(_channelSuffix_9);
                _builder.append(" : {");
                String _commSigSize_3 = this.getCommSigSize(this.pred, commSigId_1);
                _builder.append(_commSigSize_3);
                _builder.append("{1\'b0}};");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  public boolean isInputSide(final String module, final String commSigId) {
    if (((this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.KIND).equals("input") && this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.DIR).equals("direct")) || 
      (this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.KIND).equals("output") && this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.DIR).equals("reverse")))) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isOutputSide(final String module, final String commSigId) {
    if (((this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.KIND).equals("output") && this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.DIR).equals("direct")) || 
      (this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.KIND).equals("input") && this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.DIR).equals("reverse")))) {
      return true;
    } else {
      return false;
    }
  }
  
  public String reverseKind(final String module, final String commSigId) {
    boolean _equals = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.KIND).equals("input");
    if (_equals) {
      return "output";
    } else {
      return "input";
    }
  }
  
  public String getCommSigSize(final String module, final String commSigId) {
    boolean _equals = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.SIZE).equals("variable");
    if (_equals) {
      return "SIZE";
    } else {
      boolean _equals_1 = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.SIZE).equals("broadcast");
      if (_equals_1) {
        return "1";
      } else {
        return this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.SIZE);
      }
    }
  }
  
  public String getCommSigDimension(final String module, final String commSigId) {
    boolean _equals = this.getCommSigSize(module, commSigId).equals("1");
    boolean _not = (!_equals);
    if (_not) {
      String _commSigSize = this.getCommSigSize(module, commSigId);
      String _plus = ("[" + _commSigSize);
      return (_plus + "-1 : 0] ");
    } else {
      return "";
    }
  }
  
  public String getChannelSuffix(final String module, final String commSigId) {
    String _xifexpression = null;
    boolean _equals = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.CH).equals("");
    if (_equals) {
      _xifexpression = "";
    } else {
      String _get = this.modCommSignals.get(module).get(commSigId).get(SBoxPrinterGeneric.CH);
      _xifexpression = ("_" + _get);
    }
    return _xifexpression;
  }
  
  public CharSequence printInterface(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module sbox");
    _builder.append(type);
    _builder.append(" #(");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("parameter SIZE = 32");
    _builder.newLine();
    _builder.append(")(");
    _builder.newLine();
    {
      Set<String> _keySet = this.modCommSignals.get(this.pred).keySet();
      for(final String commSigId : _keySet) {
        {
          boolean _isInputSide = this.isInputSide(this.pred, commSigId);
          if (_isInputSide) {
            _builder.append("\t");
            String _reverseKind = this.reverseKind(this.pred, commSigId);
            _builder.append(_reverseKind, "\t");
            _builder.append(" ");
            String _commSigDimension = this.getCommSigDimension(this.pred, commSigId);
            _builder.append(_commSigDimension, "\t");
            _builder.append("out1");
            String _channelSuffix = this.getChannelSuffix(this.pred, commSigId);
            _builder.append(_channelSuffix, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            {
              boolean _equals = type.equals("1x2");
              if (_equals) {
                _builder.append("\t");
                String _reverseKind_1 = this.reverseKind(this.pred, commSigId);
                _builder.append(_reverseKind_1, "\t");
                _builder.append(" ");
                String _commSigDimension_1 = this.getCommSigDimension(this.pred, commSigId);
                _builder.append(_commSigDimension_1, "\t");
                _builder.append("out2");
                String _channelSuffix_1 = this.getChannelSuffix(this.pred, commSigId);
                _builder.append(_channelSuffix_1, "\t");
                _builder.append(",");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    {
      Set<String> _keySet_1 = this.modCommSignals.get(this.succ).keySet();
      for(final String commSigId_1 : _keySet_1) {
        {
          boolean _isOutputSide = this.isOutputSide(this.succ, commSigId_1);
          if (_isOutputSide) {
            _builder.append("\t");
            String _reverseKind_2 = this.reverseKind(this.succ, commSigId_1);
            _builder.append(_reverseKind_2, "\t");
            _builder.append(" ");
            String _commSigDimension_2 = this.getCommSigDimension(this.succ, commSigId_1);
            _builder.append(_commSigDimension_2, "\t");
            _builder.append("in1");
            String _channelSuffix_2 = this.getChannelSuffix(this.succ, commSigId_1);
            _builder.append(_channelSuffix_2, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            {
              boolean _equals_1 = type.equals("2x1");
              if (_equals_1) {
                _builder.append("\t");
                String _reverseKind_3 = this.reverseKind(this.succ, commSigId_1);
                _builder.append(_reverseKind_3, "\t");
                _builder.append(" ");
                String _commSigDimension_3 = this.getCommSigDimension(this.succ, commSigId_1);
                _builder.append(_commSigDimension_3, "\t");
                _builder.append("in2");
                String _channelSuffix_3 = this.getChannelSuffix(this.succ, commSigId_1);
                _builder.append(_channelSuffix_3, "\t");
                _builder.append(",");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("input sel");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printSbox(final String type, final Map<String, Map<String, Map<String, String>>> modCommSignals) {
    CharSequence _xblockexpression = null;
    {
      this.modCommSignals = modCommSignals;
      boolean _containsKey = this.modCommSignals.containsKey(SBoxPrinterGeneric.PRED);
      if (_containsKey) {
        this.pred = SBoxPrinterGeneric.PRED;
      } else {
        this.pred = SBoxPrinterGeneric.ACTOR;
      }
      boolean _containsKey_1 = this.modCommSignals.containsKey(SBoxPrinterGeneric.SUCC);
      if (_containsKey_1) {
        this.succ = SBoxPrinterGeneric.SUCC;
      } else {
        this.succ = SBoxPrinterGeneric.ACTOR;
      }
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _headerComments = this.headerComments(type);
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printInterface = this.printInterface(type);
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printBody = this.printBody(type);
      _builder.append(_printBody);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
}
