package it.mdc.tool.core;

import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import net.sf.orcc.df.Network;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A CAL Switching Boxes (SBoxes) printer.
 * 
 * printSboxes() prints the CAL file:
 * 
 * <ul>
 * <li> print header comments: headerComments();
 * <li> print interface: printInterface();
 * <li> print body: printBody().
 * </ul>
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class SBoxPrinterCal {
  private List<SboxLut> luts;
  
  private Map<Integer, Network> configMap;
  
  private String typeData;
  
  private String typeSize;
  
  private String typeSB;
  
  /**
   * Print the header of the file
   */
  public CharSequence headerComments(final String ports) {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - XDF Generation");
      _builder.newLine();
      {
        boolean _equals = ports.equals("1x2");
        if (_equals) {
          _builder.append("// 1-input 2-outputs Switching Box (1x2 SBox) - ");
          _builder.append(this.typeData);
          _builder.append(this.typeSize);
          _builder.newLineIfNotEmpty();
        } else {
          _builder.append("// 2-inpus 1-output Switching Box (2x1 SBox) - ");
          _builder.append(this.typeData);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Print the body of the file
   */
  public CharSequence printBody(final String ports) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _equals = this.typeSB.equals("DUMMY");
      boolean _not = (!_equals);
      if (_not) {
        {
          boolean _equals_1 = this.typeSB.equals("DYNAMIC");
          if (_equals_1) {
            _builder.append("bool selector := false;");
            _builder.newLine();
            _builder.append("configure: action sel:[s] ==>");
            _builder.newLine();
            _builder.append("do");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("selector := s;");
            _builder.newLine();
            _builder.append("end");
            _builder.newLine();
            _builder.newLine();
            _builder.append("forward0: action in1: [a] ==> out1: [a]");
            _builder.newLine();
            _builder.append("guard not selector");
            _builder.newLine();
            _builder.append("end");
            _builder.newLine();
            _builder.newLine();
            {
              boolean _equals_2 = ports.equals("1x2");
              if (_equals_2) {
                _builder.append("forward1: action in1: [a] ==> out2: [a]");
                _builder.newLine();
                _builder.append("guard selector");
                _builder.newLine();
                _builder.append("end");
                _builder.newLine();
              } else {
                _builder.append("forward1: action in2: [a] ==> out1: [a]");
                _builder.newLine();
                _builder.append("guard selector");
                _builder.newLine();
                _builder.append("end");
                _builder.newLine();
              }
            }
            _builder.newLine();
            _builder.append("schedule fsm init:");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("init (configure) --> wait;");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("wait (forward0) --> wait;");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("wait (forward1) --> wait;");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("wait (configure) --> wait;");
            _builder.newLine();
            _builder.append("end");
            _builder.newLine();
            _builder.append("\t\t");
            _builder.newLine();
          } else {
            _builder.append("forward0: action in1: [a] ==> out1: [a]");
            _builder.newLine();
            _builder.append("guard not SEL[ID]");
            _builder.newLine();
            _builder.append("end");
            _builder.newLine();
            _builder.newLine();
            {
              boolean _equals_3 = ports.equals("1x2");
              if (_equals_3) {
                _builder.append("forward1: action in1: [a] ==> out2: [a]");
                _builder.newLine();
                _builder.append("guard SEL[ID] ");
                _builder.newLine();
                _builder.append("end");
                _builder.newLine();
              } else {
                _builder.append("forward1: action in2: [a] ==> out1: [a]");
                _builder.newLine();
                _builder.append("guard SEL[ID] ");
                _builder.newLine();
                _builder.append("end");
                _builder.newLine();
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the interface of the file
   */
  public CharSequence printInterface(final String ports) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("actor Sbox");
    {
      boolean _equals = ports.equals("1x2");
      if (_equals) {
        _builder.append("1x2");
      } else {
        _builder.append("2x1");
      }
    }
    _builder.append(this.typeData);
    {
      boolean _equals_1 = this.typeData.equals("int");
      if (_equals_1) {
        _builder.append(this.typeSize);
      }
    }
    _builder.append(" (");
    {
      boolean _equals_2 = this.typeSB.equals("STATIC");
      if (_equals_2) {
        _builder.append("int ID=0");
        {
          boolean _equals_3 = this.typeData.equals("int");
          if (_equals_3) {
            _builder.append(", int SIZE=");
            _builder.append(this.typeSize);
          }
        }
      } else {
        {
          boolean _equals_4 = this.typeData.equals("int");
          if (_equals_4) {
            _builder.append("int SIZE=");
            _builder.append(this.typeSize);
          }
        }
      }
    }
    _builder.append(") ");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    {
      boolean _equals_5 = this.typeSB.equals("DYNAMIC");
      if (_equals_5) {
        _builder.append("bool sel,");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append(this.typeData, "\t");
    {
      boolean _equals_6 = this.typeData.equals("int");
      if (_equals_6) {
        _builder.append("(size=SIZE)");
      }
    }
    _builder.append(" in1");
    {
      boolean _equals_7 = ports.equals("2x1");
      if (_equals_7) {
        _builder.append(",");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    {
      boolean _equals_8 = ports.equals("2x1");
      if (_equals_8) {
        _builder.append(this.typeData, "\t");
        {
          boolean _equals_9 = this.typeData.equals("int");
          if (_equals_9) {
            _builder.append("(size=SIZE)");
          }
        }
        _builder.append(" in2");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("==>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(this.typeData, "\t");
    {
      boolean _equals_10 = this.typeData.equals("int");
      if (_equals_10) {
        _builder.append("(size=SIZE)");
      }
    }
    _builder.append(" out1");
    {
      boolean _equals_11 = ports.equals("1x2");
      if (_equals_11) {
        _builder.append(",");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    {
      boolean _equals_12 = ports.equals("1x2");
      if (_equals_12) {
        _builder.append(this.typeData, "\t");
        {
          boolean _equals_13 = this.typeData.equals("int");
          if (_equals_13) {
            _builder.append("(size=SIZE)");
          }
        }
        _builder.append(" out2");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append(":");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * <ul>
   * <li> print header comments: headerComments();
   * <li> print interface: printInterface();
   * <li> print body: printBody().
   * </ul>
   */
  public CharSequence printSboxes(final String typeSB, final String typeData, final String typeSize, final String ports, final String packageName) {
    CharSequence _xblockexpression = null;
    {
      this.typeData = typeData;
      this.typeSize = typeSize;
      this.typeSB = typeSB;
      this.luts = this.luts;
      this.configMap = this.configMap;
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _headerComments = this.headerComments(ports);
      _builder.append(_headerComments);
      _builder.newLineIfNotEmpty();
      _builder.append("package ");
      _builder.append(packageName);
      _builder.append(";");
      _builder.newLineIfNotEmpty();
      {
        boolean _equals = typeSB.equals("STATIC");
        if (_equals) {
          _builder.append("import ");
          _builder.append(packageName);
          _builder.append(".Configurator.SEL;");
        }
      }
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printInterface = this.printInterface(ports);
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printBody = this.printBody(ports);
      _builder.append(_printBody);
      _builder.newLineIfNotEmpty();
      _builder.append("end");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
}
