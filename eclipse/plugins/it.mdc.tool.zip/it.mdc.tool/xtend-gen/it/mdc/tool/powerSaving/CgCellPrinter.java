package it.mdc.tool.powerSaving;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.eclipse.xtend2.lib.StringConcatenation;

/**
 * A Verilog Network Configurator printer
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class CgCellPrinter {
  public CharSequence headerComments(final String type) {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Clock Gating Cell module ");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Print body of clock gating cells.
   * If target is FPGA, a BUFGCE is instantiated.
   * If target is ASIC, clock is gated by clock enable through a AND assignment
   */
  public CharSequence printBody(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Latch");
    _builder.newLine();
    _builder.append("always@(*)");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("begin");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("if(~clk)");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("enable = en;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("end");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    {
      boolean _equals = type.equals("FPGA");
      if (_equals) {
        _builder.append("// BUFG instance");
        _builder.newLine();
        _builder.append("BUFGCE BUFGCE_inst (");
        _builder.newLine();
        _builder.append("\t");
        _builder.append(".O(ck_gated),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append(".CE(enable),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append(".I(clk)");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
      } else {
        _builder.append("// And");
        _builder.newLine();
        _builder.append("assign ck_gated = clk && enable;");
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  public CharSequence printSignals() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Input(s)");
    _builder.newLine();
    _builder.append("input clk;");
    _builder.newLine();
    _builder.append("input en;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// Ouptut(s)");
    _builder.newLine();
    _builder.append("output ck_gated;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// Wire(s)");
    _builder.newLine();
    _builder.append("wire clk;");
    _builder.newLine();
    _builder.append("wire en;");
    _builder.newLine();
    _builder.append("wire ck_gated;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// Reg");
    _builder.newLine();
    _builder.append("reg enable;");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printInterface() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module clock_gating_cell(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("clk,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("en,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("ck_gated");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printCgCell(final String type) {
    StringConcatenation _builder = new StringConcatenation();
    CharSequence _headerComments = this.headerComments(type);
    _builder.append(_headerComments);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Module Interface");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    CharSequence _printInterface = this.printInterface();
    _builder.append(_printInterface);
    _builder.newLineIfNotEmpty();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Module Signals");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    CharSequence _printSignals = this.printSignals();
    _builder.append(_printSignals);
    _builder.newLineIfNotEmpty();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Body");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    CharSequence _printBody = this.printBody(type);
    _builder.append(_printBody);
    _builder.newLineIfNotEmpty();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.newLine();
    _builder.append("endmodule");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    return _builder;
  }
}
