package it.mdc.tool.prototyping;

import it.mdc.tool.core.platformComposer.ProtocolManager;
import it.mdc.tool.core.sboxManagement.SboxLut;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Pulp HWPE Wrapper Printer
 * 
 * @author Tiziana Fanni
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class PulpPrinter {
  private Map<Port, Integer> inputMap;
  
  private Map<Port, Integer> outputMap;
  
  private Map<Port, Integer> portMap;
  
  private List<Integer> signals;
  
  private List<SboxLut> luts;
  
  private int portSize;
  
  private int dataSize = 32;
  
  private Map<String, List<Port>> netPorts;
  
  private boolean dedicatedInterfaces = false;
  
  private String coupling = "";
  
  private boolean enableMonitoring;
  
  private Map<String, Map<String, String>> netSysSignals;
  
  private Map<String, Map<String, Map<String, String>>> modCommSignals;
  
  private Map<String, Map<String, String>> wrapCommSignals;
  
  private List<String> monList;
  
  public void computeNetsPorts(final Map<String, Map<String, String>> networkVertexMap) {
    HashMap<String, List<Port>> _hashMap = new HashMap<String, List<Port>>();
    this.netPorts = _hashMap;
    Set<String> _keySet = networkVertexMap.keySet();
    for (final String net : _keySet) {
      List<Integer> _sort = IterableExtensions.<Integer>sort(this.portMap.values());
      for (final int id : _sort) {
        Set<Port> _keySet_1 = this.portMap.keySet();
        for (final Port port : _keySet_1) {
          boolean _equals = this.portMap.get(port).equals(Integer.valueOf(id));
          if (_equals) {
            boolean _contains = networkVertexMap.get(net).values().contains(port.getName());
            if (_contains) {
              boolean _containsKey = this.netPorts.containsKey(net);
              if (_containsKey) {
                this.netPorts.get(net).add(port);
              } else {
                List<Port> ports = new ArrayList<Port>();
                ports.add(port);
                this.netPorts.put(net, ports);
              }
            }
          }
        }
      }
    }
  }
  
  public int computeSizePointer() {
    boolean _equals = this.coupling.equals("mm");
    if (_equals) {
      if (this.enableMonitoring) {
        int _size = this.portMap.size();
        int _size_1 = this.monList.size();
        int _plus = (_size + _size_1);
        double _log10 = Math.log10(_plus);
        double _log10_1 = Math.log10(2);
        double _divide = (_log10 / _log10_1);
        double _plus_1 = (_divide + 0.5);
        return Math.round(((float) _plus_1));
      } else {
        double _log10_2 = Math.log10(this.portMap.size());
        double _log10_3 = Math.log10(2);
        double _divide_1 = (_log10_2 / _log10_3);
        double _plus_2 = (_divide_1 + 0.5);
        return Math.round(((float) _plus_2));
      }
    } else {
      double _log10_4 = Math.log10(this.outputMap.size());
      double _log10_5 = Math.log10(2);
      double _divide_2 = (_log10_4 / _log10_5);
      double _plus_3 = (_divide_2 + 0.5);
      return Math.round(((float) _plus_3));
    }
  }
  
  public String getLongId(final int id) {
    if ((id < 10)) {
      String _string = Integer.valueOf(id).toString();
      return ("0" + _string);
    } else {
      return Integer.valueOf(id).toString();
    }
  }
  
  public int mapInOut(final Network network) {
    int _xblockexpression = (int) 0;
    {
      int index = 0;
      int size = 0;
      LinkedHashMap<Port, Integer> _linkedHashMap = new LinkedHashMap<Port, Integer>();
      this.inputMap = _linkedHashMap;
      LinkedHashMap<Port, Integer> _linkedHashMap_1 = new LinkedHashMap<Port, Integer>();
      this.outputMap = _linkedHashMap_1;
      LinkedHashMap<Port, Integer> _linkedHashMap_2 = new LinkedHashMap<Port, Integer>();
      this.portMap = _linkedHashMap_2;
      EList<Port> _inputs = network.getInputs();
      for (final Port input : _inputs) {
        {
          this.inputMap.put(input, Integer.valueOf(index));
          this.portMap.put(input, Integer.valueOf(index));
          index = (index + 1);
        }
      }
      index = 0;
      EList<Port> _outputs = network.getOutputs();
      for (final Port output : _outputs) {
        {
          this.outputMap.put(output, Integer.valueOf(index));
          int _size = this.inputMap.size();
          int _plus = (index + _size);
          this.portMap.put(output, Integer.valueOf(_plus));
          index = (index + 1);
        }
      }
      size = Math.max(this.inputMap.size(), this.outputMap.size());
      double _log10 = Math.log10(size);
      double _log10_1 = Math.log10(2);
      double _divide = (_log10 / _log10_1);
      double _plus = (_divide + 0.5);
      _xblockexpression = this.portSize = Math.round(((float) _plus));
    }
    return _xblockexpression;
  }
  
  public void mapSignals() {
    int size = Math.max(this.inputMap.size(), this.outputMap.size());
    int index = 1;
    ArrayList<Integer> _arrayList = new ArrayList<Integer>(size);
    this.signals = _arrayList;
    while ((index <= size)) {
      {
        this.signals.add((index - 1), Integer.valueOf(index));
        index = (index + 1);
      }
    }
  }
  
  public Map<Port, Integer> getPortMap() {
    return this.portMap;
  }
  
  public Map<Port, Integer> getInputMap() {
    return this.inputMap;
  }
  
  public Map<Port, Integer> getOutputMap() {
    return this.outputMap;
  }
  
  public Map<String, Map<String, String>> initPulpPrinter(final List<SboxLut> luts, final Map<String, Map<String, String>> netSysSignals, final Map<String, Map<String, Map<String, String>>> modCommSignals, final Map<String, Map<String, String>> wrapCommSignals) {
    Map<String, Map<String, String>> _xblockexpression = null;
    {
      this.coupling = this.coupling;
      this.enableMonitoring = this.enableMonitoring;
      this.monList = this.monList;
      this.luts = luts;
      this.netSysSignals = netSysSignals;
      this.modCommSignals = modCommSignals;
      _xblockexpression = this.wrapCommSignals = wrapCommSignals;
    }
    return _xblockexpression;
  }
  
  public boolean hasParameter(final String portValue) {
    boolean result = false;
    int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
    boolean _greaterThan = (_size > 3);
    if (_greaterThan) {
      result = true;
    }
    return result;
  }
  
  public int getDefaultValue(final String portValue) {
    int defaultValue = 0;
    boolean _hasParameter = this.hasParameter(portValue);
    if (_hasParameter) {
      String[] _split = portValue.split("_");
      int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
      int _minus = (_size - 1);
      defaultValue = Integer.parseInt(_split[_minus]);
    } else {
      defaultValue = Integer.parseInt(portValue.split("_")[2]);
    }
    return defaultValue;
  }
  
  public String getParameter(final String portValue) {
    String parameter = "";
    int i = 2;
    int _size = ((List<String>)Conversions.doWrapArray(portValue.split("_"))).size();
    boolean _equals = (_size == 4);
    if (_equals) {
      parameter = portValue.split("_")[2];
    } else {
      while ((i < (((List<String>)Conversions.doWrapArray(portValue.split("_"))).size() - 1))) {
        {
          boolean _equals_1 = parameter.equals("");
          if (_equals_1) {
            String _get = portValue.split("_")[i];
            String _plus = (parameter + _get);
            parameter = _plus;
          } else {
            String _get_1 = portValue.split("_")[i];
            String _plus_1 = ((parameter + "_") + _get_1);
            parameter = _plus_1;
          }
          i = (i + 1);
        }
      }
    }
    return parameter;
  }
  
  public String getDirection(final String portValue) {
    String direction = portValue;
    boolean _contains = portValue.contains("_");
    if (_contains) {
      direction = portValue.split("_")[0];
    }
    return direction;
  }
  
  public String getReverseDirection(final String portValue) {
    String direction = this.getDirection(portValue);
    boolean _equals = direction.equals("in");
    if (_equals) {
      direction = "out";
    } else {
      direction = "in";
    }
    return direction;
  }
  
  public CharSequence printTop(final Network network) {
    CharSequence _xblockexpression = null;
    {
      this.mapInOut(network);
      this.mapSignals();
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _printTopHeaderComments = this.printTopHeaderComments();
      _builder.append(_printTopHeaderComments);
      _builder.newLineIfNotEmpty();
      _builder.append("import multi_dataflow_package::*;");
      _builder.newLine();
      _builder.append("import hwpe_ctrl_package::*;");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Interface");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopInterface = this.printTopInterface();
      _builder.append(_printTopInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Module Signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopSignals = this.printTopSignals();
      _builder.append(_printTopSignals);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      {
        if (this.enableMonitoring) {
          _builder.append("//monitoring");
          _builder.newLine();
          _builder.newLine();
          {
            for(final String monitor : this.monList) {
              _builder.append("// Monitor ");
              int _indexOf = this.monList.indexOf(monitor);
              _builder.append(_indexOf);
              _builder.append(": ");
              _builder.append(monitor);
              _builder.newLineIfNotEmpty();
              _builder.append("wire clear_monitor_");
              int _indexOf_1 = this.monList.indexOf(monitor);
              _builder.append(_indexOf_1);
              _builder.append(";");
              _builder.newLineIfNotEmpty();
              _builder.append("reg [31 : 0]  ");
              _builder.append(monitor);
              _builder.append(";");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.newLine();
          {
            boolean _contains = this.monList.contains("count_clock_cycles");
            if (_contains) {
              _builder.append("reg en_clock_count;");
              _builder.newLine();
              _builder.append("reg state, next_state;  ");
              _builder.newLine();
            }
          }
        }
      }
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// Body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printTopBody = this.printTopBody();
      _builder.append(_printTopBody);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("endmodule");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printTopHeaderComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// This file has been automatically generated by:");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Template Interface Layer module - Memory-Mapped type");
      _builder.newLine();
      _builder.append("// on ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("// More info available at http://sites.unica.it/rpct/");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public String getSizePrefix(final String size) {
    boolean _equals = size.equals("1");
    if (_equals) {
      return "";
    } else {
      return (("[" + size) + "-1 : 0] ");
    }
  }
  
  public String getPortCommSigSize(final Port port, final String commSigId, final Map<String, Map<String, String>> commSigIdMap) {
    boolean _containsKey = commSigIdMap.containsKey(commSigId);
    if (_containsKey) {
      boolean _equals = commSigIdMap.get(commSigId).get(ProtocolManager.SIZE).equals("variable");
      if (_equals) {
        return Integer.valueOf(port.getType().getSizeInBits()).toString();
      } else {
        return commSigIdMap.get(commSigId).get(ProtocolManager.SIZE);
      }
    }
    return null;
  }
  
  public CharSequence printTopSignals() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// system level signals");
    _builder.newLine();
    _builder.append("logic enable, clear;");
    _builder.newLine();
    _builder.append("ctrl_streamer_t  streamer_ctrl;");
    _builder.newLine();
    _builder.append("flags_streamer_t streamer_flags;");
    _builder.newLine();
    _builder.append("ctrl_engine_t    engine_ctrl;");
    _builder.newLine();
    _builder.append("flags_engine_t   engine_flags;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// communication signals");
    _builder.newLine();
    {
      Set<Port> _keySet = this.inputMap.keySet();
      for(final Port input : _keySet) {
        {
          Set<String> _keySet_1 = this.getInFirstModCommSignals().keySet();
          for(final String commSigId : _keySet_1) {
            _builder.append("wire ");
            String _sizePrefix = this.getSizePrefix(this.getPortCommSigSize(input, commSigId, this.getFirstModCommSignals()));
            _builder.append(_sizePrefix);
            String _name = input.getName();
            _builder.append(_name);
            _builder.append("_");
            String _matchingWrapMapping = this.getMatchingWrapMapping(this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("wire [31:0] stream_if_");
        String _name_1 = input.getName();
        _builder.append(_name_1);
        _builder.append("_data;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire stream_if_");
        String _name_2 = input.getName();
        _builder.append(_name_2);
        _builder.append("_valid;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire stream_if_");
        String _name_3 = input.getName();
        _builder.append(_name_3);
        _builder.append("_ready;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire [3:0] stream_if_");
        String _name_4 = input.getName();
        _builder.append(_name_4);
        _builder.append("_strb;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_2 = this.outputMap.keySet();
      for(final Port output : _keySet_2) {
        {
          Set<String> _keySet_3 = this.getOutLastModCommSignals().keySet();
          for(final String commSigId_1 : _keySet_3) {
            _builder.append("wire ");
            String _sizePrefix_1 = this.getSizePrefix(this.getPortCommSigSize(output, commSigId_1, this.getLastModCommSignals()));
            _builder.append(_sizePrefix_1);
            String _name_5 = output.getName();
            _builder.append(_name_5);
            _builder.append("_");
            String _matchingWrapMapping_1 = this.getMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping_1);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("wire [31:0] stream_if_");
        String _name_6 = output.getName();
        _builder.append(_name_6);
        _builder.append("_data;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire stream_if_");
        String _name_7 = output.getName();
        _builder.append(_name_7);
        _builder.append("_valid;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire stream_if_");
        String _name_8 = output.getName();
        _builder.append(_name_8);
        _builder.append("_ready;");
        _builder.newLineIfNotEmpty();
        _builder.append("wire [3:0] stream_if_");
        String _name_9 = output.getName();
        _builder.append(_name_9);
        _builder.append("_strb;");
        _builder.newLineIfNotEmpty();
      }
    }
    return _builder;
  }
  
  public CharSequence printTopInterface() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module multi_dataflow_top ");
    _builder.newLine();
    _builder.append("#(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("parameter int unsigned N_CORES = 2,");
    _builder.newLine();
    _builder.append("  \t");
    _builder.append("parameter int unsigned MP  = ");
    int _size = this.portMap.size();
    _builder.append(_size, "  \t");
    _builder.append(",");
    _builder.newLineIfNotEmpty();
    _builder.append("  \t");
    _builder.append("parameter int unsigned ID  = 10 ");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    _builder.append("(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// global signals");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input  logic                                  clk_i,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input  logic                                  rst_ni,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("input  logic                                  test_mode_i,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// events");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("output logic [N_CORES-1:0][REGFILE_N_EVT-1:0] evt_o,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// tcdm master ports");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("hwpe_stream_intf_tcdm.master                  tcdm[MP-1:0],");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// periph slave port");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("hwpe_ctrl_intf_periph.slave                   periph");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printTopBody() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// hwpe stream interfaces");
    _builder.newLine();
    {
      Set<Port> _keySet = this.portMap.keySet();
      for(final Port port : _keySet) {
        _builder.append("// hwpe stream intf ");
        String _name = port.getName();
        _builder.append(_name);
        _builder.newLineIfNotEmpty();
        _builder.append("hwpe_stream_intf_stream #(");
        _builder.newLine();
        _builder.append("\t");
        _builder.append(".DATA_WIDTH(32)");
        _builder.newLine();
        _builder.append(") stream_if_");
        String _name_1 = port.getName();
        _builder.append(_name_1);
        _builder.append(" (");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".clk ( clk_i )");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("// hwpe strem interface wrappers");
    _builder.newLine();
    {
      Set<Port> _keySet_1 = this.inputMap.keySet();
      for(final Port input : _keySet_1) {
        _builder.append("// hwpe stream intf in ");
        String _name_2 = input.getName();
        _builder.append(_name_2);
        _builder.newLineIfNotEmpty();
        _builder.append("interface_wrapper_in i_interface_wrapper_in_");
        String _name_3 = input.getName();
        _builder.append(_name_3);
        _builder.append("(");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".in_data(stream_if_");
        String _name_4 = input.getName();
        _builder.append(_name_4, "\t");
        _builder.append("_data),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".in_valid(stream_if_");
        String _name_5 = input.getName();
        _builder.append(_name_5, "\t");
        _builder.append("_valid),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".in_ready(stream_if_");
        String _name_6 = input.getName();
        _builder.append(_name_6, "\t");
        _builder.append("_ready),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".in_strb(stream_if_");
        String _name_7 = input.getName();
        _builder.append(_name_7, "\t");
        _builder.append("_strb),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".in(stream_if_");
        String _name_8 = input.getName();
        _builder.append(_name_8, "\t");
        _builder.append(".sink)");
        _builder.newLineIfNotEmpty();
        _builder.append(");");
        _builder.newLine();
      }
    }
    {
      Set<Port> _keySet_2 = this.outputMap.keySet();
      for(final Port output : _keySet_2) {
        _builder.append("// hwpe stream intf out ");
        String _name_9 = output.getName();
        _builder.append(_name_9);
        _builder.newLineIfNotEmpty();
        _builder.append("interface_wrapper_out i_interface_wrapper_out_");
        String _name_10 = output.getName();
        _builder.append(_name_10);
        _builder.append("(");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".out_data(stream_if_");
        String _name_11 = output.getName();
        _builder.append(_name_11, "\t");
        _builder.append("_data),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".out_valid(stream_if_");
        String _name_12 = output.getName();
        _builder.append(_name_12, "\t");
        _builder.append("_valid),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".out_ready(stream_if_");
        String _name_13 = output.getName();
        _builder.append(_name_13, "\t");
        _builder.append("_ready),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".out_strb(stream_if_");
        String _name_14 = output.getName();
        _builder.append(_name_14, "\t");
        _builder.append("_strb),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".out(stream_if_");
        String _name_15 = output.getName();
        _builder.append(_name_15, "\t");
        _builder.append(".source)");
        _builder.newLineIfNotEmpty();
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("// Multi-Dataflow Reconfigurable Datapath");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    CharSequence _printTopDatapath = this.printTopDatapath();
    _builder.append(_printTopDatapath);
    _builder.newLineIfNotEmpty();
    {
      Set<Port> _keySet_3 = this.inputMap.keySet();
      for(final Port input_1 : _keySet_3) {
        _builder.append("assign stream_if_");
        String _name_16 = input_1.getName();
        _builder.append(_name_16);
        _builder.append("_ready = ");
        {
          Boolean _isNegMatchingWrapMapping = this.isNegMatchingWrapMapping(this.getFullChannelWrapCommSignalID());
          boolean _not = (!(_isNegMatchingWrapMapping).booleanValue());
          if (_not) {
            _builder.append("!");
          }
        }
        String _name_17 = input_1.getName();
        _builder.append(_name_17);
        _builder.append("_full;");
        _builder.newLineIfNotEmpty();
        _builder.append("assign ");
        String _name_18 = input_1.getName();
        _builder.append(_name_18);
        _builder.append("_data = stream_if_");
        String _name_19 = input_1.getName();
        _builder.append(_name_19);
        _builder.append("_data");
        {
          int _dataSize = this.getDataSize(input_1);
          boolean _lessThan = (_dataSize < 32);
          if (_lessThan) {
            _builder.append(" [");
            int _dataSize_1 = this.getDataSize(input_1);
            int _minus = (_dataSize_1 - 1);
            _builder.append(_minus);
            _builder.append(" : 0]");
          }
        }
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("assign ");
        String _name_20 = input_1.getName();
        _builder.append(_name_20);
        _builder.append("_push = stream_if_");
        String _name_21 = input_1.getName();
        _builder.append(_name_21);
        _builder.append("_valid;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_4 = this.outputMap.keySet();
      for(final Port output_1 : _keySet_4) {
        _builder.append("assign stream_if_");
        String _name_22 = output_1.getName();
        _builder.append(_name_22);
        _builder.append("_valid = ");
        String _name_23 = output_1.getName();
        _builder.append(_name_23);
        _builder.append("_push;");
        _builder.newLineIfNotEmpty();
        _builder.append("assign stream_if_");
        String _name_24 = output_1.getName();
        _builder.append(_name_24);
        _builder.append("_data = ");
        {
          int _dataSize_2 = this.getDataSize(output_1);
          boolean _lessThan_1 = (_dataSize_2 < 32);
          if (_lessThan_1) {
            _builder.append("{{");
            int _dataSize_3 = this.getDataSize(output_1);
            int _minus_1 = (32 - _dataSize_3);
            _builder.append(_minus_1);
            _builder.append("{1\'b0}},");
          }
        }
        String _name_25 = output_1.getName();
        _builder.append(_name_25);
        _builder.append("_data");
        {
          int _dataSize_4 = this.getDataSize(output_1);
          boolean _lessThan_2 = (_dataSize_4 < 32);
          if (_lessThan_2) {
            _builder.append("}");
          }
        }
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("assign stream_if_");
        String _name_26 = output_1.getName();
        _builder.append(_name_26);
        _builder.append("_strb = 4\'b111;");
        _builder.newLineIfNotEmpty();
        _builder.append("assign ");
        String _name_27 = output_1.getName();
        _builder.append(_name_27);
        _builder.append("_full = ");
        {
          Boolean _isNegMatchingWrapMapping_1 = this.isNegMatchingWrapMapping(this.getFullChannelWrapCommSignalID());
          boolean _not_1 = (!(_isNegMatchingWrapMapping_1).booleanValue());
          if (_not_1) {
            _builder.append("!");
          }
        }
        _builder.append("stream_if_");
        String _name_28 = output_1.getName();
        _builder.append(_name_28);
        _builder.append("_ready;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("// ----------------------------------------------------------------------------\t");
    _builder.newLine();
    _builder.newLine();
    {
      Set<Port> _keySet_5 = this.outputMap.keySet();
      for(final Port output_2 : _keySet_5) {
        _builder.append("// Output Counter(s)");
        _builder.newLine();
        _builder.append("// ----------------------------------------------------------------------------");
        _builder.newLine();
        _builder.append("//counter #(\t\t\t");
        _builder.newLine();
        _builder.append("//\t.SIZE(SIZE_ADDR_");
        Integer _get = this.portMap.get(output_2);
        int _plus = ((_get).intValue() + 1);
        _builder.append(_plus);
        _builder.append(") ) ");
        _builder.newLineIfNotEmpty();
        _builder.append("//i_counter_");
        String _name_29 = output_2.getName();
        _builder.append(_name_29);
        _builder.append(" (");
        _builder.newLineIfNotEmpty();
        _builder.append("//\t.aclk(s00_axi_aclk),");
        _builder.newLine();
        _builder.append("//\t.aresetn(s00_axi_aresetn),");
        _builder.newLine();
        _builder.append("//\t.clr(slv_reg0[2]),");
        _builder.newLine();
        _builder.append("//\t.en(");
        String _name_30 = output_2.getName();
        _builder.append(_name_30);
        _builder.append("_push),");
        _builder.newLineIfNotEmpty();
        _builder.append("//\t.max(slv_reg");
        Integer _get_1 = this.outputMap.get(output_2);
        int _plus_1 = ((_get_1).intValue() + 1);
        _builder.append(_plus_1);
        _builder.append("[SIZE_ADDR_");
        Integer _get_2 = this.portMap.get(output_2);
        int _plus_2 = ((_get_2).intValue() + 1);
        _builder.append(_plus_2);
        _builder.append("-1:0]),");
        _builder.newLineIfNotEmpty();
        _builder.append("//\t.count(),");
        _builder.newLine();
        _builder.append("//\t.last(m");
        String _longId = this.getLongId((this.outputMap.get(output_2)).intValue());
        _builder.append(_longId);
        _builder.append("_axis_tlast)");
        _builder.newLineIfNotEmpty();
        _builder.append("//);");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("multi_dataflow_streamer #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".MP ( MP )");
    _builder.newLine();
    _builder.append(") i_streamer (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i            ( clk_i          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni           ( rst_ni         ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".test_mode_i      ( test_mode_i    ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".enable_i         ( enable         ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clear_i          ( clear          ),");
    _builder.newLine();
    {
      Set<Port> _keySet_6 = this.inputMap.keySet();
      for(final Port input_2 : _keySet_6) {
        _builder.append("    ");
        _builder.append(".stream_if_");
        String _name_31 = input_2.getName();
        _builder.append(_name_31, "    ");
        _builder.append(" (stream_if_");
        String _name_32 = input_2.getName();
        _builder.append(_name_32, "    ");
        _builder.append(".source),");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_7 = this.outputMap.keySet();
      for(final Port output_3 : _keySet_7) {
        _builder.append("    ");
        _builder.append(".stream_if_");
        String _name_33 = output_3.getName();
        _builder.append(_name_33, "    ");
        _builder.append(" (stream_if_");
        String _name_34 = output_3.getName();
        _builder.append(_name_34, "    ");
        _builder.append(".sink),");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("    ");
    _builder.append(".tcdm             ( tcdm           ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_i           ( streamer_ctrl  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_o          ( streamer_flags )");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("multi_dataflow_ctrl #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_CORES   ( 2  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_CONTEXT ( 2  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_IO_REGS ( 16 ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ID ( ID )");
    _builder.newLine();
    _builder.append(") i_ctrl (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i            ( clk_i          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni           ( rst_ni         ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".test_mode_i      ( test_mode_i    ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".evt_o            ( evt_o          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clear_o          ( clear          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_streamer_o  ( streamer_ctrl  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_streamer_i ( streamer_flags ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_engine_o    ( engine_ctrl    ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_engine_i   ( engine_flags   ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".periph           ( periph         )");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("assign enable = 1\'b1;");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    return _builder;
  }
  
  public String getFullChannelWrapCommSignalID() {
    Set<String> _keySet = this.wrapCommSignals.keySet();
    for (final String commSigId : _keySet) {
      boolean _equals = this.wrapCommSignals.get(commSigId).get(ProtocolManager.MAP).equals("full");
      if (_equals) {
        return this.wrapCommSignals.get(commSigId).get(ProtocolManager.CH);
      }
    }
    return null;
  }
  
  public Integer getPortIdFromName(final String name) {
    Set<Port> _keySet = this.portMap.keySet();
    for (final Port port : _keySet) {
      boolean _equals = port.getName().equals(name);
      if (_equals) {
        return this.portMap.get(port);
      }
    }
    return null;
  }
  
  public int getDataSize(final Port port) {
    Set<String> _keySet = this.wrapCommSignals.keySet();
    for (final String commSigId : _keySet) {
      boolean _equals = this.wrapCommSignals.get(commSigId).get(ProtocolManager.MAP).equals("data");
      if (_equals) {
        boolean _equals_1 = this.wrapCommSignals.get(commSigId).get(ProtocolManager.SIZE).equals("variable");
        if (_equals_1) {
          return port.getType().getSizeInBits();
        } else {
          return Integer.parseInt(this.wrapCommSignals.get(commSigId).get(ProtocolManager.SIZE));
        }
      }
    }
    return 1;
  }
  
  public CharSequence printTopDatapath() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// to adapt profiling");
    _builder.newLine();
    _builder.append("multi_dataflow reconf_dpath (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Multi-Dataflow Input(s)");
    _builder.newLine();
    {
      Set<Port> _keySet = this.inputMap.keySet();
      for(final Port input : _keySet) {
        {
          Set<String> _keySet_1 = this.getInFirstModCommSignals().keySet();
          for(final String commSigId : _keySet_1) {
            _builder.append("\t");
            _builder.append(".");
            String _name = input.getName();
            _builder.append(_name, "\t");
            String _suffix = this.getSuffix(this.getInFirstModCommSignals(), commSigId);
            _builder.append(_suffix, "\t");
            _builder.append("(");
            String _name_1 = input.getName();
            _builder.append(_name_1, "\t");
            _builder.append("_");
            String _matchingWrapMapping = this.getMatchingWrapMapping(this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.append("// Multi-Dataflow Output(s)");
    _builder.newLine();
    {
      Set<Port> _keySet_2 = this.outputMap.keySet();
      for(final Port output : _keySet_2) {
        {
          Set<String> _keySet_3 = this.getOutLastModCommSignals().keySet();
          for(final String commSigId_1 : _keySet_3) {
            _builder.append("\t");
            _builder.append(".");
            String _name_2 = output.getName();
            _builder.append(_name_2, "\t");
            String _suffix_1 = this.getSuffix(this.getOutLastModCommSignals(), commSigId_1);
            _builder.append(_suffix_1, "\t");
            _builder.append("(");
            {
              Boolean _isNegMatchingWrapMapping = this.isNegMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
              if ((_isNegMatchingWrapMapping).booleanValue()) {
                _builder.append("!");
              }
            }
            String _name_3 = output.getName();
            _builder.append(_name_3, "\t");
            _builder.append("_");
            String _matchingWrapMapping_1 = this.getMatchingWrapMapping(this.getLastModCommSignals().get(commSigId_1).get(ProtocolManager.CH));
            _builder.append(_matchingWrapMapping_1, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    {
      List<String> _clockSysSignals = this.getClockSysSignals();
      for(final String clockSignal : _clockSysSignals) {
        _builder.append("\t");
        _builder.append(".");
        _builder.append(clockSignal, "\t");
        _builder.append("(clk_i)");
        {
          boolean _not = (!(this.getResetSysSignals().isEmpty() && this.luts.isEmpty()));
          if (_not) {
            _builder.append(",");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<String> _keySet_4 = this.getResetSysSignals().keySet();
      for(final String resetSignal : _keySet_4) {
        _builder.append("\t");
        _builder.append(".");
        _builder.append(resetSignal, "\t");
        _builder.append("(");
        {
          boolean _equals = this.getResetSysSignals().get(resetSignal).equals("HIGH");
          if (_equals) {
            _builder.append("!");
          }
        }
        _builder.append("rst_ni)");
        {
          boolean _isEmpty = this.luts.isEmpty();
          boolean _not_1 = (!_isEmpty);
          if (_not_1) {
            _builder.append(",");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    {
      boolean _isEmpty_1 = this.luts.isEmpty();
      boolean _not_2 = (!_isEmpty_1);
      if (_not_2) {
        _builder.append("// Multi-Dataflow Kernel ID");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".ID(engine_ctrl.configuration)");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append(");");
    _builder.newLine();
    return _builder;
  }
  
  public String getSuffix(final Map<String, String> idNameMap, final String id) {
    boolean _containsKey = idNameMap.containsKey(id);
    if (_containsKey) {
      boolean _equals = idNameMap.get(id).equals("");
      if (_equals) {
        return "";
      } else {
        String _get = idNameMap.get(id);
        return ("_" + _get);
      }
    }
    return null;
  }
  
  public String getMatchingWrapMapping(final String channel) {
    Set<String> _keySet = this.wrapCommSignals.keySet();
    for (final String commSigId : _keySet) {
      boolean _containsKey = this.wrapCommSignals.get(commSigId).containsKey(ProtocolManager.CH);
      if (_containsKey) {
        boolean _equals = channel.equals(this.wrapCommSignals.get(commSigId).get(ProtocolManager.CH));
        if (_equals) {
          return this.wrapCommSignals.get(commSigId).get(ProtocolManager.MAP);
        }
      }
    }
    return null;
  }
  
  public Boolean isNegMatchingWrapMapping(final String channel) {
    Set<String> _keySet = this.wrapCommSignals.keySet();
    for (final String commSigId : _keySet) {
      boolean _containsKey = this.wrapCommSignals.get(commSigId).containsKey(ProtocolManager.CH);
      if (_containsKey) {
        boolean _equals = channel.equals(this.wrapCommSignals.get(commSigId).get(ProtocolManager.CH));
        if (_equals) {
          return Boolean.valueOf(this.wrapCommSignals.get(commSigId).containsKey(ProtocolManager.INV));
        }
      }
    }
    return null;
  }
  
  public Map<String, String> getOutLastModCommSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.getLastModCommSignals().keySet();
    for (final String commSigId : _keySet) {
      if (((this.getLastModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("output") && this.getLastModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("direct")) || 
        (this.getLastModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("input") && this.getLastModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("reverse")))) {
        result.put(commSigId, this.getLastModCommSignals().get(commSigId).get(ProtocolManager.CH));
      }
    }
    return result;
  }
  
  public Map<String, Map<String, String>> getLastModCommSignals() {
    boolean _containsKey = this.modCommSignals.containsKey(ProtocolManager.SUCC);
    if (_containsKey) {
      return this.modCommSignals.get(ProtocolManager.SUCC);
    } else {
      return this.modCommSignals.get(ProtocolManager.ACTOR);
    }
  }
  
  public Map<String, String> getInFirstModCommSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.getFirstModCommSignals().keySet();
    for (final String commSigId : _keySet) {
      if (((this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("input") && this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("direct")) || 
        (this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.KIND).equals("output") && this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.DIR).equals("reverse")))) {
        result.put(commSigId, this.getFirstModCommSignals().get(commSigId).get(ProtocolManager.CH));
      }
    }
    return result;
  }
  
  public Map<String, Map<String, String>> getFirstModCommSignals() {
    boolean _containsKey = this.modCommSignals.containsKey(ProtocolManager.PRED);
    if (_containsKey) {
      return this.modCommSignals.get(ProtocolManager.PRED);
    } else {
      return this.modCommSignals.get(ProtocolManager.ACTOR);
    }
  }
  
  public List<String> getClockSysSignals() {
    List<String> result = new ArrayList<String>();
    Set<String> _keySet = this.netSysSignals.keySet();
    for (final String sysSigId : _keySet) {
      boolean _containsKey = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.CLOCK);
      if (_containsKey) {
        result.add(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP));
      }
    }
    return result;
  }
  
  public Map<String, String> getResetSysSignals() {
    Map<String, String> result = new HashMap<String, String>();
    Set<String> _keySet = this.netSysSignals.keySet();
    for (final String sysSigId : _keySet) {
      boolean _containsKey = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.RST);
      if (_containsKey) {
        result.put(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP), "HIGH");
      } else {
        boolean _containsKey_1 = this.netSysSignals.get(sysSigId).containsKey(ProtocolManager.RSTN);
        if (_containsKey_1) {
          result.put(this.netSysSignals.get(sysSigId).get(ProtocolManager.NETP), "LOW");
        }
      }
    }
    return result;
  }
  
  public CharSequence printCtrl() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("/*");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("* Module: multi_dataflow_ctrl.sv");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("*/");
    _builder.newLine();
    _builder.append(" ");
    _builder.newLine();
    _builder.append("import multi_dataflow_package::*;");
    _builder.newLine();
    _builder.append("import hwpe_ctrl_package::*;");
    _builder.newLine();
    _builder.append("module multi_dataflow_ctrl");
    _builder.newLine();
    _builder.append("#(");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned N_CORES         = 2,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned N_CONTEXT       = 2,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned N_IO_REGS       = 16,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned ID              = 10,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned UCODE_HARDWIRED = 0");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    _builder.append("(  // Global signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  clk_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  rst_ni,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  test_mode_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic                                  clear_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// events");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [N_CORES-1:0][REGFILE_N_EVT-1:0] evt_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// ctrl & flags");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_streamer_t                        ctrl_streamer_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_streamer_t                       flags_streamer_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_engine_t                          ctrl_engine_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_engine_t                         flags_engine_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// periph slave port");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_ctrl_intf_periph.slave                   periph");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Ctrl/flags signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("ctrl_slave_t   slave_ctrl;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("flags_slave_t  slave_flags;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("ctrl_regfile_t reg_file;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Uloop signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic [223:0]  ucode_flat;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("ucode_t   ucode;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("ctrl_ucode_t   ucode_ctrl;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("flags_ucode_t  ucode_flags;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic [11:0][31:0] ucode_registers_read;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Standard registers");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic unsigned [31:0] static_reg_nb_iter;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic unsigned [31:0] static_reg_len_iter;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic unsigned [31:0] static_reg_vectstride;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic unsigned [31:0] static_reg_onestride;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic unsigned [15:0] static_reg_shift;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("logic static_reg_simplemul;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Custom register files");
    _builder.newLine();
    _builder.append("  \t\t  ");
    _builder.append("logic unsigned [(32-1):0] static_reg_0;");
    _builder.newLine();
    {
      Set<Port> _keySet = this.portMap.keySet();
      for(final Port port : _keySet) {
        _builder.append("  ");
        _builder.append("logic unsigned [(32-1):0] static_reg_");
        Integer _get = this.portMap.get(port);
        int _plus = ((_get).intValue() + 1);
        _builder.append(_plus, "  ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("ctrl_fsm_t fsm_ctrl;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("/* Peripheral slave & register file */");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_ctrl_slave #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_CORES        ( N_CORES               ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_CONTEXT      ( N_CONTEXT             ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_IO_REGS      ( N_IO_REGS             ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_GENERIC_REGS ( (1-UCODE_HARDWIRED)*8 ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ID_WIDTH       ( ID                    )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(") i_slave (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i    ( clk_i       ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni   ( rst_ni      ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clear_o  ( clear_o     ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".cfg      ( periph      ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_i   ( slave_ctrl  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_o  ( slave_flags ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".reg_file ( reg_file    )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign evt_o = slave_flags.evt;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("/* Direct register file mappings */");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Standard registers");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_nb_iter    = reg_file.hwpe_params[REG_NB_ITER]  + 1;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_len_iter   = reg_file.hwpe_params[REG_LEN_ITER] + 1;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_shift      = reg_file.hwpe_params[REG_SHIFT_SIMPLEMUL][31:16];");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_simplemul  = reg_file.hwpe_params[REG_SHIFT_SIMPLEMUL][0];");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_vectstride = reg_file.hwpe_params[REG_SHIFT_VECTSTRIDE];");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_onestride  = 4;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Custom registers");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign static_reg_0 = reg_file.hwpe_params[CONFIG];");
    _builder.newLine();
    {
      Set<Port> _keySet_1 = this.portMap.keySet();
      for(final Port port_1 : _keySet_1) {
        _builder.append("  \t\t");
        _builder.append("assign static_reg_");
        Integer _get_1 = this.portMap.get(port_1);
        int _plus_1 = ((_get_1).intValue() + 1);
        _builder.append(_plus_1, "  \t\t");
        _builder.append(" = reg_file.hwpe_params[PORT_");
        String _name = port_1.getName();
        _builder.append(_name, "  \t\t");
        _builder.append("];");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("/* Microcode processor */");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("generate");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("if(UCODE_HARDWIRED != 0) begin");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("// equivalent to the microcode in ucode/code.yml");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign ucode_flat = 224\'h0000000000040000000000000000000000000000000008cd11a12c05;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("else begin");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("// the microcode is stored in registers independent of context (job)");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign ucode_flat = reg_file.generic_params[6:0];");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("endgenerate");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign ucode = {");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// loops & bytecode");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ucode_flat,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// ranges");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("12\'b0,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("12\'b0,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("12\'b0,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("12\'b0,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("12\'b0,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("static_reg_nb_iter[11:0]");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("};");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign ucode_registers_read[UCODE_MNEM_NBITER]     = static_reg_nb_iter;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign ucode_registers_read[UCODE_MNEM_ITERSTRIDE] = static_reg_vectstride;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign ucode_registers_read[UCODE_MNEM_ONESTRIDE]  = static_reg_onestride;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("assign ucode_registers_read[11:3] = \'0;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_ctrl_ucode #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".NB_LOOPS       ( 1  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".NB_REG         ( 4  ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".NB_RO_REG      ( 12 )\t\t  ");
    _builder.newLine();
    _builder.append("\t     ");
    _builder.append(") i_uloop (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i            ( clk_i                ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni           ( rst_ni               ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".test_mode_i      ( test_mode_i          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clear_i          ( clear_o              ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_i           ( ucode_ctrl           ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_o          ( ucode_flags          ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ucode_i          ( ucode                ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".registers_read_i ( ucode_registers_read )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("/* Main FSM */");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("multi_dataflow_fsm i_fsm (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i            ( clk_i              ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni           ( rst_ni             ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".test_mode_i      ( test_mode_i        ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clear_i          ( clear_o            ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_streamer_o  ( ctrl_streamer_o    ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_streamer_i ( flags_streamer_i   ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_engine_o    ( ctrl_engine_o      ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_engine_i   ( flags_engine_i     ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_ucode_o     ( ucode_ctrl         ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_ucode_i    ( ucode_flags        ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_slave_o     ( slave_ctrl         ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".flags_slave_i    ( slave_flags        ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".reg_file_i       ( reg_file           ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ctrl_i           ( fsm_ctrl           )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("always_comb");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("begin");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("fsm_ctrl.simple_mul = static_reg_simplemul;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("fsm_ctrl.shift      = static_reg_shift[$clog2(32)-1:0];");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("fsm_ctrl.len        = static_reg_len_iter[$clog2(CNT_LEN):0];");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// Custom register file mappings to fsm");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("fsm_ctrl.configuration    = static_reg_0;");
    _builder.newLine();
    {
      Set<Port> _keySet_2 = this.portMap.keySet();
      for(final Port port_2 : _keySet_2) {
        _builder.append("    ");
        _builder.append("fsm_ctrl.port_");
        String _name_1 = port_2.getName();
        _builder.append(_name_1, "    ");
        _builder.append("    = static_reg_");
        Integer _get_2 = this.portMap.get(port_2);
        int _plus_2 = ((_get_2).intValue() + 1);
        _builder.append(_plus_2, "    ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("endmodule");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printFSM() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("/*");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("* Module: multi_dataflow_fsm.sv");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("*/");
    _builder.newLine();
    _builder.append("import multi_dataflow_package::*;");
    _builder.newLine();
    _builder.append("import hwpe_ctrl_package::*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("module multi_dataflow_fsm (");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Global signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  clk_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  rst_ni,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  test_mode_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic                                  clear_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// ctrl & flags");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_streamer_t                        ctrl_streamer_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_streamer_t                       flags_streamer_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_engine_t                          ctrl_engine_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_engine_t                         flags_engine_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_ucode_t                           ctrl_ucode_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_ucode_t                          flags_ucode_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output ctrl_slave_t                           ctrl_slave_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  flags_slave_t                          flags_slave_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  ctrl_regfile_t                         reg_file_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  ctrl_fsm_t                             ctrl_i");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// State signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("state_fsm_t curr_state, next_state;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// State computation");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("always_ff @(posedge clk_i or negedge rst_ni)");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("begin : main_fsm_seq");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("if(~rst_ni) begin");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("curr_state <= FSM_IDLE;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("else if(clear_i) begin");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("curr_state <= FSM_IDLE;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("else begin");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("curr_state <= next_state;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// State declaration");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("always_comb");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("begin : main_fsm_comb");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// direct mappings - these have to be here due to blocking/non-blocking assignment");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// combination with the same ctrl_engine_o/ctrl_streamer_o variable");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// shift-by-3 due to conversion from bits to bytes");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("//");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// INITIALIZATION");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("//");
    _builder.newLine();
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("/* INPUT FLOW */");
    _builder.newLine();
    {
      Set<Port> _keySet = this.inputMap.keySet();
      for(final Port input : _keySet) {
        _builder.append("    ");
        _builder.append("// ");
        String _name = input.getName();
        _builder.append(_name, "    ");
        _builder.append(" stream");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_1 = input.getName();
        _builder.append(_name_1, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.trans_size  = ctrl_i.len;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_2 = input.getName();
        _builder.append(_name_2, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.line_stride = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_3 = input.getName();
        _builder.append(_name_3, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.line_length = ctrl_i.len;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_4 = input.getName();
        _builder.append(_name_4, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.feat_stride = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_5 = input.getName();
        _builder.append(_name_5, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.feat_length = 1;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_6 = input.getName();
        _builder.append(_name_6, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.base_addr   = reg_file_i.hwpe_params[PORT_");
        String _name_7 = input.getName();
        _builder.append(_name_7, "    ");
        _builder.append("_ADDR] + (flags_ucode_i.offs[PORT_");
        String _name_8 = input.getName();
        _builder.append(_name_8, "    ");
        _builder.append("_UCODE_OFFS]);");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_9 = input.getName();
        _builder.append(_name_9, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.feat_roll   = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_10 = input.getName();
        _builder.append(_name_10, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.loop_outer  = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_11 = input.getName();
        _builder.append(_name_11, "    ");
        _builder.append("_source_ctrl.addressgen_ctrl.realign_type = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.newLine();
      }
    }
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("/* OUTPUT FLOW */");
    _builder.newLine();
    {
      Set<Port> _keySet_1 = this.outputMap.keySet();
      for(final Port output : _keySet_1) {
        _builder.append("    ");
        _builder.append("// ");
        String _name_12 = output.getName();
        _builder.append(_name_12, "    ");
        _builder.append(" stream");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("// ctrl_streamer_o.");
        String _name_13 = output.getName();
        _builder.append(_name_13, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.trans_size  = (ctrl_i.simple_mul) ? ctrl_i.len : 1;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_14 = output.getName();
        _builder.append(_name_14, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.trans_size  =  ctrl_i.len;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_15 = output.getName();
        _builder.append(_name_15, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.line_stride = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("// ctrl_streamer_o.");
        String _name_16 = output.getName();
        _builder.append(_name_16, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.line_length = (ctrl_i.simple_mul) ? ctrl_i.len : 1;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_17 = output.getName();
        _builder.append(_name_17, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.line_length =  ctrl_i.len;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_18 = output.getName();
        _builder.append(_name_18, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.feat_stride = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_19 = output.getName();
        _builder.append(_name_19, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.feat_length = 1;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_20 = output.getName();
        _builder.append(_name_20, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.base_addr   = reg_file_i.hwpe_params[PORT_");
        String _name_21 = output.getName();
        _builder.append(_name_21, "    ");
        _builder.append("_ADDR] + (flags_ucode_i.offs[PORT_");
        String _name_22 = output.getName();
        _builder.append(_name_22, "    ");
        _builder.append("_UCODE_OFFS]);");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_23 = output.getName();
        _builder.append(_name_23, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.feat_roll   = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_24 = output.getName();
        _builder.append(_name_24, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.loop_outer  = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("ctrl_streamer_o.");
        String _name_25 = output.getName();
        _builder.append(_name_25, "    ");
        _builder.append("_sink_ctrl.addressgen_ctrl.realign_type = \'0;");
        _builder.newLineIfNotEmpty();
        _builder.append("    ");
        _builder.append("//");
        _builder.newLine();
        _builder.append("    ");
        _builder.newLine();
      }
    }
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// ucode");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_ucode_o.accum_loop = \'0; // this is not relevant for this simple accelerator, and it should be moved from");
    _builder.newLine();
    _builder.append("                                     ");
    _builder.append("// ucode to an accelerator-specific module");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// engine");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.clear      = \'1;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.enable     = \'1;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.start      = \'0;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.simple_mul = ctrl_i.simple_mul;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.shift      = ctrl_i.shift;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.len        = ctrl_i.len;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_engine_o.configuration    = ctrl_i.configuration;");
    _builder.newLine();
    {
      Set<Port> _keySet_2 = this.portMap.keySet();
      for(final Port port : _keySet_2) {
        _builder.append("    ");
        _builder.append("ctrl_engine_o.port_");
        String _name_26 = port.getName();
        _builder.append(_name_26, "    ");
        _builder.append("    = ctrl_i.port_");
        String _name_27 = port.getName();
        _builder.append(_name_27, "    ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// slave");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_slave_o.done = \'0;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_slave_o.evt  = \'0;");
    _builder.newLine();
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// real finite-state machine");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("next_state   = curr_state;");
    _builder.newLine();
    {
      Set<Port> _keySet_3 = this.inputMap.keySet();
      for(final Port input_1 : _keySet_3) {
        _builder.append("ctrl_streamer_o.");
        String _name_28 = input_1.getName();
        _builder.append(_name_28);
        _builder.append("_source_ctrl.req_start    = \'0;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_4 = this.outputMap.keySet();
      for(final Port output_1 : _keySet_4) {
        _builder.append("ctrl_streamer_o.");
        String _name_29 = output_1.getName();
        _builder.append(_name_29);
        _builder.append("_sink_ctrl.req_start      = \'0;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("    ");
    _builder.append("ctrl_ucode_o.enable                        = \'0;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ctrl_ucode_o.clear                         = \'0;");
    _builder.newLine();
    _builder.append("    ");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("//");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// STATES");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("//");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("case(curr_state)");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_IDLE: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// wait for a start signal");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_ucode_o.clear = \'1;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(flags_slave_i.start) begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("next_state = FSM_START;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_START: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// update the indeces, then load the first feature");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(");
    _builder.newLine();
    {
      Set<Port> _keySet_5 = this.inputMap.keySet();
      for(final Port input_2 : _keySet_5) {
        _builder.append("          \t");
        _builder.append("flags_streamer_i.");
        String _name_30 = input_2.getName();
        _builder.append(_name_30, "          \t");
        _builder.append("_source_flags.ready_start &");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_6 = this.outputMap.keySet();
      boolean _hasElements = false;
      for(final Port output_2 : _keySet_6) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(" & ", "");
        }
        _builder.append("flags_streamer_i.");
        String _name_31 = output_2.getName();
        _builder.append(_name_31);
        _builder.append("_sink_flags.ready_start");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(")  begin");
    _builder.newLineIfNotEmpty();
    _builder.append("          ");
    _builder.append("next_state  = FSM_COMPUTE;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.start  = 1\'b1;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.enable = 1\'b1;");
    _builder.newLine();
    {
      Set<Port> _keySet_7 = this.inputMap.keySet();
      for(final Port input_3 : _keySet_7) {
        _builder.append("          ");
        _builder.append("ctrl_streamer_o.");
        String _name_32 = input_3.getName();
        _builder.append(_name_32, "          ");
        _builder.append("_source_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_8 = this.outputMap.keySet();
      for(final Port output_3 : _keySet_8) {
        _builder.append("          ");
        _builder.append("ctrl_streamer_o.");
        String _name_33 = output_3.getName();
        _builder.append(_name_33, "          ");
        _builder.append("_sink_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("else begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("next_state = FSM_WAIT;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_COMPUTE: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("//if((flags_engine_i.cnt == ctrl_i.len) & flags_engine_i.acc_valid)");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("//next_state = FSM_UPDATEIDX;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if (flags_engine_i.cnt == ctrl_i.len)");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("next_state = FSM_TERMINATE;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(flags_engine_i.ready) begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.start  = 1\'b1;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.enable = 1\'b1;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_UPDATEIDX: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// update the indeces, then go back to load or idle");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(flags_ucode_i.valid == 1\'b0) begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_ucode_o.enable = 1\'b1;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("else if(flags_ucode_i.done) begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// else if(flags_engine_i.cnt == ctrl_i.len) begin // interface with Vivado HLS --> finished filtering input data?");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// if(flags_engine_i.cnt == ctrl_i.len) begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("next_state = FSM_TERMINATE;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("else if(");
    _builder.newLine();
    {
      Set<Port> _keySet_9 = this.inputMap.keySet();
      for(final Port input_4 : _keySet_9) {
        _builder.append("    \t\t          \t");
        _builder.append("flags_streamer_i.");
        String _name_34 = input_4.getName();
        _builder.append(_name_34, "    \t\t          \t");
        _builder.append("_source_flags.ready_start &");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_10 = this.outputMap.keySet();
      boolean _hasElements_1 = false;
      for(final Port output_4 : _keySet_10) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(" & ", "");
        }
        _builder.append("flags_streamer_i.");
        String _name_35 = output_4.getName();
        _builder.append(_name_35);
        _builder.append("_sink_flags.ready_start");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(")  begin");
    _builder.newLineIfNotEmpty();
    _builder.append("          ");
    _builder.append("next_state = FSM_COMPUTE;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.start  = 1\'b1;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.enable = 1\'b1;");
    _builder.newLine();
    {
      Set<Port> _keySet_11 = this.inputMap.keySet();
      for(final Port input_5 : _keySet_11) {
        _builder.append("          ");
        _builder.append("ctrl_streamer_o.");
        String _name_36 = input_5.getName();
        _builder.append(_name_36, "          ");
        _builder.append("_source_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_12 = this.outputMap.keySet();
      for(final Port output_5 : _keySet_12) {
        _builder.append("\t\t  ");
        _builder.append("ctrl_streamer_o.");
        String _name_37 = output_5.getName();
        _builder.append(_name_37, "\t\t  ");
        _builder.append("_sink_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("else begin");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("next_state = FSM_WAIT;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_WAIT: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// wait for the flags to be ok then go back to load");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_engine_o.enable = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_ucode_o.enable  = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(");
    _builder.newLine();
    {
      Set<Port> _keySet_13 = this.inputMap.keySet();
      for(final Port input_6 : _keySet_13) {
        _builder.append("flags_streamer_i.");
        String _name_38 = input_6.getName();
        _builder.append(_name_38);
        _builder.append("_source_flags.ready_start &");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_14 = this.outputMap.keySet();
      boolean _hasElements_2 = false;
      for(final Port output_6 : _keySet_14) {
        if (!_hasElements_2) {
          _hasElements_2 = true;
        } else {
          _builder.appendImmediate(" & ", "");
        }
        _builder.append("flags_streamer_i.");
        String _name_39 = output_6.getName();
        _builder.append(_name_39);
        _builder.append("_sink_flags.ready_start");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(")  begin");
    _builder.newLineIfNotEmpty();
    _builder.append("          ");
    _builder.append("next_state = FSM_COMPUTE;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.start = 1\'b1;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_engine_o.enable = 1\'b1;");
    _builder.newLine();
    {
      Set<Port> _keySet_15 = this.inputMap.keySet();
      for(final Port input_7 : _keySet_15) {
        _builder.append("  \t\t          ");
        _builder.append("ctrl_streamer_o.");
        String _name_40 = input_7.getName();
        _builder.append(_name_40, "  \t\t          ");
        _builder.append("_source_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_16 = this.outputMap.keySet();
      for(final Port output_7 : _keySet_16) {
        _builder.append("  \t\t\t\t  ");
        _builder.append("ctrl_streamer_o.");
        String _name_41 = output_7.getName();
        _builder.append(_name_41, "  \t\t\t\t  ");
        _builder.append("_sink_ctrl.req_start = 1\'b1;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("FSM_TERMINATE: begin");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("// wait for the flags to be ok then go back to idle");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_engine_o.clear  = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("ctrl_engine_o.enable = 1\'b0;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("if(");
    _builder.newLine();
    {
      Set<Port> _keySet_17 = this.inputMap.keySet();
      for(final Port input_8 : _keySet_17) {
        _builder.append("flags_streamer_i.");
        String _name_42 = input_8.getName();
        _builder.append(_name_42);
        _builder.append("_source_flags.ready_start &");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_18 = this.outputMap.keySet();
      boolean _hasElements_3 = false;
      for(final Port output_8 : _keySet_18) {
        if (!_hasElements_3) {
          _hasElements_3 = true;
        } else {
          _builder.appendImmediate(" & ", "");
        }
        _builder.append("flags_streamer_i.");
        String _name_43 = output_8.getName();
        _builder.append(_name_43);
        _builder.append("_sink_flags.ready_start");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(")  begin");
    _builder.newLineIfNotEmpty();
    _builder.append("          ");
    _builder.append("next_state = FSM_IDLE;");
    _builder.newLine();
    _builder.append("          ");
    _builder.append("ctrl_slave_o.done = 1\'b1;");
    _builder.newLine();
    _builder.append("        ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("endcase // curr_state");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("endmodule // multi_dataflow_fsm");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printBender(final String hclPath) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("hw-mac-engine:");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("incdirs : [");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("]");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("files : [");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_package.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_fsm.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_ctrl.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_streamer.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_engine.sv,");
    _builder.newLine();
    {
      File[] _listFiles = new File(hclPath).listFiles();
      for(final File file : _listFiles) {
        _builder.append("    ");
        _builder.append("rtl/");
        String _name = file.getName();
        _builder.append(_name, "    ");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      boolean _isEmpty = this.luts.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("\t");
        _builder.append("rtl/configurator.v\\");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("rtl/sbox1x2.v\\");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("rtl/sbox2x1.v\\");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("/rtl/multi_dataflow.v,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("/rtl/interface_wrapper.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("rtl/multi_dataflow_top.sv,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("wrap/multi_dataflow_top_wrap.sv");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("]");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("vlog_opts : [");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("\"-L hwpe_ctrl_lib\",");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("\"-L hwpe_stream_lib\"");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("]");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printPackage() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("/*");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("* Module: multi_dataflow_package.sv");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("*/");
    _builder.newLine();
    _builder.append(" ");
    _builder.newLine();
    _builder.append("import hwpe_stream_package::*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("package multi_dataflow_package;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned CNT_LEN = 1024; // maximum length of the vectors for a scalar product");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("/* Registers */");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// TCDM addresses");
    _builder.newLine();
    {
      Set<Port> _keySet = this.portMap.keySet();
      for(final Port port : _keySet) {
        _builder.append("  ");
        _builder.append("parameter int unsigned PORT_");
        String _name = port.getName();
        _builder.append(_name, "  ");
        _builder.append("_ADDR              = ");
        Integer _get = this.portMap.get(port);
        _builder.append(_get, "  ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Standard registers");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned REG_NB_ITER              = ");
    int _size = this.portMap.size();
    _builder.append(_size, "  ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter int unsigned REG_LEN_ITER             = ");
    int _size_1 = this.portMap.size();
    int _plus = (_size_1 + 1);
    _builder.append(_plus, "  ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter int unsigned REG_SHIFT_SIMPLEMUL      = ");
    int _size_2 = this.portMap.size();
    int _plus_1 = (_size_2 + 2);
    _builder.append(_plus_1, "  ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter int unsigned REG_SHIFT_VECTSTRIDE     = ");
    int _size_3 = this.portMap.size();
    int _plus_2 = (_size_3 + 3);
    _builder.append(_plus_2, "  ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter int unsigned REG_SHIFT_VECTSTRIDE2    = ");
    int _size_4 = this.portMap.size();
    int _plus_3 = (_size_4 + 4);
    _builder.append(_plus_3, "  ");
    _builder.append("; // Added to be aligned with sw (not used in hw)");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// Custom register files");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned CONFIG             = ");
    int _size_5 = this.portMap.size();
    int _plus_4 = (_size_5 + 5);
    _builder.append(_plus_4, "  ");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    {
      Set<Port> _keySet_1 = this.portMap.keySet();
      for(final Port port_1 : _keySet_1) {
        _builder.append("  ");
        _builder.append("parameter int unsigned PORT_");
        String _name_1 = port_1.getName();
        _builder.append(_name_1, "  ");
        _builder.append("             = ");
        Integer _get_1 = this.portMap.get(port_1);
        int _size_6 = this.portMap.size();
        int _plus_5 = ((_get_1).intValue() + _size_6);
        int _plus_6 = (_plus_5 + 6);
        _builder.append(_plus_6, "  ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// microcode offset indeces -- this should be aligned to the microcode compiler of course!");
    _builder.newLine();
    {
      Set<Port> _keySet_2 = this.portMap.keySet();
      for(final Port port_2 : _keySet_2) {
        _builder.append("  ");
        _builder.append("parameter int unsigned PORT_");
        String _name_2 = port_2.getName();
        _builder.append(_name_2, "  ");
        _builder.append("_UCODE_OFFS              = ");
        Integer _get_2 = this.portMap.get(port_2);
        _builder.append(_get_2, "  ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// microcode mnemonics -- this should be aligned to the microcode compiler of course!");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned UCODE_MNEM_NBITER     = 4 - 4;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned UCODE_MNEM_ITERSTRIDE = 5 - 4;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned UCODE_MNEM_ONESTRIDE  = 6 - 4;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef struct packed {");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic clear;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic enable;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic simple_mul;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic start;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [$clog2(32)-1       :0] shift;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [$clog2(CNT_LEN):0] len; // 1 bit more as cnt starts from 1, not 0");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// Custom register files");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [(32-1):0] configuration;");
    _builder.newLine();
    {
      Set<Port> _keySet_3 = this.portMap.keySet();
      for(final Port port_3 : _keySet_3) {
        _builder.append("    ");
        _builder.append("logic unsigned [(32-1):0] port_");
        String _name_3 = port_3.getName();
        _builder.append(_name_3, "    ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("} ctrl_engine_t;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef struct packed {");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [$clog2(CNT_LEN):0] cnt; // 1 bit more as cnt starts from 1, not 0");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic done;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic idle;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic ready;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("} flags_engine_t;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef struct packed {");
    _builder.newLine();
    {
      Set<Port> _keySet_4 = this.inputMap.keySet();
      for(final Port input : _keySet_4) {
        _builder.append("  \t");
        _builder.append("hwpe_stream_package::ctrl_sourcesink_t ");
        String _name_4 = input.getName();
        _builder.append(_name_4, "  \t");
        _builder.append("_source_ctrl;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_5 = this.outputMap.keySet();
      for(final Port output : _keySet_5) {
        _builder.append("    ");
        _builder.append("hwpe_stream_package::ctrl_sourcesink_t ");
        String _name_5 = output.getName();
        _builder.append(_name_5, "    ");
        _builder.append("_sink_ctrl;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("} ctrl_streamer_t;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef struct packed {");
    _builder.newLine();
    {
      Set<Port> _keySet_6 = this.inputMap.keySet();
      for(final Port input_1 : _keySet_6) {
        _builder.append("  \t");
        _builder.append("hwpe_stream_package::flags_sourcesink_t ");
        String _name_6 = input_1.getName();
        _builder.append(_name_6, "  \t");
        _builder.append("_source_flags;");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_7 = this.outputMap.keySet();
      for(final Port output_1 : _keySet_7) {
        _builder.append("    ");
        _builder.append("hwpe_stream_package::flags_sourcesink_t ");
        String _name_7 = output_1.getName();
        _builder.append(_name_7, "    ");
        _builder.append("_sink_flags;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("} flags_streamer_t;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef struct packed {");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic simple_mul;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [$clog2(32)-1       :0] shift;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [$clog2(CNT_LEN):0] len; // 1 bit more as cnt starts from 1, not 0");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("// Custom register files");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("logic unsigned [(32-1):0] configuration;");
    _builder.newLine();
    {
      Set<Port> _keySet_8 = this.portMap.keySet();
      for(final Port port_4 : _keySet_8) {
        _builder.append("    ");
        _builder.append("logic unsigned [(32-1):0] port_");
        String _name_8 = port_4.getName();
        _builder.append(_name_8, "    ");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("  ");
    _builder.append("} ctrl_fsm_t;");
    _builder.newLine();
    _builder.append("  ");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("typedef enum {");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_IDLE,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_START,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_COMPUTE,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_WAIT,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_UPDATEIDX,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("FSM_TERMINATE");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("} state_fsm_t;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("endpackage");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printStreamer() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("/*");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("* multi_dataflow_streamer.sv");
    _builder.newLine();
    _builder.append(" ");
    _builder.append("*/");
    _builder.newLine();
    _builder.newLine();
    _builder.append("import multi_dataflow_package::*;");
    _builder.newLine();
    _builder.append("import hwpe_stream_package::*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("module multi_dataflow_streamer");
    _builder.newLine();
    _builder.append("#(");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter int unsigned MP = ");
    int _size = this.portMap.size();
    _builder.append(_size, "  ");
    _builder.append(", // number of master ports");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter int unsigned FD = 2  // FIFO depth");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    _builder.append("(");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// global signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                   clk_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                   rst_ni,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                   test_mode_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// local enable & clear");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                   enable_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                   clear_i,");
    _builder.newLine();
    _builder.newLine();
    {
      Set<Port> _keySet = this.inputMap.keySet();
      for(final Port input : _keySet) {
        _builder.append("\t    ");
        _builder.append("// input ");
        String _name = input.getName();
        _builder.append(_name, "\t    ");
        _builder.append(" stream + handshake");
        _builder.newLineIfNotEmpty();
        _builder.append("\t    ");
        _builder.append("hwpe_stream_intf_stream.source stream_if_");
        String _name_1 = input.getName();
        _builder.append(_name_1, "\t    ");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      Set<Port> _keySet_1 = this.outputMap.keySet();
      for(final Port output : _keySet_1) {
        _builder.append("\t    ");
        _builder.append("// output ");
        String _name_2 = output.getName();
        _builder.append(_name_2, "\t    ");
        _builder.append(" stream + handshake");
        _builder.newLineIfNotEmpty();
        _builder.append("\t    ");
        _builder.append("hwpe_stream_intf_stream.sink stream_if_");
        String _name_3 = output.getName();
        _builder.append(_name_3, "\t    ");
        _builder.append(",");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// TCDM ports");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_stream_intf_tcdm.master tcdm [MP-1:0],");
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// control channel");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  ctrl_streamer_t  ctrl_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output flags_streamer_t flags_o");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("logic ");
    {
      Set<Port> _keySet_2 = this.inputMap.keySet();
      boolean _hasElements = false;
      for(final Port input_1 : _keySet_2) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(", ", "");
        }
        String _name_4 = input_1.getName();
        _builder.append(_name_4);
        _builder.append("_tcdm_fifo_ready");
      }
    }
    _builder.append(";\t\t");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      Set<Port> _keySet_3 = this.portMap.keySet();
      for(final Port input_2 : _keySet_3) {
        _builder.append("hwpe_stream_intf_stream #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".DATA_WIDTH ( 32 )");
        _builder.newLine();
        _builder.append(") ");
        String _name_5 = input_2.getName();
        _builder.append(_name_5);
        _builder.append("_prefifo (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk ( clk_i )");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    {
      Set<Port> _keySet_4 = this.portMap.keySet();
      for(final Port output_1 : _keySet_4) {
        _builder.append("hwpe_stream_intf_stream #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".DATA_WIDTH ( 32 )");
        _builder.newLine();
        _builder.append(") ");
        String _name_6 = output_1.getName();
        _builder.append(_name_6);
        _builder.append("_postfifo (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk ( clk_i )");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_stream_intf_tcdm tcdm_fifo [MP-1:0] (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk ( clk_i )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    {
      Set<Port> _keySet_5 = this.portMap.keySet();
      for(final Port port : _keySet_5) {
        _builder.append("  \t\t");
        _builder.append("hwpe_stream_intf_tcdm tcdm_fifo_");
        Integer _get = this.portMap.get(port);
        _builder.append(_get, "  \t\t");
        _builder.append(" [0:0] (");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t    ");
        _builder.append(".clk ( clk_i )");
        _builder.newLine();
        _builder.append("\t\t  ");
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// source and sink modules");
    _builder.newLine();
    {
      Set<Port> _keySet_6 = this.inputMap.keySet();
      for(final Port input_3 : _keySet_6) {
        _builder.append("  ");
        _builder.append("hwpe_stream_source #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".DATA_WIDTH ( 32 ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".DECOUPLED  ( 1  )");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(") i_");
        String _name_7 = input_3.getName();
        _builder.append(_name_7, "  ");
        _builder.append("_source (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".clk_i              ( clk_i                  ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".rst_ni             ( rst_ni                 ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".test_mode_i        ( test_mode_i            ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".clear_i            ( clear_i                ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".tcdm               ( tcdm_fifo_");
        Integer _get_1 = this.portMap.get(input_3);
        _builder.append(_get_1, "    ");
        _builder.append("), // this syntax is necessary for Verilator as hwpe_stream_source expects an array of interfaces");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".stream             ( ");
        String _name_8 = input_3.getName();
        _builder.append(_name_8, "    ");
        _builder.append("_prefifo.source),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".ctrl_i             ( ctrl_i.");
        String _name_9 = input_3.getName();
        _builder.append(_name_9, "    ");
        _builder.append("_source_ctrl   ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".flags_o            ( flags_o.");
        String _name_10 = input_3.getName();
        _builder.append(_name_10, "    ");
        _builder.append("_source_flags ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".tcdm_fifo_ready_o  ( ");
        String _name_11 = input_3.getName();
        _builder.append(_name_11, "    ");
        _builder.append("_tcdm_fifo_ready      )");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(");");
        _builder.newLine();
        _builder.append("  ");
        _builder.newLine();
      }
    }
    {
      Set<Port> _keySet_7 = this.outputMap.keySet();
      for(final Port output_2 : _keySet_7) {
        _builder.append("  ");
        _builder.append("hwpe_stream_sink #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".DATA_WIDTH ( 32 )");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(") i_");
        String _name_12 = output_2.getName();
        _builder.append(_name_12, "  ");
        _builder.append("_sink (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".clk_i       ( clk_i                ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".rst_ni      ( rst_ni               ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".test_mode_i ( test_mode_i          ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".clear_i     ( clear_i              ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".tcdm        ( tcdm_fifo_");
        Integer _get_2 = this.portMap.get(output_2);
        _builder.append(_get_2, "    ");
        _builder.append("), // this syntax is necessary for Verilator as hwpe_stream_source expects an array of interfaces");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".stream      ( ");
        String _name_13 = output_2.getName();
        _builder.append(_name_13, "    ");
        _builder.append("_postfifo.sink      ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".ctrl_i      ( ctrl_i.");
        String _name_14 = output_2.getName();
        _builder.append(_name_14, "    ");
        _builder.append("_sink_ctrl   ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append("  ");
        _builder.append(".flags_o     ( flags_o.");
        String _name_15 = output_2.getName();
        _builder.append(_name_15, "    ");
        _builder.append("_sink_flags )");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(");");
        _builder.newLine();
        _builder.append("  ");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// TCDM-side FIFOs");
    _builder.newLine();
    {
      Set<Port> _keySet_8 = this.inputMap.keySet();
      for(final Port input_4 : _keySet_8) {
        _builder.append("hwpe_stream_tcdm_fifo_load #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".FIFO_DEPTH ( 4 )");
        _builder.newLine();
        _builder.append(") i_");
        String _name_16 = input_4.getName();
        _builder.append(_name_16);
        _builder.append("_tcdm_fifo_load (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk_i       ( clk_i             ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".rst_ni      ( rst_ni            ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".clear_i     ( clear_i           ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".flags_o     (                   ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".ready_i     ( ");
        String _name_17 = input_4.getName();
        _builder.append(_name_17, "  ");
        _builder.append("_tcdm_fifo_ready ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".tcdm_slave  ( tcdm_fifo_");
        Integer _get_3 = this.portMap.get(input_4);
        _builder.append(_get_3, "  ");
        _builder.append("[0]    ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".tcdm_master ( tcdm      [");
        Integer _get_4 = this.portMap.get(input_4);
        _builder.append(_get_4, "  ");
        _builder.append("]     )");
        _builder.newLineIfNotEmpty();
        _builder.append(");");
        _builder.newLine();
        _builder.newLine();
      }
    }
    _builder.newLine();
    {
      Set<Port> _keySet_9 = this.outputMap.keySet();
      for(final Port output_3 : _keySet_9) {
        _builder.append("hwpe_stream_tcdm_fifo_store #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".FIFO_DEPTH ( 4 )");
        _builder.newLine();
        _builder.append(") i_");
        String _name_18 = output_3.getName();
        _builder.append(_name_18);
        _builder.append("_tcdm_fifo_store (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk_i       ( clk_i          ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".rst_ni      ( rst_ni         ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".clear_i     ( clear_i        ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".flags_o     (                ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".tcdm_slave  ( tcdm_fifo_");
        Integer _get_5 = this.portMap.get(output_3);
        _builder.append(_get_5, "  ");
        _builder.append("[0] ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".tcdm_master ( tcdm       [");
        Integer _get_6 = this.portMap.get(output_3);
        _builder.append(_get_6, "  ");
        _builder.append("] )");
        _builder.newLineIfNotEmpty();
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// datapath-side FIFOs");
    _builder.newLine();
    {
      Set<Port> _keySet_10 = this.inputMap.keySet();
      for(final Port input_5 : _keySet_10) {
        _builder.append("hwpe_stream_fifo #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".DATA_WIDTH( 32 ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".FIFO_DEPTH( 2  ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".LATCH_FIFO( 0  )");
        _builder.newLine();
        _builder.append(") i_");
        String _name_19 = input_5.getName();
        _builder.append(_name_19);
        _builder.append("_fifo (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk_i   ( clk_i          ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".rst_ni  ( rst_ni         ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".clear_i ( clear_i        ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".push_i  ( ");
        String _name_20 = input_5.getName();
        _builder.append(_name_20, "  ");
        _builder.append("_prefifo.sink ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".pop_o   ( stream_if_");
        String _name_21 = input_5.getName();
        _builder.append(_name_21, "  ");
        _builder.append("            ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".flags_o (                )");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
        _builder.newLine();
      }
    }
    _builder.newLine();
    {
      Set<Port> _keySet_11 = this.outputMap.keySet();
      for(final Port output_4 : _keySet_11) {
        _builder.append("hwpe_stream_fifo #(");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".DATA_WIDTH( 32 ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".FIFO_DEPTH( 2  ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".LATCH_FIFO( 0  )");
        _builder.newLine();
        _builder.append(") i_");
        String _name_22 = output_4.getName();
        _builder.append(_name_22);
        _builder.append("_fifo (");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".clk_i   ( clk_i             ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".rst_ni  ( rst_ni            ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".clear_i ( clear_i           ),");
        _builder.newLine();
        _builder.append("  ");
        _builder.append(".push_i  ( stream_if_");
        String _name_23 = output_4.getName();
        _builder.append(_name_23, "  ");
        _builder.append("               ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".pop_o   ( ");
        String _name_24 = output_4.getName();
        _builder.append(_name_24, "  ");
        _builder.append("_postfifo.source ),");
        _builder.newLineIfNotEmpty();
        _builder.append("  ");
        _builder.append(".flags_o (                   )");
        _builder.newLine();
        _builder.append(");");
        _builder.newLine();
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("endmodule // multi_dataflow_streamer");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printMk(final String hclPath) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("IP=hwpe_multi_dataflow");
    _builder.newLine();
    _builder.append("IP_PATH=$(IPS_PATH)/hwpe-multi-dataflow");
    _builder.newLine();
    _builder.append("LIB_NAME=$(IP)_lib");
    _builder.newLine();
    _builder.newLine();
    _builder.append("include vcompile/build.mk");
    _builder.newLine();
    _builder.newLine();
    _builder.append(".PHONY: vcompile-$(IP) vcompile-subip-hw-multi-dataflow ");
    _builder.newLine();
    _builder.newLine();
    _builder.append("vcompile-$(IP): $(LIB_PATH)/_vmake");
    _builder.newLine();
    _builder.newLine();
    _builder.append("$(LIB_PATH)/_vmake : $(LIB_PATH)/hw-multi-dataflow.vmake ");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@touch $(LIB_PATH)/_vmake");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("# hw-multi-dataflow component");
    _builder.newLine();
    _builder.append("INCDIR_HW-MULTI-DATAFLOW=+incdir+$(IP_PATH)/rtl");
    _builder.newLine();
    _builder.append("SRC_SVLOG_HW-MULTI-DATAFLOW=\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow_package.sv\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow_fsm.sv\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow_ctrl.sv\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow_streamer.sv\\");
    _builder.newLine();
    {
      File[] _listFiles = new File(hclPath).listFiles();
      for(final File file : _listFiles) {
        _builder.append("\t");
        _builder.append("$(IP_PATH)/rtl/");
        String _name = file.getName();
        _builder.append(_name, "\t");
        _builder.append("\\");
        _builder.newLineIfNotEmpty();
      }
    }
    {
      boolean _isEmpty = this.luts.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("\t");
        _builder.append("$(IP_PATH)/rtl/configurator.v\\");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("$(IP_PATH)/rtl/sbox1x2.v\\");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("$(IP_PATH)/rtl/sbox2x1.v\\");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow.v\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/interface_wrapper.sv\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/rtl/multi_dataflow_top.sv\\");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(IP_PATH)/wrap/multi_dataflow_top_wrap.sv");
    _builder.newLine();
    _builder.append("SRC_VHDL_HW-MULTI-DATAFLOW=");
    _builder.newLine();
    _builder.newLine();
    _builder.append("vcompile-subip-hw-multi-dataflow: $(LIB_PATH)/hw-multi-dataflow.vmake");
    _builder.newLine();
    _builder.newLine();
    _builder.append("$(LIB_PATH)/hw-multi-dataflow.vmake: $(SRC_SVLOG_HW-MULTI-DATAFLOW) $(SRC_VHDL_HW-MULTI-DATAFLOW)");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(call subip_echo,hw-multi-dataflow)");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("$(SVLOG_CC) -work $(LIB_PATH) +define+HWPE_ASSERT_SEVERITY=\"\\$$fatal\" -L hwpe_ctrl_lib -L hwpe_stream_lib -suppress 2583 -suppress 13314 $(INCDIR_HW-MULTI-DATAFLOW) $(SRC_SVLOG_HW-MULTI-DATAFLOW)");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("@touch $(LIB_PATH)/hw-multi-dataflow.vmake");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printWrap() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("import multi_dataflow_package::*;");
    _builder.newLine();
    _builder.append("import hwpe_ctrl_package::*;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("module multi_dataflow_top_wrap");
    _builder.newLine();
    _builder.append("#(");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter N_CORES = 2,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("parameter MP  = ");
    int _size = this.portMap.size();
    _builder.append(_size, "  ");
    _builder.append(",");
    _builder.newLineIfNotEmpty();
    _builder.append("  ");
    _builder.append("parameter ID  = 10");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    _builder.append("(");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// global signals");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  clk_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  rst_ni,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  test_mode_i,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// evnets");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [N_CORES-1:0][REGFILE_N_EVT-1:0] evt_o,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// tcdm master ports");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [MP-1:0]                         tcdm_req,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic [MP-1:0]                         tcdm_gnt,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [MP-1:0][31:0]                   tcdm_add,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [MP-1:0]                         tcdm_wen,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [MP-1:0][3:0]                    tcdm_be,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic [MP-1:0][31:0]                   tcdm_data,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic [MP-1:0][31:0]                   tcdm_r_data,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic [MP-1:0]                         tcdm_r_valid,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// periph slave port");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  periph_req,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic                                  periph_gnt,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic         [31:0]                   periph_add,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic                                  periph_wen,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic         [3:0]                    periph_be,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic         [31:0]                   periph_data,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("input  logic       [ID-1:0]                   periph_id,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic         [31:0]                   periph_r_data,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic                                  periph_r_valid,");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("output logic       [ID-1:0]                   periph_r_id");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_stream_intf_tcdm tcdm[MP-1:0] (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk ( clk_i )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("hwpe_ctrl_intf_periph #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ID_WIDTH ( ID )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(") periph (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk ( clk_i )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("// bindings");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("generate");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("for(genvar ii=0; ii<MP; ii++) begin: tcdm_binding");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm_req  [ii] = tcdm[ii].req;");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm_add  [ii] = tcdm[ii].add;");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm_wen  [ii] = tcdm[ii].wen;");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm_be   [ii] = tcdm[ii].be;");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm_data [ii] = tcdm[ii].data;");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm[ii].gnt     = tcdm_gnt     [ii];");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm[ii].r_data  = tcdm_r_data  [ii];");
    _builder.newLine();
    _builder.append("      ");
    _builder.append("assign tcdm[ii].r_valid = tcdm_r_valid [ii];");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("end");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("endgenerate");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("always_comb");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("begin");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.req  = periph_req;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.add  = periph_add;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.wen  = periph_wen;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.be   = periph_be;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.data = periph_data;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph.id   = periph_id;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph_gnt     = periph.gnt;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph_r_data  = periph.r_data;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph_r_valid = periph.r_valid;");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("periph_r_id    = periph.r_id;");
    _builder.newLine();
    _builder.append("  ");
    _builder.append("end");
    _builder.newLine();
    _builder.newLine();
    _builder.append("  ");
    _builder.append("multi_dataflow_top #(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".N_CORES ( N_CORES ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".MP      ( MP      ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".ID      ( ID      )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(") i_multi_dataflow_top (");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".clk_i       ( clk_i       ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".rst_ni      ( rst_ni      ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".test_mode_i ( test_mode_i ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".evt_o       ( evt_o       ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".tcdm        ( tcdm        ),");
    _builder.newLine();
    _builder.append("    ");
    _builder.append(".periph      ( periph      )");
    _builder.newLine();
    _builder.append("  ");
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.append("endmodule // multi_dataflow_top_wrap");
    _builder.newLine();
    return _builder;
  }
}
