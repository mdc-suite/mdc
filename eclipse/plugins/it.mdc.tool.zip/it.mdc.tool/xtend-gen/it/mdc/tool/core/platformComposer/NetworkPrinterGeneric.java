package it.mdc.tool.core.platformComposer;

import com.google.common.base.Objects;
import com.google.common.collect.Iterables;
import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Actor;
import net.sf.orcc.df.Connection;
import net.sf.orcc.df.Entity;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import net.sf.orcc.graph.Edge;
import net.sf.orcc.graph.Vertex;
import net.sf.orcc.ir.Expression;
import net.sf.orcc.ir.Var;
import net.sf.orcc.ir.util.ExpressionEvaluator;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.IntegerRange;

/**
 * A Verilog FIFO-based Generic Protocol Network printer
 * 
 * printNetwork() is in charge of printing the top module.
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class NetworkPrinterGeneric {
  private ExpressionEvaluator evaluator;
  
  private Network network;
  
  /**
   * Map which contains the Clock Domain of a port
   */
  private Map<Port, String> portClockDomain;
  
  /**
   * Map which contains the Clock Domain of an instance
   */
  private Map<Actor, String> instanceClockDomain;
  
  /**
   * Contains a Map which indicates the number of the broadcasted actor
   */
  private Map<Connection, Integer> networkPortConnectionFanout;
  
  /**
   * Contains a Map which indicates the number of a Network Port broadcasted
   */
  private Map<Port, Integer> networkPortFanout;
  
  /**
   * Contains a Map which indicates the index of the given clock
   */
  private Map<String, Integer> clockDomainsIndex;
  
  private ProtocolManager protocolManager;
  
  private Boolean lastParm = Boolean.valueOf(false);
  
  private Boolean enableClockGating;
  
  private Boolean enablePowerGating;
  
  private Map<String, Object> options;
  
  private Map<String, Set<String>> logicRegions;
  
  private Map<String, Set<String>> netRegions;
  
  private Set<String> powerSets;
  
  private Map<String, Integer> powerSetsIndex;
  
  private Map<String, Boolean> logicRegionsSeqMap;
  
  private Map<Connection, List<Integer>> connectionsClockDomain;
  
  private String DEFAULT_CLOCK_DOMAIN = "CLK";
  
  /**
   * Count the fanout of the actor's output port
   * 
   * @param network
   */
  private String clockSignal;
  
  private int idParm = 0;
  
  public void computeActorOutputPortFanout(final Network network) {
    EList<Vertex> _vertices = network.getVertices();
    for (final Vertex vertex : _vertices) {
      if ((vertex instanceof Actor)) {
        Actor actor = ((Actor) vertex);
        Map<Port, List<Connection>> map = actor.<Entity>getAdapter(Entity.class).getOutgoingPortMap();
        Collection<List<Connection>> _values = map.values();
        for (final List<Connection> values : _values) {
          {
            int cp = 0;
            for (final Connection connection : values) {
              {
                this.networkPortConnectionFanout.put(connection, Integer.valueOf(cp));
                cp = (cp + 1);
              }
            }
          }
        }
      }
    }
  }
  
  /**
   * def computeCombPorts(List<Port> ports) {
   * var combInputs = new ArrayList<Port>();
   * for(Port input : ports) {
   * if(input.isNative()) {
   * combInputs.add(input);
   * }
   * }
   * return combInputs;
   * }
   */
  public void computeNetworkInputPortFanout(final Network network) {
    EList<Port> _inputs = network.getInputs();
    for (final Port port : _inputs) {
      {
        int cp = 0;
        EList<Connection> _connections = network.getConnections();
        for (final Connection connection : _connections) {
          Vertex _source = connection.getSource();
          boolean _equals = Objects.equal(_source, port);
          if (_equals) {
            this.networkPortFanout.put(port, Integer.valueOf((cp + 1)));
            this.networkPortConnectionFanout.put(connection, Integer.valueOf(cp));
            cp = (cp + 1);
          }
        }
      }
    }
  }
  
  /**
   * Create the map which indicates the index of each clock
   */
  public void computeNetworkClockDomains(final Network network, final Map<String, Set<String>> clockSets) {
    EList<Port> _inputs = network.getInputs();
    for (final Port port : _inputs) {
      this.portClockDomain.put(port, this.DEFAULT_CLOCK_DOMAIN);
    }
    EList<Port> _outputs = network.getOutputs();
    for (final Port port_1 : _outputs) {
      this.portClockDomain.put(port_1, this.DEFAULT_CLOCK_DOMAIN);
    }
    int clkIndex = 0;
    this.clockDomainsIndex.put(this.DEFAULT_CLOCK_DOMAIN, Integer.valueOf(clkIndex));
    clkIndex = (clkIndex + 1);
    Set<String> _keySet = clockSets.keySet();
    for (final String clkId : _keySet) {
      {
        this.clockDomainsIndex.put(clkId.toString(), Integer.valueOf(clkIndex));
        clkIndex = (clkIndex + 1);
      }
    }
    EList<Vertex> _vertices = network.getVertices();
    for (final Vertex vertex : _vertices) {
      if ((vertex instanceof Actor)) {
        Actor actor = ((Actor) vertex);
        boolean _isEmpty = clockSets.isEmpty();
        boolean _not = (!_isEmpty);
        if (_not) {
          Set<String> _keySet_1 = clockSets.keySet();
          for (final String clkId_1 : _keySet_1) {
            Set<String> _get = clockSets.get(clkId_1);
            for (final String instance : _get) {
              boolean _equals = instance.equals(actor.getName());
              if (_equals) {
                String domain = clkId_1.toString();
                this.instanceClockDomain.put(actor, domain);
              } else {
                boolean _containsKey = this.instanceClockDomain.containsKey(actor);
                boolean _not_1 = (!_containsKey);
                if (_not_1) {
                  this.instanceClockDomain.put(actor, this.DEFAULT_CLOCK_DOMAIN);
                }
              }
            }
          }
        } else {
          this.instanceClockDomain.put(actor, this.DEFAULT_CLOCK_DOMAIN);
        }
      }
    }
  }
  
  /**
   * Return the simple name of an actor.
   */
  public String getActorName(final Actor actor) {
    String[] splitName = actor.getName().split("_");
    String result = "";
    result = splitName[0];
    final String[] _converted_splitName = (String[])splitName;
    int _size = ((List<String>)Conversions.doWrapArray(_converted_splitName)).size();
    boolean _greaterThan = (_size > 2);
    if (_greaterThan) {
      final String[] _converted_splitName_1 = (String[])splitName;
      int _size_1 = ((List<String>)Conversions.doWrapArray(_converted_splitName_1)).size();
      int _minus = (_size_1 - 2);
      IntegerRange _upTo = new IntegerRange(1, _minus);
      for (final int i : _upTo) {
        String _get = splitName[i];
        String _plus = ((result + "_") + _get);
        result = _plus;
      }
    }
    return result;
  }
  
  /**
   * Return the list of actor static (design time) parameters
   */
  public List<Var> getActorStaticParms(final Actor actor) {
    List<Var> result = new ArrayList<Var>();
    EList<Var> _parameters = actor.getParameters();
    for (final Var actVar : _parameters) {
      Var _matchingVariable = this.getMatchingVariable(actVar);
      boolean _tripleNotEquals = (_matchingVariable != null);
      if (_tripleNotEquals) {
        result.add(actVar);
      }
    }
    EList<Var> _parameters_1 = actor.getParameters();
    for (final Var actVar_1 : _parameters_1) {
      if (((this.getMatchingVariable(actVar_1) == null) && (this.getMatchingParameter(actVar_1) == null))) {
        result.add(actVar_1);
      }
    }
    return result;
  }
  
  /**
   * Return the list of actor dynamic (run time) parameters
   */
  public List<Var> getActorDynamicParms(final Actor actor) {
    List<Var> result = new ArrayList<Var>();
    EList<Var> _parameters = actor.getParameters();
    for (final Var actVar : _parameters) {
      Var _matchingParameter = this.getMatchingParameter(actVar);
      boolean _tripleNotEquals = (_matchingParameter != null);
      if (_tripleNotEquals) {
        result.add(actVar);
      }
    }
    return result;
  }
  
  /**
   * Return the buffer (FIFO) size as integer
   */
  public Integer getBufferSizeIntegerValue(final Connection connection) {
    int _xifexpression = (int) 0;
    boolean _hasAttribute = connection.hasAttribute("bufferSize");
    if (_hasAttribute) {
      int _xifexpression_1 = (int) 0;
      EObject _containedValue = connection.getAttribute("bufferSize").getContainedValue();
      boolean _tripleNotEquals = (_containedValue != null);
      if (_tripleNotEquals) {
        EObject _containedValue_1 = connection.getAttribute("bufferSize").getContainedValue();
        _xifexpression_1 = this.evaluator.evaluateAsInteger(((Expression) _containedValue_1));
      } else {
        EObject _referencedValue = connection.getAttribute("bufferSize").getReferencedValue();
        boolean _tripleNotEquals_1 = (_referencedValue != null);
        if (_tripleNotEquals_1) {
          EObject _referencedValue_1 = connection.getAttribute("bufferSize").getReferencedValue();
          return Integer.valueOf(this.evaluator.evaluateAsInteger(((Expression) _referencedValue_1)));
        } else {
          Object _objectValue = connection.getAttribute("bufferSize").getObjectValue();
          return Integer.valueOf(this.evaluator.evaluateAsInteger(((Expression) _objectValue)));
        }
      }
      _xifexpression = _xifexpression_1;
    } else {
      return null;
    }
    return Integer.valueOf(_xifexpression);
  }
  
  /**
   * Return the Map which indicates the index of the given clock
   */
  public Map<String, Integer> getClockDomainIndex() {
    return this.clockDomainsIndex;
  }
  
  /**
   * Return network parameter matching with the passed variable
   */
  public Var getMatchingParameter(final Var actVar) {
    EList<Var> _parameters = this.network.getParameters();
    for (final Var netVar : _parameters) {
      boolean _equals = actVar.getName().equals(netVar.getName());
      if (_equals) {
        return netVar;
      }
    }
    return null;
  }
  
  /**
   * Return network variable matching with the passed variable
   */
  public Var getMatchingVariable(final Var actVar) {
    EList<Var> _variables = this.network.getVariables();
    for (final Var netVar : _variables) {
      boolean _equals = actVar.getName().equals(netVar.getName());
      if (_equals) {
        return netVar;
      }
    }
    return null;
  }
  
  /**
   * Return the value of the parameter with the given ID for the given module, actor and port
   */
  public String getParameterValue(final String module, final Actor actor, final Port port, final String commParId) {
    String _xifexpression = null;
    boolean _equals = this.protocolManager.getModCommParms().get(module).get(commParId).get(ProtocolManager.VAL).equals("variable");
    if (_equals) {
      _xifexpression = Integer.valueOf(port.getType().getSizeInBits()).toString();
    } else {
      String _xifexpression_1 = null;
      boolean _equals_1 = this.protocolManager.getModCommParms().get(module).get(commParId).get(ProtocolManager.VAL).equals("bufferSize");
      if (_equals_1) {
        String _xifexpression_2 = null;
        boolean _containsKey = actor.getIncomingPortMap().containsKey(port);
        if (_containsKey) {
          String _xifexpression_3 = null;
          boolean _hasAttribute = actor.getIncomingPortMap().get(port).hasAttribute("bufferSize");
          if (_hasAttribute) {
            _xifexpression_3 = this.getBufferSizeIntegerValue(actor.getIncomingPortMap().get(port)).toString();
          } else {
            _xifexpression_3 = "64";
          }
          _xifexpression_2 = _xifexpression_3;
        } else {
          String _xifexpression_4 = null;
          boolean _containsKey_1 = actor.getOutgoingPortMap().containsKey(port);
          if (_containsKey_1) {
            String _xifexpression_5 = null;
            boolean _hasAttribute_1 = actor.getOutgoingPortMap().get(port).get(0).hasAttribute("bufferSize");
            if (_hasAttribute_1) {
              _xifexpression_5 = this.getBufferSizeIntegerValue(actor.getOutgoingPortMap().get(port).get(0)).toString();
            } else {
              _xifexpression_5 = "64";
            }
            _xifexpression_4 = _xifexpression_5;
          }
          _xifexpression_2 = _xifexpression_4;
        }
        _xifexpression_1 = _xifexpression_2;
      } else {
        String _xifexpression_6 = null;
        boolean _equals_2 = this.protocolManager.getModCommParms().get(module).get(commParId).get(ProtocolManager.VAL).equals("broadcast");
        if (_equals_2) {
          String _xifexpression_7 = null;
          boolean _hasAttribute_2 = actor.getOutgoingPortMap().get(port).get(0).hasAttribute("broadcast");
          if (_hasAttribute_2) {
            _xifexpression_7 = Integer.valueOf(actor.getOutgoingPortMap().get(port).size()).toString();
          } else {
            _xifexpression_7 = "1";
          }
          _xifexpression_6 = _xifexpression_7;
        } else {
          _xifexpression_6 = this.protocolManager.getModCommParms().get(module).get(commParId).get(ProtocolManager.VAL);
        }
        _xifexpression_1 = _xifexpression_6;
      }
      _xifexpression = _xifexpression_1;
    }
    return _xifexpression;
  }
  
  /**
   * Return the simple name of a SBox
   */
  public String getSboxActorName(final Actor actor) {
    String result = null;
    boolean _equals = actor.getAttribute("type").getStringValue().equals("1x2");
    if (_equals) {
      result = "sbox1x2";
    } else {
      result = "sbox2x1";
    }
    return result;
  }
  
  /**
   * Return the selector ID for the given SBox
   */
  public String getSboxSelID(final Actor actor) {
    return actor.getSimpleName().split("_")[1];
  }
  
  /**
   * Return the SBox size
   */
  public String getSboxSize(final Actor actor) {
    return String.valueOf(actor.getInputs().get(0).getType().getSizeInBits());
  }
  
  /**
   * Return the SBox type (1x2 or 2x1)
   */
  public String getSboxType(final Actor actor) {
    return actor.getAttribute("type").getStringValue();
  }
  
  public String getSourceSignal(final Connection connection, final String succ, final String targetChannel) {
    String _xblockexpression = null;
    {
      String prefix = "";
      String suffix = "";
      Vertex _source = connection.getSource();
      if ((_source instanceof Actor)) {
        Vertex _source_1 = connection.getSource();
        boolean _hasAttribute = ((Actor) _source_1).hasAttribute("sbox");
        boolean _not = (!_hasAttribute);
        if (_not) {
          String _modName = this.protocolManager.getModName(succ);
          boolean _notEquals = (!Objects.equal(_modName, ""));
          if (_notEquals) {
            prefix = this.protocolManager.getModName(succ);
          }
        }
      }
      boolean _hasAttribute_1 = connection.hasAttribute("broadcast");
      if (_hasAttribute_1) {
        Set<String> _keySet = this.protocolManager.getModCommSignals().get(succ).keySet();
        for (final String commSigId : _keySet) {
          boolean _equals = this.protocolManager.getModCommSignals().get(succ).get(commSigId).get(ProtocolManager.CH).equals(targetChannel);
          if (_equals) {
            boolean _equals_1 = this.protocolManager.getModCommSignals().get(succ).get(commSigId).get(ProtocolManager.SIZE).equals("broadcast");
            if (_equals_1) {
              Port _sourcePort = connection.getSourcePort();
              boolean _tripleEquals = (_sourcePort == null);
              if (_tripleEquals) {
                Vertex _source_2 = connection.getSource();
                int _indexOf = ((Port) _source_2).getOutgoing().indexOf(connection);
                String _plus = ("[" + Integer.valueOf(_indexOf));
                String _plus_1 = (_plus + "]");
                suffix = _plus_1;
              } else {
                Vertex _source_3 = connection.getSource();
                int _indexOf_1 = ((Actor) _source_3).getOutgoingPortMap().get(connection.getSourcePort()).indexOf(connection);
                String _plus_2 = ("[" + Integer.valueOf(_indexOf_1));
                String _plus_3 = (_plus_2 + "]");
                suffix = _plus_3;
              }
            }
          }
        }
      }
      String _xifexpression = null;
      Port _sourcePort_1 = connection.getSourcePort();
      boolean _tripleEquals_1 = (_sourcePort_1 == null);
      if (_tripleEquals_1) {
        Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(succ).keySet();
        for (final String commSigId_1 : _keySet_1) {
          {
            String suffix2 = "";
            boolean _equals_2 = this.protocolManager.getModCommSignals().get(succ).get(commSigId_1).get(ProtocolManager.CH).equals("");
            boolean _not_1 = (!_equals_2);
            if (_not_1) {
              String _get = this.protocolManager.getModCommSignals().get(succ).get(commSigId_1).get(ProtocolManager.CH);
              String _plus_4 = ("_" + _get);
              suffix2 = _plus_4;
            }
            boolean _equals_3 = this.protocolManager.getModCommSignals().get(succ).get(commSigId_1).get(ProtocolManager.CH).equals(targetChannel);
            if (_equals_3) {
              String _label = connection.getSource().getLabel();
              String _plus_5 = (prefix + _label);
              String _plus_6 = (_plus_5 + suffix2);
              return (_plus_6 + suffix);
            }
          }
        }
      } else {
        Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(succ).keySet();
        for (final String commSigId_2 : _keySet_2) {
          {
            String suffix2 = "";
            boolean _equals_2 = this.protocolManager.getModCommSignals().get(succ).get(commSigId_2).get(ProtocolManager.CH).equals("");
            boolean _not_1 = (!_equals_2);
            if (_not_1) {
              String _get = this.protocolManager.getModCommSignals().get(succ).get(commSigId_2).get(ProtocolManager.CH);
              String _plus_4 = ("_" + _get);
              suffix2 = _plus_4;
            }
            boolean _equals_3 = this.protocolManager.getModCommSignals().get(succ).get(commSigId_2).get(ProtocolManager.CH).equals(targetChannel);
            if (_equals_3) {
              String _label = connection.getSource().getLabel();
              String _plus_5 = (prefix + _label);
              String _plus_6 = (_plus_5 + "_");
              String _label_1 = connection.getSourcePort().getLabel();
              String _plus_7 = (_plus_6 + _label_1);
              String _plus_8 = (_plus_7 + suffix2);
              return (_plus_8 + suffix);
            }
          }
        }
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  /**
   * Print actors instantiation in top module.
   */
  public CharSequence printActors(final Map<String, Set<String>> clockSets) {
    StringConcatenation _builder = new StringConcatenation();
    {
      Iterable<Actor> _filter = Iterables.<Actor>filter(this.network.getChildren(), Actor.class);
      for(final Actor actor : _filter) {
        _builder.newLine();
        {
          boolean _hasAttribute = actor.hasAttribute("sbox");
          boolean _not = (!_hasAttribute);
          if (_not) {
            {
              boolean _containsKey = this.protocolManager.getModNames().containsKey(ProtocolManager.PRED);
              if (_containsKey) {
                {
                  EList<Port> _inputs = actor.getInputs();
                  for(final Port input : _inputs) {
                    _builder.append("// ");
                    String _get = this.protocolManager.getModNames().get(ProtocolManager.PRED);
                    _builder.append(_get);
                    _builder.append("_");
                    String _simpleName = actor.getSimpleName();
                    _builder.append(_simpleName);
                    _builder.append("_");
                    String _label = input.getLabel();
                    _builder.append(_label);
                    _builder.newLineIfNotEmpty();
                    String _get_1 = this.protocolManager.getModNames().get(ProtocolManager.PRED);
                    _builder.append(_get_1);
                    _builder.append(" ");
                    {
                      boolean _containsKey_1 = this.protocolManager.getModCommParms().containsKey(ProtocolManager.PRED);
                      if (_containsKey_1) {
                        _builder.append("#(");
                        _builder.newLineIfNotEmpty();
                        {
                          Set<String> _keySet = this.protocolManager.getModCommParms().get(ProtocolManager.PRED).keySet();
                          boolean _hasElements = false;
                          for(final String commParId : _keySet) {
                            if (!_hasElements) {
                              _hasElements = true;
                            } else {
                              _builder.appendImmediate(",", "");
                            }
                            _builder.append("\t.");
                            String _get_2 = this.protocolManager.getModCommParms().get(ProtocolManager.PRED).get(commParId).get(ProtocolManager.NAME);
                            _builder.append(_get_2);
                            _builder.append("(");
                            String _parameterValue = this.getParameterValue(ProtocolManager.PRED, actor, input, commParId);
                            _builder.append(_parameterValue);
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        _builder.append(") ");
                      }
                    }
                    String _get_3 = this.protocolManager.getModNames().get(ProtocolManager.PRED);
                    _builder.append(_get_3);
                    _builder.append("_");
                    String _simpleName_1 = actor.getSimpleName();
                    _builder.append(_simpleName_1);
                    _builder.append("_");
                    String _label_1 = input.getLabel();
                    _builder.append(_label_1);
                    _builder.append("(");
                    _builder.newLineIfNotEmpty();
                    {
                      Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(ProtocolManager.PRED).keySet();
                      for(final String commSigId : _keySet_1) {
                        _builder.append("\t");
                        {
                          boolean _isInputSide = this.protocolManager.isInputSide(ProtocolManager.PRED, commSigId);
                          if (_isInputSide) {
                            _builder.append(".");
                            String _get_4 = this.protocolManager.getModCommSignals().get(ProtocolManager.PRED).get(commSigId).get(ProtocolManager.ACTP);
                            _builder.append(_get_4, "\t");
                            _builder.append("(");
                            String _modName = this.protocolManager.getModName(ProtocolManager.PRED);
                            _builder.append(_modName, "\t");
                            String _label_2 = actor.getLabel();
                            _builder.append(_label_2, "\t");
                            _builder.append("_");
                            String _sigPrintName = this.protocolManager.getSigPrintName(ProtocolManager.PRED, commSigId, input);
                            _builder.append(_sigPrintName, "\t");
                            _builder.append("),");
                          }
                        }
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        {
                          boolean _isOutputSide = this.protocolManager.isOutputSide(ProtocolManager.PRED, commSigId);
                          if (_isOutputSide) {
                            _builder.append(".");
                            String _get_5 = this.protocolManager.getModCommSignals().get(ProtocolManager.PRED).get(commSigId).get(ProtocolManager.ACTP);
                            _builder.append(_get_5, "\t");
                            _builder.append("(");
                            String _modName_1 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                            _builder.append(_modName_1, "\t");
                            String _label_3 = actor.getLabel();
                            _builder.append(_label_3, "\t");
                            _builder.append("_");
                            String _sigPrintName_1 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId, input);
                            _builder.append(_sigPrintName_1, "\t");
                            _builder.append("),");
                          }
                        }
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("// System Signal(s)");
                    _builder.newLine();
                    {
                      Set<String> _keySet_2 = this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).keySet();
                      boolean _hasElements_1 = false;
                      for(final String sysSigId : _keySet_2) {
                        if (!_hasElements_1) {
                          _hasElements_1 = true;
                        } else {
                          _builder.appendImmediate(",", "\t");
                        }
                        {
                          if ((this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).get(sysSigId).containsKey(ProtocolManager.CLOCK) && ((this.enableClockGating).booleanValue() || (this.enablePowerGating).booleanValue()))) {
                            _builder.append("\t");
                            _builder.append(".");
                            String _get_6 = this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).get(sysSigId).get(ProtocolManager.ACTP);
                            _builder.append(_get_6, "\t");
                            _builder.append("(");
                            {
                              boolean _contains = this.powerSets.contains(this.instanceClockDomain.get(actor));
                              if (_contains) {
                                _builder.append(this.clockSignal, "\t");
                                _builder.append("ck_gated_");
                                Integer _get_7 = this.clockDomainsIndex.get(this.instanceClockDomain.get(actor));
                                _builder.append(_get_7, "\t");
                              } else {
                                String _get_8 = this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).get(sysSigId).get(ProtocolManager.NETP);
                                _builder.append(_get_8, "\t");
                              }
                            }
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            _builder.append(".");
                            String _get_9 = this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).get(sysSigId).get(ProtocolManager.ACTP);
                            _builder.append(_get_9, "\t");
                            _builder.append("(");
                            String _get_10 = this.protocolManager.getModSysSignals().get(ProtocolManager.PRED).get(sysSigId).get(ProtocolManager.NETP);
                            _builder.append(_get_10, "\t");
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append(");");
                    _builder.newLine();
                  }
                }
              }
            }
            _builder.newLine();
            _builder.append("// actor ");
            String _simpleName_2 = actor.getSimpleName();
            _builder.append(_simpleName_2);
            _builder.newLineIfNotEmpty();
            String _actorName = this.getActorName(actor);
            _builder.append(_actorName);
            _builder.append(" ");
            {
              boolean _isEmpty = this.getActorStaticParms(actor).isEmpty();
              boolean _not_1 = (!_isEmpty);
              if (_not_1) {
                _builder.append("#(");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append("// Parameter(s)");
                _builder.newLine();
                {
                  List<Var> _actorStaticParms = this.getActorStaticParms(actor);
                  boolean _hasElements_2 = false;
                  for(final Var parm : _actorStaticParms) {
                    if (!_hasElements_2) {
                      _hasElements_2 = true;
                    } else {
                      _builder.appendImmediate(",", "");
                    }
                    String _printActorStaticParm = this.printActorStaticParm(parm, actor.getParameters().size());
                    _builder.append(_printActorStaticParm);
                    _builder.newLineIfNotEmpty();
                  }
                }
                _builder.append(")");
                _builder.newLine();
              }
            }
            _builder.append("actor_");
            String _simpleName_3 = actor.getSimpleName();
            _builder.append(_simpleName_3);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Input Signal(s)");
            _builder.newLine();
            {
              EList<Port> _inputs_1 = actor.getInputs();
              boolean _hasElements_3 = false;
              for(final Port input_1 : _inputs_1) {
                if (!_hasElements_3) {
                  _hasElements_3 = true;
                } else {
                  _builder.appendImmediate(",", "\t");
                }
                {
                  ArrayList<String> _actorInputCommSignals = this.protocolManager.getActorInputCommSignals(actor);
                  boolean _hasElements_4 = false;
                  for(final String commSigId_1 : _actorInputCommSignals) {
                    if (!_hasElements_4) {
                      _hasElements_4 = true;
                    } else {
                      _builder.appendImmediate(",", "\t");
                    }
                    _builder.append("\t");
                    _builder.append(".");
                    String _actorPortPrintSignal = this.protocolManager.getActorPortPrintSignal(commSigId_1, input_1);
                    _builder.append(_actorPortPrintSignal, "\t");
                    _builder.append("(");
                    String _modName_2 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                    _builder.append(_modName_2, "\t");
                    String _label_4 = actor.getLabel();
                    _builder.append(_label_4, "\t");
                    _builder.append("_");
                    String _sigPrintName_2 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId_1, input_1);
                    _builder.append(_sigPrintName_2, "\t");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append("\t");
            {
              if (((((!actor.getInputs().isEmpty()) && (!this.protocolManager.getActorInputCommSignals(actor).isEmpty())) && 
                (!actor.getOutputs().isEmpty())) && (!this.protocolManager.getActorOutputCommSignals(actor).isEmpty()))) {
                _builder.append(",");
              }
            }
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Output Signal(s)");
            _builder.newLine();
            {
              EList<Port> _outputs = actor.getOutputs();
              boolean _hasElements_5 = false;
              for(final Port output : _outputs) {
                if (!_hasElements_5) {
                  _hasElements_5 = true;
                } else {
                  _builder.appendImmediate(",", "\t");
                }
                {
                  ArrayList<String> _actorOutputCommSignals = this.protocolManager.getActorOutputCommSignals(actor);
                  boolean _hasElements_6 = false;
                  for(final String commSigId_2 : _actorOutputCommSignals) {
                    if (!_hasElements_6) {
                      _hasElements_6 = true;
                    } else {
                      _builder.appendImmediate(",", "\t");
                    }
                    _builder.append("\t");
                    _builder.append(".");
                    String _actorPortPrintSignal_1 = this.protocolManager.getActorPortPrintSignal(commSigId_2, output);
                    _builder.append(_actorPortPrintSignal_1, "\t");
                    _builder.append("(");
                    String _modName_3 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                    _builder.append(_modName_3, "\t");
                    String _label_5 = actor.getLabel();
                    _builder.append(_label_5, "\t");
                    _builder.append("_");
                    String _sigPrintName_3 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId_2, output);
                    _builder.append(_sigPrintName_3, "\t");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append("\t");
            {
              if (((!this.getActorDynamicParms(actor).isEmpty()) && (!actor.getParameters().isEmpty()))) {
                _builder.append(",");
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.newLine();
                _builder.append("\t");
                _builder.append("// Dynamic Parameter(s)");
                _builder.newLine();
                {
                  List<Var> _actorDynamicParms = this.getActorDynamicParms(actor);
                  boolean _hasElements_7 = false;
                  for(final Var parm_1 : _actorDynamicParms) {
                    if (!_hasElements_7) {
                      _hasElements_7 = true;
                    } else {
                      _builder.appendImmediate(",", "\t");
                    }
                    _builder.append("\t");
                    String _printActorDynamicParm = this.printActorDynamicParm(parm_1, actor.getParameters().size());
                    _builder.append(_printActorDynamicParm, "\t");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append("\t");
            {
              boolean _isEmpty_1 = this.protocolManager.getActorSysSignals(actor).isEmpty();
              boolean _not_2 = (!_isEmpty_1);
              if (_not_2) {
                _builder.append(",");
              }
            }
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// System Signal(s)");
            _builder.newLine();
            {
              ArrayList<String> _actorSysSignals = this.protocolManager.getActorSysSignals(actor);
              boolean _hasElements_8 = false;
              for(final String sysSigId_1 : _actorSysSignals) {
                if (!_hasElements_8) {
                  _hasElements_8 = true;
                } else {
                  _builder.appendImmediate(",", "\t");
                }
                {
                  if ((this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).containsKey(ProtocolManager.CLOCK) && ((this.enableClockGating).booleanValue() || (this.enablePowerGating).booleanValue()))) {
                    _builder.append("\t");
                    _builder.append(".");
                    String _get_11 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).get(ProtocolManager.ACTP);
                    _builder.append(_get_11, "\t");
                    _builder.append("(");
                    {
                      boolean _contains_1 = this.powerSets.contains(this.instanceClockDomain.get(actor));
                      if (_contains_1) {
                        _builder.append(this.clockSignal, "\t");
                        _builder.append("ck_gated_");
                        Integer _get_12 = this.clockDomainsIndex.get(this.instanceClockDomain.get(actor));
                        _builder.append(_get_12, "\t");
                      } else {
                        String _get_13 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).get(ProtocolManager.NETP);
                        _builder.append(_get_13, "\t");
                      }
                    }
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                  } else {
                    _builder.append("\t");
                    _builder.append(".");
                    String _get_14 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).get(ProtocolManager.ACTP);
                    _builder.append(_get_14, "\t");
                    _builder.append("(");
                    String _get_15 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).get(ProtocolManager.NETP);
                    _builder.append(_get_15, "\t");
                    _builder.append(")");
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append(");");
            _builder.newLine();
            _builder.newLine();
          } else {
            _builder.append("// actor ");
            String _simpleName_4 = actor.getSimpleName();
            _builder.append(_simpleName_4);
            _builder.newLineIfNotEmpty();
            String _sboxActorName = this.getSboxActorName(actor);
            _builder.append(_sboxActorName);
            _builder.append(" #(");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".SIZE(");
            int _sizeInBits = actor.getInput("in1").getType().getSizeInBits();
            _builder.append(_sizeInBits, "\t");
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append(")");
            _builder.newLine();
            String _simpleName_5 = actor.getSimpleName();
            _builder.append(_simpleName_5);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("// Input Signal(s)");
            _builder.newLine();
            {
              EList<Port> _inputs_2 = actor.getInputs();
              for(final Port input_2 : _inputs_2) {
                {
                  Set<String> _keySet_3 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
                  for(final String commSigId_3 : _keySet_3) {
                    _builder.append("\t");
                    {
                      if ((this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId_3) && (!input_2.getLabel().equals("sel")))) {
                        _builder.append(".");
                        String _label_6 = input_2.getLabel();
                        _builder.append(_label_6, "\t");
                        String _channelPrintSuffix = this.protocolManager.getChannelPrintSuffix(this.protocolManager.getFirstMod(), commSigId_3);
                        _builder.append(_channelPrintSuffix, "\t");
                        _builder.append("(");
                        String _label_7 = actor.getLabel();
                        _builder.append(_label_7, "\t");
                        _builder.append("_");
                        String _sigPrintName_4 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_3, input_2);
                        _builder.append(_sigPrintName_4, "\t");
                        _builder.append("),");
                      }
                    }
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Output Signal(s)");
            _builder.newLine();
            {
              EList<Port> _outputs_1 = actor.getOutputs();
              for(final Port output_1 : _outputs_1) {
                {
                  Set<String> _keySet_4 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
                  for(final String commSigId_4 : _keySet_4) {
                    _builder.append("\t");
                    {
                      boolean _isOutputSide_1 = this.protocolManager.isOutputSide(this.protocolManager.getLastMod(), commSigId_4);
                      if (_isOutputSide_1) {
                        _builder.append(".");
                        String _label_8 = output_1.getLabel();
                        _builder.append(_label_8, "\t");
                        String _channelPrintSuffix_1 = this.protocolManager.getChannelPrintSuffix(this.protocolManager.getLastMod(), commSigId_4);
                        _builder.append(_channelPrintSuffix_1, "\t");
                        _builder.append("(");
                        String _label_9 = actor.getLabel();
                        _builder.append(_label_9, "\t");
                        _builder.append("_");
                        String _sigPrintName_5 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_4, output_1);
                        _builder.append(_sigPrintName_5, "\t");
                        _builder.append("),");
                      }
                    }
                    _builder.newLineIfNotEmpty();
                  }
                }
              }
            }
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("// Selector");
            _builder.newLine();
            _builder.append("\t");
            _builder.append(".sel(sel[");
            String _get_16 = actor.getSimpleName().split("_")[1];
            _builder.append(_get_16, "\t");
            _builder.append("])\t");
            _builder.newLineIfNotEmpty();
            _builder.append(");");
            _builder.newLine();
          }
        }
        _builder.newLine();
        {
          boolean _hasAttribute_1 = actor.hasAttribute("sbox");
          boolean _not_3 = (!_hasAttribute_1);
          if (_not_3) {
            {
              boolean _containsKey_2 = this.protocolManager.getModNames().containsKey(ProtocolManager.SUCC);
              if (_containsKey_2) {
                {
                  EList<Port> _outputs_2 = actor.getOutputs();
                  for(final Port output_2 : _outputs_2) {
                    _builder.append("// ");
                    String _get_17 = this.protocolManager.getModNames().get(ProtocolManager.SUCC);
                    _builder.append(_get_17);
                    _builder.append("_");
                    String _simpleName_6 = actor.getSimpleName();
                    _builder.append(_simpleName_6);
                    _builder.append("_");
                    String _label_10 = output_2.getLabel();
                    _builder.append(_label_10);
                    _builder.newLineIfNotEmpty();
                    String _get_18 = this.protocolManager.getModNames().get(ProtocolManager.SUCC);
                    _builder.append(_get_18);
                    _builder.append("  ");
                    {
                      boolean _containsKey_3 = this.protocolManager.getModCommParms().containsKey(ProtocolManager.PRED);
                      if (_containsKey_3) {
                        _builder.append("#(");
                        _builder.newLineIfNotEmpty();
                        {
                          Set<String> _keySet_5 = this.protocolManager.getModCommParms().get(ProtocolManager.SUCC).keySet();
                          boolean _hasElements_9 = false;
                          for(final String commParId_1 : _keySet_5) {
                            if (!_hasElements_9) {
                              _hasElements_9 = true;
                            } else {
                              _builder.appendImmediate(",", "");
                            }
                            _builder.append("\t.");
                            String _get_19 = this.protocolManager.getModCommParms().get(ProtocolManager.SUCC).get(commParId_1).get(ProtocolManager.NAME);
                            _builder.append(_get_19);
                            _builder.append("(");
                            String _parameterValue_1 = this.getParameterValue(ProtocolManager.SUCC, actor, output_2, commParId_1);
                            _builder.append(_parameterValue_1);
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                        _builder.append(") ");
                      }
                    }
                    String _get_20 = this.protocolManager.getModNames().get(ProtocolManager.SUCC);
                    _builder.append(_get_20);
                    _builder.append("_");
                    String _simpleName_7 = actor.getSimpleName();
                    _builder.append(_simpleName_7);
                    _builder.append("_");
                    String _label_11 = output_2.getLabel();
                    _builder.append(_label_11);
                    _builder.append("(");
                    _builder.newLineIfNotEmpty();
                    {
                      Set<String> _keySet_6 = this.protocolManager.getModCommSignals().get(ProtocolManager.SUCC).keySet();
                      for(final String commSigId_5 : _keySet_6) {
                        _builder.append("\t");
                        {
                          boolean _isInputSide_1 = this.protocolManager.isInputSide(ProtocolManager.SUCC, commSigId_5);
                          if (_isInputSide_1) {
                            _builder.append(".");
                            String _get_21 = this.protocolManager.getModCommSignals().get(ProtocolManager.SUCC).get(commSigId_5).get(ProtocolManager.ACTP);
                            _builder.append(_get_21, "\t");
                            _builder.append("(");
                            String _modName_4 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                            _builder.append(_modName_4, "\t");
                            String _label_12 = actor.getLabel();
                            _builder.append(_label_12, "\t");
                            _builder.append("_");
                            String _sigPrintName_6 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId_5, output_2);
                            _builder.append(_sigPrintName_6, "\t");
                            _builder.append("),");
                          }
                        }
                        _builder.newLineIfNotEmpty();
                        _builder.append("\t");
                        {
                          boolean _isOutputSide_2 = this.protocolManager.isOutputSide(ProtocolManager.SUCC, commSigId_5);
                          if (_isOutputSide_2) {
                            _builder.append(".");
                            String _get_22 = this.protocolManager.getModCommSignals().get(ProtocolManager.SUCC).get(commSigId_5).get(ProtocolManager.ACTP);
                            _builder.append(_get_22, "\t");
                            _builder.append("(");
                            String _modName_5 = this.protocolManager.getModName(ProtocolManager.SUCC);
                            _builder.append(_modName_5, "\t");
                            String _label_13 = actor.getLabel();
                            _builder.append(_label_13, "\t");
                            _builder.append("_");
                            String _sigPrintName_7 = this.protocolManager.getSigPrintName(ProtocolManager.SUCC, commSigId_5, output_2);
                            _builder.append(_sigPrintName_7, "\t");
                            _builder.append("),");
                          }
                        }
                        _builder.newLineIfNotEmpty();
                      }
                    }
                    _builder.append("\t");
                    _builder.newLine();
                    _builder.append("\t");
                    _builder.append("// System Signal(s)");
                    _builder.newLine();
                    {
                      Set<String> _keySet_7 = this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).keySet();
                      boolean _hasElements_10 = false;
                      for(final String sysSigId_2 : _keySet_7) {
                        if (!_hasElements_10) {
                          _hasElements_10 = true;
                        } else {
                          _builder.appendImmediate(",", "\t");
                        }
                        {
                          if ((this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).get(sysSigId_2).containsKey(ProtocolManager.CLOCK) && ((this.enableClockGating).booleanValue() || (this.enablePowerGating).booleanValue()))) {
                            _builder.append("\t");
                            _builder.append(".");
                            String _get_23 = this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).get(sysSigId_2).get(ProtocolManager.ACTP);
                            _builder.append(_get_23, "\t");
                            _builder.append("(");
                            {
                              boolean _contains_2 = this.powerSets.contains(this.instanceClockDomain.get(actor));
                              if (_contains_2) {
                                _builder.append(this.clockSignal, "\t");
                                _builder.append("ck_gated_");
                                Integer _get_24 = this.clockDomainsIndex.get(this.instanceClockDomain.get(actor));
                                _builder.append(_get_24, "\t");
                              } else {
                                String _get_25 = this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).get(sysSigId_2).get(ProtocolManager.NETP);
                                _builder.append(_get_25, "\t");
                              }
                            }
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          } else {
                            _builder.append("\t");
                            _builder.append(".");
                            String _get_26 = this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).get(sysSigId_2).get(ProtocolManager.ACTP);
                            _builder.append(_get_26, "\t");
                            _builder.append("(");
                            String _get_27 = this.protocolManager.getModSysSignals().get(ProtocolManager.SUCC).get(sysSigId_2).get(ProtocolManager.NETP);
                            _builder.append(_get_27, "\t");
                            _builder.append(")");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                    _builder.append(");");
                    _builder.newLine();
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the given dynamic (run time) parameter of an actor
   */
  public String printActorDynamicParm(final Var parm, final int size) {
    String result = "";
    String value = "";
    EList<Var> _parameters = this.network.getParameters();
    for (final Var netParm : _parameters) {
      boolean _equals = netParm.getName().equals(parm.getName());
      if (_equals) {
        value = netParm.getName();
      }
    }
    boolean _equals_1 = value.equals("");
    if (_equals_1) {
      value = Integer.valueOf(this.evaluator.evaluateAsInteger(parm.getInitialValue())).toString();
    }
    String _name = parm.getName();
    String _plus = ("." + _name);
    String _plus_1 = (_plus + "(");
    String _plus_2 = (_plus_1 + value);
    String _plus_3 = (_plus_2 + ")");
    result = _plus_3;
    return result;
  }
  
  /**
   * Print the given static (design time) parameter of an actor
   */
  public String printActorStaticParm(final Var parm, final int size) {
    String result = "";
    String value = "";
    EList<Var> _variables = this.network.getVariables();
    for (final Var netParm : _variables) {
      boolean _equals = netParm.getName().equals(parm.getName());
      if (_equals) {
        value = netParm.getName();
      }
    }
    boolean _equals_1 = value.equals("");
    if (_equals_1) {
      value = Integer.valueOf(this.evaluator.evaluateAsInteger(parm.getInitialValue())).toString();
    }
    String _name = parm.getName();
    String _plus = ("." + _name);
    String _plus_1 = (_plus + "(");
    String _plus_2 = (_plus_1 + value);
    String _plus_3 = (_plus_2 + ")");
    result = _plus_3;
    return result;
  }
  
  /**
   * Print assignments to connect instances.
   */
  public CharSequence printAssignments() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Module(s) Assignments");
    _builder.newLine();
    {
      EList<Connection> _connections = this.network.getConnections();
      for(final Connection connection : _connections) {
        {
          Set<String> _keySet = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
          for(final String commSigId : _keySet) {
            {
              boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId);
              if (_isInputSide) {
                {
                  boolean _equals = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.KIND).equals("input");
                  if (_equals) {
                    _builder.append("assign ");
                    String _targetSignal = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId);
                    _builder.append(_targetSignal);
                    _builder.append(" = ");
                    String _sourceSignal = this.getSourceSignal(connection, this.protocolManager.getLastMod(), this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.CH));
                    _builder.append(_sourceSignal);
                    _builder.append(";");
                    _builder.newLineIfNotEmpty();
                  } else {
                    {
                      boolean _hasAttribute = connection.hasAttribute("broadcast");
                      if (_hasAttribute) {
                        {
                          Vertex _source = connection.getSource();
                          if ((_source instanceof Actor)) {
                            {
                              boolean _hasAttribute_1 = connection.getSourcePort().hasAttribute("printed");
                              boolean _not = (!_hasAttribute_1);
                              if (_not) {
                                _builder.append("assign ");
                                String _sourceSignal_1 = this.getSourceSignal(connection, this.protocolManager.getLastMod(), this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.CH));
                                _builder.append(_sourceSignal_1);
                                _builder.append(" =");
                                _builder.newLineIfNotEmpty();
                                {
                                  Vertex _source_1 = connection.getSource();
                                  List<Connection> _get = ((Actor) _source_1).getOutgoingPortMap().get(connection.getSourcePort());
                                  boolean _hasElements = false;
                                  for(final Connection broadConn : _get) {
                                    if (!_hasElements) {
                                      _hasElements = true;
                                    } else {
                                      _builder.appendImmediate(" ||", "");
                                    }
                                    String _targetSignal_1 = this.protocolManager.getTargetSignal(broadConn, this.protocolManager.getFirstMod(), commSigId);
                                    _builder.append(_targetSignal_1);
                                    _builder.append(" ");
                                    _builder.newLineIfNotEmpty();
                                  }
                                }
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                                connection.getSourcePort().setAttribute("printed", "");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          } else {
                            {
                              boolean _hasAttribute_2 = connection.getSource().hasAttribute("printed");
                              boolean _not_1 = (!_hasAttribute_2);
                              if (_not_1) {
                                _builder.append("assign ");
                                String _sourceSignal_2 = this.getSourceSignal(connection, this.protocolManager.getLastMod(), this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.CH));
                                _builder.append(_sourceSignal_2);
                                _builder.append(" =\t\t");
                                _builder.newLineIfNotEmpty();
                                {
                                  Vertex _source_2 = connection.getSource();
                                  EList<Edge> _outgoing = ((Port) _source_2).getOutgoing();
                                  boolean _hasElements_1 = false;
                                  for(final Edge broadConn_1 : _outgoing) {
                                    if (!_hasElements_1) {
                                      _hasElements_1 = true;
                                    } else {
                                      _builder.appendImmediate(" ||", "");
                                    }
                                    String _targetSignal_2 = this.protocolManager.getTargetSignal(((Connection) broadConn_1), this.protocolManager.getFirstMod(), commSigId);
                                    _builder.append(_targetSignal_2);
                                    _builder.append(" ");
                                    _builder.newLineIfNotEmpty();
                                  }
                                }
                                _builder.append(";");
                                _builder.newLineIfNotEmpty();
                                connection.getSource().setAttribute("printed", "");
                                _builder.newLineIfNotEmpty();
                              }
                            }
                          }
                        }
                      } else {
                        _builder.append("assign ");
                        String _sourceSignal_3 = this.getSourceSignal(connection, this.protocolManager.getLastMod(), this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.CH));
                        _builder.append(_sourceSignal_3);
                        _builder.append(" = ");
                        String _targetSignal_3 = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId);
                        _builder.append(_targetSignal_3);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          }
        }
        _builder.newLine();
      }
    }
    return _builder;
  }
  
  /**
   * Print clock domains information
   */
  public CharSequence printClockInformation() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Clock Domain(s) Information on the Network \"");
    String _simpleName = this.network.getSimpleName();
    _builder.append(_simpleName);
    _builder.append("\"");
    _builder.newLineIfNotEmpty();
    _builder.append("//");
    _builder.newLine();
    _builder.append("// Network input port(s) clock domain:");
    _builder.newLine();
    _builder.newLine();
    _builder.append("// Actor(s) clock domains (for clock gating):");
    _builder.newLine();
    {
      EList<Vertex> _vertices = this.network.getVertices();
      for(final Vertex vertex : _vertices) {
        {
          if ((vertex instanceof Actor)) {
            {
              boolean _not = (!(((Actor)vertex).<Actor>getAdapter(Actor.class).hasAttribute("sbox") || ((Actor)vertex).<Actor>getAdapter(Actor.class).hasAttribute("only_cal")));
              if (_not) {
                _builder.append("//\t");
                String _simpleName_1 = ((Actor) vertex).getSimpleName();
                _builder.append(_simpleName_1);
                _builder.append(" --> ");
                String _get = this.instanceClockDomain.get(((Actor) vertex));
                _builder.append(_get);
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Print the configurator
   */
  public CharSequence printConfig(final List<SboxLut> luts) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Network Configurator");
    _builder.newLine();
    _builder.append("configurator config_0 (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".sel(sel),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".ID(ID)");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * Print the logic necessary to manage the clock gating technique: enable generator and clock gating cells
   */
  public CharSequence printEnableGenerator() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("// Enable Generator");
    _builder.newLine();
    _builder.append("enable_generator en_gen_0 (");
    _builder.newLine();
    {
      Set<String> _keySet = this.protocolManager.getNetSysSignals().keySet();
      boolean _hasElements = false;
      for(final String sysSigId : _keySet) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(",", "\t");
        }
        {
          boolean _containsKey = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId).containsKey(ProtocolManager.CLOCK);
          if (_containsKey) {
            _builder.append("\t");
            _builder.append(".clock_in(");
            String _get = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get, "\t");
            _builder.append(")");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append(".clocks_en(clocks_en),\t\t\t\t\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".ID(ID)");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    {
      for(final String lr : this.powerSets) {
        {
          Boolean _get_1 = this.logicRegionsSeqMap.get(lr);
          if ((_get_1).booleanValue()) {
            _builder.append("// Clock Gating Cell ");
            Integer _get_2 = this.powerSetsIndex.get(lr);
            _builder.append(_get_2);
            _builder.append(" (switches off LR ");
            Integer _get_3 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_3);
            _builder.append(")");
            _builder.newLineIfNotEmpty();
            _builder.append("clock_gating_cell cgc_");
            Integer _get_4 = this.powerSetsIndex.get(lr);
            _builder.append(_get_4);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".ck_gated(ck_gated_");
            Integer _get_5 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_5, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en(clocks_en[");
            Integer _get_6 = this.powerSetsIndex.get(lr);
            _builder.append(_get_6, "\t");
            _builder.append("]),");
            _builder.newLineIfNotEmpty();
            {
              Set<String> _keySet_1 = this.protocolManager.getNetSysSignals().keySet();
              for(final String sysSigId_1 : _keySet_1) {
                {
                  boolean _containsKey_1 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).containsKey(ProtocolManager.CLOCK);
                  if (_containsKey_1) {
                    _builder.append("\t");
                    _builder.append(".clk(");
                    String _get_7 = this.protocolManager.getNetSysSignals().get(sysSigId_1).get(ProtocolManager.NETP);
                    _builder.append(_get_7, "\t");
                    _builder.append(")");
                  }
                }
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append(");");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the header of the Verilog file
   */
  public CharSequence printHeaderComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Network module ");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * Print top module interface.
   */
  public CharSequence printInterface(final List<SboxLut> luts) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("module multi_dataflow ");
    {
      boolean _isEmpty = this.network.getVariables().isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("#(");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("// Static Parameter(s)");
        _builder.newLine();
        {
          EList<Var> _variables = this.network.getVariables();
          boolean _hasElements = false;
          for(final Var param : _variables) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder.appendImmediate(",", "\t");
            }
            _builder.append("\t");
            _builder.append("parameter ");
            {
              int _sizeInBits = param.getType().getSizeInBits();
              boolean _notEquals = (_sizeInBits != 1);
              if (_notEquals) {
                _builder.append("[");
                int _sizeInBits_1 = param.getType().getSizeInBits();
                int _minus = (_sizeInBits_1 - 1);
                _builder.append(_minus, "\t");
                _builder.append(":0] ");
              }
            }
            String _name = param.getName();
            _builder.append(_name, "\t");
            _builder.append(" = ");
            Expression _initialValue = param.getInitialValue();
            int _evaluateAsInteger = this.evaluator.evaluateAsInteger(((Expression) _initialValue));
            _builder.append(_evaluateAsInteger, "\t");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append(") ");
      }
    }
    _builder.append("(");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("// Input(s)");
    _builder.newLine();
    {
      EList<Port> _inputs = this.network.getInputs();
      for(final Port input : _inputs) {
        {
          Set<String> _keySet = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
          for(final String commSigId : _keySet) {
            {
              boolean _isInputSide = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId);
              if (_isInputSide) {
                _builder.append("\t");
                String _get = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).get(commSigId).get(ProtocolManager.KIND);
                _builder.append(_get, "\t");
                _builder.append(" ");
                String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId, input);
                _builder.append(_commSigPrintRange, "\t");
                String _sigPrintName = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId, input);
                _builder.append(_sigPrintName, "\t");
                _builder.append(",");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("// Output(s)");
        _builder.newLine();
      }
    }
    {
      EList<Port> _outputs = this.network.getOutputs();
      for(final Port output : _outputs) {
        {
          Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).keySet();
          for(final String commSigId_1 : _keySet_1) {
            {
              boolean _isOutputSide = this.protocolManager.isOutputSide(this.protocolManager.getLastMod(), commSigId_1);
              if (_isOutputSide) {
                _builder.append("\t");
                String _get_1 = this.protocolManager.getModCommSignals().get(this.protocolManager.getLastMod()).get(commSigId_1).get(ProtocolManager.KIND);
                _builder.append(_get_1, "\t");
                _builder.append(" ");
                String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getLastMod(), null, commSigId_1, output);
                _builder.append(_commSigPrintRange_1, "\t");
                String _sigPrintName_1 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_1, output);
                _builder.append(_sigPrintName_1, "\t");
                _builder.append(",");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Dynamic Parameter(s)");
    _builder.newLine();
    {
      boolean _isEmpty_1 = this.network.getParameters().isEmpty();
      boolean _not_1 = (!_isEmpty_1);
      if (_not_1) {
        {
          EList<Var> _parameters = this.network.getParameters();
          for(final Var param_1 : _parameters) {
            _builder.append("\t");
            _builder.append("input [");
            int _sizeInBits_2 = param_1.getType().getSizeInBits();
            int _minus_1 = (_sizeInBits_2 - 1);
            _builder.append(_minus_1, "\t");
            _builder.append(":0] ");
            String _name_1 = param_1.getName();
            _builder.append(_name_1, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Monitoring");
    _builder.newLine();
    {
      EList<Connection> _connections = this.network.getConnections();
      for(final Connection connection : _connections) {
        {
          boolean _hasAttribute = connection.hasAttribute("monitor_in");
          if (_hasAttribute) {
            {
              Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
              for(final String commSigId_2 : _keySet_2) {
                {
                  boolean _isInputSide_1 = this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId_2);
                  if (_isInputSide_1) {
                    {
                      Vertex _target = connection.getTarget();
                      if ((_target instanceof Port)) {
                        _builder.append("\t");
                        _builder.append("output ");
                        String _commSigPrintRange_2 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), null, commSigId_2, connection.getTarget().<Port>getAdapter(Port.class));
                        _builder.append(_commSigPrintRange_2, "\t");
                        String _targetSignal = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId_2);
                        _builder.append(_targetSignal, "\t");
                        _builder.append(", // ");
                        _builder.append(connection, "\t");
                        _builder.newLineIfNotEmpty();
                      } else {
                        _builder.append("\t");
                        _builder.append("output ");
                        String _commSigPrintRange_3 = this.protocolManager.getCommSigPrintRange(this.protocolManager.getFirstMod(), connection.getTarget().<Actor>getAdapter(Actor.class), commSigId_2, connection.getTargetPort());
                        _builder.append(_commSigPrintRange_3, "\t");
                        String _targetSignal_1 = this.protocolManager.getTargetSignal(connection, this.protocolManager.getFirstMod(), commSigId_2);
                        _builder.append(_targetSignal_1, "\t");
                        _builder.append(", // ");
                        _builder.append(connection, "\t");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Configuration ID");
    _builder.newLine();
    {
      boolean _isEmpty_2 = luts.isEmpty();
      boolean _not_2 = (!_isEmpty_2);
      if (_not_2) {
        _builder.append("\t");
        _builder.append("input [7:0] ID,");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      if ((this.enablePowerGating).booleanValue()) {
        _builder.append("\t");
        _builder.append("input [17:0] reference_count, //to set the time necessary for be sure power is off or on");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
        {
          for(final String lr : this.powerSets) {
            _builder.append("\t");
            _builder.append("output\tstatus");
            Integer _get_2 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_2, "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// System Signal(s)\t\t");
    _builder.newLine();
    {
      Set<String> _keySet_3 = this.protocolManager.getNetSysSignals().keySet();
      boolean _hasElements_1 = false;
      for(final String sysSigId : _keySet_3) {
        if (!_hasElements_1) {
          _hasElements_1 = true;
        } else {
          _builder.appendImmediate(",", "\t");
        }
        _builder.append("\t");
        String _get_3 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.KIND);
        _builder.append(_get_3, "\t");
        _builder.append(" ");
        String _sysSigPrintRange = this.protocolManager.getSysSigPrintRange(null, sysSigId);
        _builder.append(_sysSigPrintRange, "\t");
        String _get_4 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
        _builder.append(_get_4, "\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(");\t");
    _builder.newLine();
    return _builder;
  }
  
  /**
   * print top module internal signals
   */
  public CharSequence printInternalSignals(final List<SboxLut> luts) {
    StringConcatenation _builder = new StringConcatenation();
    {
      boolean _isEmpty = luts.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("// Sboxes Config Wire(s)");
        _builder.newLine();
        _builder.append("wire [");
        int _size = luts.size();
        int _minus = (_size - 1);
        _builder.append(_minus);
        _builder.append(" : 0] sel;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t\t");
    _builder.newLine();
    {
      if ((this.enableClockGating).booleanValue()) {
        _builder.append("// Enable Generator Wire(s)");
        _builder.newLine();
        _builder.append("wire [");
        int _size_1 = this.powerSetsIndex.size();
        int _minus_1 = (_size_1 - 1);
        _builder.append(_minus_1);
        _builder.append(" : 0] clocks_en;");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    {
      if ((this.enablePowerGating).booleanValue()) {
        _builder.append("//Power controller Wires");
        _builder.newLine();
        _builder.append("wire [17:0] reference_count;");
        _builder.newLine();
        _builder.newLine();
        {
          for(final String lr : this.powerSets) {
            _builder.append("wire\tsw_ack");
            Integer _get = this.clockDomainsIndex.get(lr);
            _builder.append(_get);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire\tstatus");
            Integer _get_1 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_1);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("wire\tiso_en");
            Integer _get_2 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_2);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            {
              Boolean _get_3 = this.logicRegionsSeqMap.get(lr);
              if ((_get_3).booleanValue()) {
                _builder.append("wire\trtn_en");
                Integer _get_4 = this.clockDomainsIndex.get(lr);
                _builder.append(_get_4);
                _builder.append(";");
                _builder.newLineIfNotEmpty();
                _builder.append("wire\ten_cg");
                Integer _get_5 = this.clockDomainsIndex.get(lr);
                _builder.append(_get_5);
                _builder.append(";");
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append("wire\tpw_switch_en");
            Integer _get_6 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_6);
            _builder.append(";");
            _builder.newLineIfNotEmpty();
          }
        }
      }
    }
    _builder.newLine();
    _builder.append("// Actors Wire(s)");
    _builder.newLine();
    {
      Iterable<Actor> _filter = Iterables.<Actor>filter(this.network.getChildren(), Actor.class);
      for(final Actor actor : _filter) {
        _builder.append("\t");
        _builder.newLine();
        _builder.append("// actor ");
        String _simpleName = actor.getSimpleName();
        _builder.append(_simpleName);
        _builder.newLineIfNotEmpty();
        {
          boolean _hasAttribute = actor.hasAttribute("sbox");
          boolean _not_1 = (!_hasAttribute);
          if (_not_1) {
            {
              EList<Port> _inputs = actor.getInputs();
              for(final Port input : _inputs) {
                {
                  boolean _containsKey = this.protocolManager.getModNames().containsKey(ProtocolManager.PRED);
                  if (_containsKey) {
                    {
                      Set<String> _keySet = this.protocolManager.getModCommSignals().get(ProtocolManager.PRED).keySet();
                      for(final String commSigId : _keySet) {
                        {
                          boolean _isInputSide = this.protocolManager.isInputSide(ProtocolManager.PRED, commSigId);
                          if (_isInputSide) {
                            _builder.append("wire ");
                            String _commSigPrintRange = this.protocolManager.getCommSigPrintRange(ProtocolManager.PRED, actor, commSigId, input);
                            _builder.append(_commSigPrintRange);
                            String _modName = this.protocolManager.getModName(ProtocolManager.PRED);
                            _builder.append(_modName);
                            String _label = actor.getLabel();
                            _builder.append(_label);
                            _builder.append("_");
                            String _sigPrintName = this.protocolManager.getSigPrintName(ProtocolManager.PRED, commSigId, input);
                            _builder.append(_sigPrintName);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
                {
                  Set<String> _keySet_1 = this.protocolManager.getModCommSignals().get(ProtocolManager.ACTOR).keySet();
                  for(final String commSigId_1 : _keySet_1) {
                    {
                      boolean _isInputSide_1 = this.protocolManager.isInputSide(ProtocolManager.ACTOR, commSigId_1);
                      if (_isInputSide_1) {
                        _builder.append("wire ");
                        String _commSigPrintRange_1 = this.protocolManager.getCommSigPrintRange(ProtocolManager.ACTOR, actor, commSigId_1, input);
                        _builder.append(_commSigPrintRange_1);
                        String _modName_1 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                        _builder.append(_modName_1);
                        String _label_1 = actor.getLabel();
                        _builder.append(_label_1);
                        _builder.append("_");
                        String _sigPrintName_1 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId_1, input);
                        _builder.append(_sigPrintName_1);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            {
              EList<Port> _outputs = actor.getOutputs();
              for(final Port output : _outputs) {
                {
                  Set<String> _keySet_2 = this.protocolManager.getModCommSignals().get(ProtocolManager.ACTOR).keySet();
                  for(final String commSigId_2 : _keySet_2) {
                    {
                      boolean _isOutputSide = this.protocolManager.isOutputSide(ProtocolManager.ACTOR, commSigId_2);
                      if (_isOutputSide) {
                        _builder.append("wire ");
                        String _commSigPrintRange_2 = this.protocolManager.getCommSigPrintRange(ProtocolManager.ACTOR, actor, commSigId_2, output);
                        _builder.append(_commSigPrintRange_2);
                        String _modName_2 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                        _builder.append(_modName_2);
                        String _label_2 = actor.getLabel();
                        _builder.append(_label_2);
                        _builder.append("_");
                        String _sigPrintName_2 = this.protocolManager.getSigPrintName(ProtocolManager.ACTOR, commSigId_2, output);
                        _builder.append(_sigPrintName_2);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
                {
                  boolean _containsKey_1 = this.protocolManager.getModNames().containsKey(ProtocolManager.SUCC);
                  if (_containsKey_1) {
                    {
                      Set<String> _keySet_3 = this.protocolManager.getModCommSignals().get(ProtocolManager.SUCC).keySet();
                      for(final String commSigId_3 : _keySet_3) {
                        {
                          boolean _isOutputSide_1 = this.protocolManager.isOutputSide(ProtocolManager.SUCC, commSigId_3);
                          if (_isOutputSide_1) {
                            _builder.append("wire ");
                            String _commSigPrintRange_3 = this.protocolManager.getCommSigPrintRange(ProtocolManager.SUCC, actor, commSigId_3, output);
                            _builder.append(_commSigPrintRange_3);
                            String _modName_3 = this.protocolManager.getModName(ProtocolManager.SUCC);
                            _builder.append(_modName_3);
                            String _label_3 = actor.getLabel();
                            _builder.append(_label_3);
                            _builder.append("_");
                            String _sigPrintName_3 = this.protocolManager.getSigPrintName(ProtocolManager.SUCC, commSigId_3, output);
                            _builder.append(_sigPrintName_3);
                            _builder.append(";");
                            _builder.newLineIfNotEmpty();
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            {
              EList<Port> _inputs_1 = actor.getInputs();
              for(final Port input_1 : _inputs_1) {
                {
                  Set<String> _keySet_4 = this.protocolManager.getModCommSignals().get(this.protocolManager.getFirstMod()).keySet();
                  for(final String commSigId_4 : _keySet_4) {
                    {
                      if ((this.protocolManager.isInputSide(this.protocolManager.getFirstMod(), commSigId_4) && (!input_1.getLabel().equals("sel")))) {
                        _builder.append("wire ");
                        String _commSigPrintRange_4 = this.protocolManager.getCommSigPrintRange(ProtocolManager.ACTOR, actor, commSigId_4, input_1);
                        _builder.append(_commSigPrintRange_4);
                        String _modName_4 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                        _builder.append(_modName_4);
                        String _label_4 = actor.getLabel();
                        _builder.append(_label_4);
                        _builder.append("_");
                        String _sigPrintName_4 = this.protocolManager.getSigPrintName(this.protocolManager.getFirstMod(), commSigId_4, input_1);
                        _builder.append(_sigPrintName_4);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
            {
              EList<Port> _outputs_1 = actor.getOutputs();
              for(final Port output_1 : _outputs_1) {
                {
                  Set<String> _keySet_5 = this.protocolManager.getModCommSignals().get(ProtocolManager.ACTOR).keySet();
                  for(final String commSigId_5 : _keySet_5) {
                    {
                      boolean _isOutputSide_2 = this.protocolManager.isOutputSide(this.protocolManager.getLastMod(), commSigId_5);
                      if (_isOutputSide_2) {
                        _builder.append("wire ");
                        String _commSigPrintRange_5 = this.protocolManager.getCommSigPrintRange(ProtocolManager.ACTOR, actor, commSigId_5, output_1);
                        _builder.append(_commSigPrintRange_5);
                        String _modName_5 = this.protocolManager.getModName(ProtocolManager.ACTOR);
                        _builder.append(_modName_5);
                        String _label_5 = actor.getLabel();
                        _builder.append(_label_5);
                        _builder.append("_");
                        String _sigPrintName_5 = this.protocolManager.getSigPrintName(this.protocolManager.getLastMod(), commSigId_5, output_1);
                        _builder.append(_sigPrintName_5);
                        _builder.append(";");
                        _builder.newLineIfNotEmpty();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print the logic necessary to manage the power gating technique: power controller and clock gating cells
   */
  public CharSequence printPowerController() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("//Power Controller");
    _builder.newLine();
    _builder.append("PowerController powerController_0(");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Input Signal(s)");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".ID(ID),");
    _builder.newLine();
    _builder.append("\t");
    _builder.append(".reference_count(reference_count),");
    _builder.newLine();
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// Output Signal(s)\t\t\t");
    _builder.newLine();
    {
      for(final String lr : this.powerSets) {
        _builder.append("\t");
        _builder.append(".sw_ack");
        Integer _get = this.clockDomainsIndex.get(lr);
        _builder.append(_get, "\t");
        _builder.append("(sw_ack");
        Integer _get_1 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_1, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".status");
        Integer _get_2 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_2, "\t");
        _builder.append("(status");
        Integer _get_3 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_3, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".iso_en");
        Integer _get_4 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_4, "\t");
        _builder.append("(iso_en");
        Integer _get_5 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_5, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
        {
          Boolean _get_6 = this.logicRegionsSeqMap.get(lr);
          if ((_get_6).booleanValue()) {
            _builder.append("\t");
            _builder.append(".rtn_en");
            Integer _get_7 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_7, "\t");
            _builder.append("(rtn_en");
            Integer _get_8 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_8, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en_cg");
            Integer _get_9 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_9, "\t");
            _builder.append("(en_cg");
            Integer _get_10 = this.clockDomainsIndex.get(lr);
            _builder.append(_get_10, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append(".pw_switch_en");
        Integer _get_11 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_11, "\t");
        _builder.append("(pw_switch_en");
        Integer _get_12 = this.clockDomainsIndex.get(lr);
        _builder.append(_get_12, "\t");
        _builder.append("),\t\t\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.append("// System Signal(s)");
    _builder.newLine();
    {
      Set<String> _keySet = this.protocolManager.getNetSysSignals().keySet();
      boolean _hasElements = false;
      for(final String sysSigId : _keySet) {
        if (!_hasElements) {
          _hasElements = true;
        } else {
          _builder.appendImmediate(",", "\t");
        }
        {
          boolean _containsKey = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId).containsKey(ProtocolManager.CLOCK);
          if (_containsKey) {
            _builder.append("\t");
            _builder.append(".clk(");
            String _get_13 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get_13, "\t");
            _builder.append(")");
          } else {
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".rst(!");
            String _get_14 = this.protocolManager.getNetSysSignals().get(sysSigId).get(ProtocolManager.NETP);
            _builder.append(_get_14, "\t");
            _builder.append(")");
          }
        }
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    _builder.newLine();
    _builder.append("/*fake_switches are inserted for behavioural and post synthesis simulation ");
    _builder.newLine();
    _builder.append("and verification (when real switches have not been insterted yet.");
    _builder.newLine();
    _builder.append("Remove these fake switches before synthesis and implementation!");
    _builder.newLine();
    _builder.append("*/");
    _builder.newLine();
    {
      for(final String lr_1 : this.powerSets) {
        _builder.append("fake_switch fake_sw_");
        Integer _get_15 = this.clockDomainsIndex.get(lr_1);
        _builder.append(_get_15);
        _builder.append(" (");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".nsleep_in(pw_switch_en");
        Integer _get_16 = this.clockDomainsIndex.get(lr_1);
        _builder.append(_get_16, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append(".nsleep_out(sw_ack");
        Integer _get_17 = this.clockDomainsIndex.get(lr_1);
        _builder.append(_get_17, "\t");
        _builder.append("),");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("// System Signal(s)");
        _builder.newLine();
        {
          Set<String> _keySet_1 = this.protocolManager.getNetSysSignals().keySet();
          boolean _hasElements_1 = false;
          for(final String sysSigId_1 : _keySet_1) {
            if (!_hasElements_1) {
              _hasElements_1 = true;
            } else {
              _builder.appendImmediate(",", "\t");
            }
            {
              boolean _containsKey_1 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_1).containsKey(ProtocolManager.CLOCK);
              if (_containsKey_1) {
                _builder.append("\t");
                _builder.append(".aclk(");
                String _get_18 = this.protocolManager.getNetSysSignals().get(sysSigId_1).get(ProtocolManager.NETP);
                _builder.append(_get_18, "\t");
                _builder.append(")");
              } else {
                _builder.newLineIfNotEmpty();
                _builder.append("\t");
                _builder.append(".aresetn(");
                String _get_19 = this.protocolManager.getNetSysSignals().get(sysSigId_1).get(ProtocolManager.NETP);
                _builder.append(_get_19, "\t");
                _builder.append(")");
              }
            }
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t\t");
        _builder.append(");");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.newLine();
    {
      for(final String lr_2 : this.powerSets) {
        {
          Boolean _get_20 = this.logicRegionsSeqMap.get(lr_2);
          if ((_get_20).booleanValue()) {
            _builder.append("// Clock Gating Cell ");
            Integer _get_21 = this.clockDomainsIndex.get(lr_2);
            _builder.append(_get_21);
            _builder.newLineIfNotEmpty();
            _builder.append("clock_gating_cell cgc_");
            Integer _get_22 = this.clockDomainsIndex.get(lr_2);
            _builder.append(_get_22);
            _builder.append(" (");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".ck_gated(ck_gated_");
            Integer _get_23 = this.clockDomainsIndex.get(lr_2);
            _builder.append(_get_23, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append(".en(en_cg");
            Integer _get_24 = this.clockDomainsIndex.get(lr_2);
            _builder.append(_get_24, "\t");
            _builder.append("),");
            _builder.newLineIfNotEmpty();
            {
              Set<String> _keySet_2 = this.protocolManager.getNetSysSignals().keySet();
              for(final String sysSigId_2 : _keySet_2) {
                {
                  boolean _containsKey_2 = this.protocolManager.getModSysSignals().get(ProtocolManager.ACTOR).get(sysSigId_2).containsKey(ProtocolManager.CLOCK);
                  if (_containsKey_2) {
                    _builder.append("\t");
                    _builder.append(".clk(");
                    String _get_25 = this.protocolManager.getNetSysSignals().get(sysSigId_2).get(ProtocolManager.NETP);
                    _builder.append(_get_25, "\t");
                    _builder.append(")");
                  }
                }
                _builder.newLineIfNotEmpty();
              }
            }
            _builder.append(");");
            _builder.newLine();
          }
        }
      }
    }
    return _builder;
  }
  
  /**
   * Print parameter within parameter list
   * 
   * @parm
   * 				involved variable
   * @size
   * 				overall number of parameters
   * @return
   * 				parameter to be printed within list
   */
  public String printParm(final Var parm, final int size) {
    String result = "";
    String _name = parm.getName();
    String _plus = ("." + _name);
    String _plus_1 = (_plus + "(");
    int _evaluateAsInteger = this.evaluator.evaluateAsInteger(parm.getInitialValue());
    String _plus_2 = (_plus_1 + Integer.valueOf(_evaluateAsInteger));
    String _plus_3 = (_plus_2 + ")");
    result = _plus_3;
    if ((this.idParm == (size - 1))) {
      this.idParm = 0;
      this.lastParm = Boolean.valueOf(true);
    } else {
      this.idParm = (this.idParm + 1);
    }
    if ((!(this.lastParm).booleanValue())) {
      result = (result + ",");
    } else {
      this.lastParm = Boolean.valueOf(false);
      this.idParm = 0;
    }
    return result;
  }
  
  /**
   * Print the top module of the merged network.
   * 
   * <ul>
   * <li> headerComments()
   * <li> printInterface()
   * <li> printInternalSignals()
   * <li> printConfig()
   * <li> printAssignments()
   * </ul>
   * According with user options, also the following can be run.
   * <ul>
   * <li> printActors()
   * <li> printEnableGenerator()
   * <li> printPowerController()
   * 
   * </ul>
   */
  public CharSequence printNetwork(final Network network, final List<SboxLut> luts, final Map<String, Set<String>> clockSets, final boolean enableClockGating, final boolean enablePowerGating, final Map<String, Set<String>> logicRegions, final Map<String, Set<String>> netRegions, final Set<String> powerSets, final Map<String, Integer> powerSetsIndex, final Map<String, Boolean> logicRegionsSeqMap, final ProtocolManager protocolManager) {
    CharSequence _xblockexpression = null;
    {
      ExpressionEvaluator _expressionEvaluator = new ExpressionEvaluator();
      this.evaluator = _expressionEvaluator;
      this.clockSignal = this.clockSignal;
      this.network = network;
      HashMap<String, Object> _hashMap = new HashMap<String, Object>();
      this.options = _hashMap;
      this.enableClockGating = Boolean.valueOf(enableClockGating);
      this.enablePowerGating = Boolean.valueOf(enablePowerGating);
      this.logicRegions = logicRegions;
      this.powerSets = powerSets;
      this.netRegions = netRegions;
      this.powerSetsIndex = powerSetsIndex;
      this.logicRegionsSeqMap = logicRegionsSeqMap;
      this.protocolManager = protocolManager;
      HashMap<Port, Integer> _hashMap_1 = new HashMap<Port, Integer>();
      this.networkPortFanout = _hashMap_1;
      HashMap<Connection, Integer> _hashMap_2 = new HashMap<Connection, Integer>();
      this.networkPortConnectionFanout = _hashMap_2;
      HashMap<Port, String> _hashMap_3 = new HashMap<Port, String>();
      this.portClockDomain = _hashMap_3;
      HashMap<Actor, String> _hashMap_4 = new HashMap<Actor, String>();
      this.instanceClockDomain = _hashMap_4;
      HashMap<String, Integer> _hashMap_5 = new HashMap<String, Integer>();
      this.clockDomainsIndex = _hashMap_5;
      HashMap<Connection, List<Integer>> _hashMap_6 = new HashMap<Connection, List<Integer>>();
      this.connectionsClockDomain = _hashMap_6;
      this.computeNetworkClockDomains(network, clockSets);
      StringConcatenation _builder = new StringConcatenation();
      CharSequence _printHeaderComments = this.printHeaderComments();
      _builder.append(_printHeaderComments);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      CharSequence _printInterface = this.printInterface(luts);
      _builder.append(_printInterface);
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// internal signals");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      CharSequence _printInternalSignals = this.printInternalSignals(luts);
      _builder.append(_printInternalSignals);
      _builder.newLineIfNotEmpty();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.newLine();
      _builder.append("// body");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      {
        boolean _isEmpty = luts.isEmpty();
        boolean _not = (!_isEmpty);
        if (_not) {
          CharSequence _printConfig = this.printConfig(luts);
          _builder.append(_printConfig);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.newLine();
      {
        if (enableClockGating) {
          CharSequence _printEnableGenerator = this.printEnableGenerator();
          _builder.append(_printEnableGenerator);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.newLine();
      {
        if (enablePowerGating) {
          CharSequence _printPowerController = this.printPowerController();
          _builder.append(_printPowerController);
          _builder.newLineIfNotEmpty();
        }
      }
      _builder.newLine();
      CharSequence _printActors = this.printActors(clockSets);
      _builder.append(_printActors);
      _builder.newLineIfNotEmpty();
      CharSequence _printAssignments = this.printAssignments();
      _builder.append(_printAssignments);
      _builder.newLineIfNotEmpty();
      _builder.append("endmodule");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  /**
   * For each connection, if the connection has already been printed, remove the "printed" attribute from its source port or vertex.
   * 
   * TODO there is a similar function in PlatformComposer.removeAllPrintFlags(): do we need both?
   */
  public void removeAllPrintFlags() {
    EList<Connection> _connections = this.network.getConnections();
    for (final Connection connection : _connections) {
      Port _sourcePort = connection.getSourcePort();
      boolean _tripleEquals = (_sourcePort == null);
      if (_tripleEquals) {
        boolean _hasAttribute = connection.getSource().hasAttribute("printed");
        if (_hasAttribute) {
          connection.getSource().removeAttribute("printed");
        }
      } else {
        boolean _hasAttribute_1 = connection.getSourcePort().hasAttribute("printed");
        if (_hasAttribute_1) {
          connection.getSourcePort().removeAttribute("printed");
        }
      }
    }
  }
}
