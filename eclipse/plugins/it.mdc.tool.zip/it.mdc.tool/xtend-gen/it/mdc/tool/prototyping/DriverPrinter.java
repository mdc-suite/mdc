package it.mdc.tool.prototyping;

import it.mdc.tool.core.ConfigManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.orcc.df.Network;
import net.sf.orcc.df.Port;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

/**
 * Vivado AXI IP Driver Printer
 * 
 * @author Tiziana Fanni
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class DriverPrinter {
  private String coupling;
  
  private String processor;
  
  private boolean enDma;
  
  private Map<Port, Integer> portMap;
  
  private Map<Port, Integer> inputMap;
  
  private Map<Port, Integer> outputMap;
  
  public boolean isMemoryMapped() {
    boolean _equals = this.coupling.equals("mm");
    if (_equals) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean isArm() {
    boolean _equals = this.processor.equals("ARM");
    if (_equals) {
      return true;
    } else {
      return false;
    }
  }
  
  public boolean initDriverPrinter(final String coupling, final String processor, final Boolean enDma, final Map<Port, Integer> portMap, final Map<Port, Integer> inputMap, final Map<Port, Integer> outputMap) {
    boolean _xblockexpression = false;
    {
      this.coupling = coupling;
      this.portMap = portMap;
      this.inputMap = inputMap;
      this.outputMap = outputMap;
      this.processor = processor;
      _xblockexpression = this.enDma = (enDma).booleanValue();
    }
    return _xblockexpression;
  }
  
  public CharSequence printDriverSource(final Network network, final Map<String, Map<String, String>> networkVertexMap, final ConfigManager configManager) {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      Map<String, ArrayList<Port>> netIdPortMap = new LinkedHashMap<String, ArrayList<Port>>();
      int i = 0;
      Set<String> _keySet = networkVertexMap.keySet();
      for (final String net : _keySet) {
        {
          i = 0;
          List<Integer> _sort = IterableExtensions.<Integer>sort(this.portMap.values());
          for (final Integer id : _sort) {
            Set<Port> _keySet_1 = this.portMap.keySet();
            for (final Port port : _keySet_1) {
              boolean _equals = this.portMap.get(port).equals(id);
              if (_equals) {
                boolean _contains = networkVertexMap.get(net).values().contains(port.getName());
                if (_contains) {
                  boolean _containsKey = netIdPortMap.containsKey(net);
                  boolean _not = (!_containsKey);
                  if (_not) {
                    ArrayList<Port> newList = new ArrayList<Port>();
                    newList.add(i, port);
                    netIdPortMap.put(net, newList);
                  } else {
                    netIdPortMap.get(net).add(i, port);
                  }
                }
              }
            }
          }
        }
      }
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("/*****************************************************************************");
      _builder.newLine();
      _builder.append("*  Filename:          ");
      _builder.append(this.coupling);
      _builder.append("_accelerator.c");
      _builder.newLineIfNotEmpty();
      _builder.append("*  Description:       ");
      {
        boolean _isMemoryMapped = this.isMemoryMapped();
        if (_isMemoryMapped) {
          _builder.append("Memory-Mapped");
        } else {
          _builder.append("Stream");
        }
      }
      _builder.append(" Accelerator Driver");
      _builder.newLineIfNotEmpty();
      _builder.append("*  Date:              ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.append(" (by Multi-Dataflow Composer - Platform Composer)");
      _builder.newLineIfNotEmpty();
      _builder.append("*****************************************************************************/");
      _builder.newLine();
      _builder.newLine();
      _builder.append("#include \"");
      _builder.append(this.coupling);
      _builder.append("_accelerator.h\"");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      {
        Set<String> _keySet_1 = networkVertexMap.keySet();
        boolean _hasElements = false;
        for(final String net_1 : _keySet_1) {
          if (!_hasElements) {
            _hasElements = true;
          } else {
            _builder.appendImmediate("\n", "");
          }
          _builder.append("int ");
          _builder.append(this.coupling);
          _builder.append("_accelerator_");
          _builder.append(net_1);
          _builder.append("(");
          _builder.newLineIfNotEmpty();
          {
            ArrayList<Port> _get = netIdPortMap.get(net_1);
            boolean _hasElements_1 = false;
            for(final Port port : _get) {
              if (!_hasElements_1) {
                _hasElements_1 = true;
              } else {
                _builder.appendImmediate(",", "\t");
              }
              _builder.append("\t");
              _builder.append("// port ");
              String _name = port.getName();
              _builder.append(_name, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("int size_");
              String _name_1 = port.getName();
              _builder.append(_name_1, "\t");
              _builder.append(", int* data_");
              String _name_2 = port.getName();
              _builder.append(_name_2, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append("\t");
          _builder.append(") {");
          _builder.newLine();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("volatile int* config = (int*) XPAR_");
          String _upperCase = this.coupling.toUpperCase();
          _builder.append(_upperCase, "\t");
          _builder.append("_ACCELERATOR_0_CFG_BASEADDR;");
          _builder.newLineIfNotEmpty();
          {
            if ((!this.enDma)) {
              {
                Set<Port> _keySet_2 = this.portMap.keySet();
                for(final Port port_1 : _keySet_2) {
                  _builder.append("\t");
                  _builder.append("int idx_");
                  String _name_3 = port_1.getName();
                  _builder.append(_name_3, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.newLine();
          {
            boolean _isMemoryMapped_1 = this.isMemoryMapped();
            if (_isMemoryMapped_1) {
              _builder.append("\t");
              _builder.append("// configure I/O");
              _builder.newLine();
              {
                Set<Port> _keySet_3 = this.portMap.keySet();
                for(final Port port_2 : _keySet_3) {
                  _builder.append("\t");
                  _builder.append("*(config + ");
                  Integer _get_1 = this.portMap.get(port_2);
                  int _plus = ((_get_1).intValue() + 1);
                  _builder.append(_plus, "\t");
                  _builder.append(") = size_");
                  String _name_4 = port_2.getName();
                  _builder.append(_name_4, "\t");
                  _builder.append(" - 1;");
                  _builder.newLineIfNotEmpty();
                }
              }
              _builder.append("\t");
              _builder.newLine();
              {
                Set<Port> _keySet_4 = this.inputMap.keySet();
                for(final Port input : _keySet_4) {
                  _builder.append("\t");
                  _builder.append("// send data port ");
                  String _name_5 = input.getName();
                  _builder.append(_name_5, "\t");
                  _builder.newLineIfNotEmpty();
                  {
                    if (this.enDma) {
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x04>>2)) = 0x00000002; // verify idle");
                      _builder.newLine();
                      _builder.append("\t");
                      _builder.append("//*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x00>>2)) = 0x00001000;\t// irq en (optional)");
                      _builder.newLine();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x18>>2)) = (int) data_");
                      String _name_6 = input.getName();
                      _builder.append(_name_6, "\t");
                      _builder.append("; // src");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x20>>2)) = XPAR_MM_ACCELERATOR_0_MEM_BASEADDR + MM_ACCELERATOR_MEM_");
                      Integer _get_2 = this.portMap.get(input);
                      int _plus_1 = ((_get_2).intValue() + 1);
                      _builder.append(_plus_1, "\t");
                      _builder.append("_OFFSET; // dst");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x28>>2)) = size_");
                      String _name_7 = input.getName();
                      _builder.append(_name_7, "\t");
                      _builder.append("*4; // size [B]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("while((*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x04>>2)) & 0x2) != 0x2);");
                      _builder.newLine();
                    } else {
                      _builder.append("\t");
                      _builder.append("for(idx_");
                      String _name_8 = input.getName();
                      _builder.append(_name_8, "\t");
                      _builder.append("=0; idx_");
                      String _name_9 = input.getName();
                      _builder.append(_name_9, "\t");
                      _builder.append("<size_");
                      String _name_10 = input.getName();
                      _builder.append(_name_10, "\t");
                      _builder.append("; idx_");
                      String _name_11 = input.getName();
                      _builder.append(_name_11, "\t");
                      _builder.append("++) {");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((int *) (XPAR_MM_ACCELERATOR_0_MEM_BASEADDR + MM_ACCELERATOR_MEM_");
                      Integer _get_3 = this.portMap.get(input);
                      int _plus_2 = ((_get_3).intValue() + 1);
                      _builder.append(_plus_2, "\t\t");
                      _builder.append("_OFFSET + idx_");
                      String _name_12 = input.getName();
                      _builder.append(_name_12, "\t\t");
                      _builder.append("*4)) = *(data_");
                      String _name_13 = input.getName();
                      _builder.append(_name_13, "\t\t");
                      _builder.append("+idx_");
                      String _name_14 = input.getName();
                      _builder.append(_name_14, "\t\t");
                      _builder.append(");");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("}");
                      _builder.newLine();
                    }
                  }
                }
              }
            } else {
              _builder.append("\t");
              _builder.append("// configure I/O");
              _builder.newLine();
              {
                Set<Port> _keySet_5 = this.outputMap.keySet();
                for(final Port output : _keySet_5) {
                  _builder.append("\t");
                  _builder.append("*(config + ");
                  Integer _get_4 = this.outputMap.get(output);
                  int _plus_3 = ((_get_4).intValue() + 1);
                  _builder.append(_plus_3, "\t");
                  _builder.append(") = size_");
                  String _name_15 = output.getName();
                  _builder.append(_name_15, "\t");
                  _builder.append(";");
                  _builder.newLineIfNotEmpty();
                }
              }
            }
          }
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("// start execution");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("*(config) = 0x");
          int _networkId = configManager.getNetworkId(net_1);
          int _doubleLessThan = (_networkId << 24);
          int _plus_4 = (_doubleLessThan + 1);
          String _hexString = Integer.toHexString(_plus_4);
          _builder.append(_hexString, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
          {
            boolean _isMemoryMapped_2 = this.isMemoryMapped();
            boolean _not = (!_isMemoryMapped_2);
            if (_not) {
              {
                Set<Port> _keySet_6 = this.inputMap.keySet();
                for(final Port input_1 : _keySet_6) {
                  _builder.append("\t");
                  _builder.append("\t");
                  _builder.append("// send data port ");
                  String _name_16 = input_1.getName();
                  _builder.append(_name_16, "\t\t");
                  _builder.newLineIfNotEmpty();
                  {
                    if (this.enDma) {
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_5 = this.inputMap.get(input_1);
                      _builder.append(_get_5, "\t\t");
                      _builder.append("_BASEADDR + (0x00>>2)) = 0x00000001; // start");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_6 = this.inputMap.get(input_1);
                      _builder.append(_get_6, "\t\t");
                      _builder.append("_BASEADDR + (0x04>>2)) = 0x00000000; // reset idle");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_7 = this.inputMap.get(input_1);
                      _builder.append(_get_7, "\t\t");
                      _builder.append("_BASEADDR + (0x18>>2)) = (int) data_");
                      String _name_17 = input_1.getName();
                      _builder.append(_name_17, "\t\t");
                      _builder.append("; // src");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_8 = this.inputMap.get(input_1);
                      _builder.append(_get_8, "\t\t");
                      _builder.append("_BASEADDR + (0x28>>2)) = size_");
                      String _name_18 = input_1.getName();
                      _builder.append(_name_18, "\t\t");
                      _builder.append("*4; // size [B]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("while(((*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_9 = this.inputMap.get(input_1);
                      _builder.append(_get_9, "\t\t");
                      _builder.append("_BASEADDR + (0x04>>2))) & 0x2) != 0x2);");
                      _builder.newLineIfNotEmpty();
                    } else {
                      {
                        boolean _isArm = this.isArm();
                        if (_isArm) {
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) XPAR_AXI_FIFO_");
                          Integer _get_10 = this.inputMap.get(input_1);
                          _builder.append(_get_10, "\t\t");
                          _builder.append("_BASEADDR) = 0xFFFFFFFF;\t\t\t\t\t\t\t\t// clear interrupts");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_11 = this.inputMap.get(input_1);
                          _builder.append(_get_11, "\t\t");
                          _builder.append("_BASEADDR + 0x2C)) = 0x0;\t\t\t\t\t\t\t\t// set user ID");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("for(idx_");
                          String _name_19 = input_1.getName();
                          _builder.append(_name_19, "\t\t");
                          _builder.append("=0; idx_");
                          String _name_20 = input_1.getName();
                          _builder.append(_name_20, "\t\t");
                          _builder.append("<size_");
                          String _name_21 = input_1.getName();
                          _builder.append(_name_21, "\t\t");
                          _builder.append("; idx_");
                          String _name_22 = input_1.getName();
                          _builder.append(_name_22, "\t\t");
                          _builder.append("++) {");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("\t\t");
                          _builder.append("*((volatile int*) XPAR_AXI_FIFO_");
                          Integer _get_12 = this.inputMap.get(input_1);
                          _builder.append(_get_12, "\t\t\t\t");
                          _builder.append("_AXI4_BASEADDR) = *(data_");
                          String _name_23 = input_1.getName();
                          _builder.append(_name_23, "\t\t\t\t");
                          _builder.append("+idx_");
                          String _name_24 = input_1.getName();
                          _builder.append(_name_24, "\t\t\t\t");
                          _builder.append(");\t// send data");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("}");
                          _builder.newLine();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_13 = this.inputMap.get(input_1);
                          _builder.append(_get_13, "\t\t");
                          _builder.append("_BASEADDR + 0x14)) = size_");
                          String _name_25 = input_1.getName();
                          _builder.append(_name_25, "\t\t");
                          _builder.append("*4;\t\t\t\t// tx length (start tx)");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("while((*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_14 = this.inputMap.get(input_1);
                          _builder.append(_get_14, "\t\t");
                          _builder.append("_BASEADDR)) & 0x08000000) != 0x08000000);\t\t// wait for interrupt");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_15 = this.inputMap.get(input_1);
                          _builder.append(_get_15, "\t\t");
                          _builder.append("_BASEADDR)) = 0xFFFFFFFF;\t\t\t\t\t\t\t\t// clear interrupts");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("for(idx_");
                          String _name_26 = input_1.getName();
                          _builder.append(_name_26, "\t\t");
                          _builder.append("=0; idx_");
                          String _name_27 = input_1.getName();
                          _builder.append(_name_27, "\t\t");
                          _builder.append("<size_");
                          String _name_28 = input_1.getName();
                          _builder.append(_name_28, "\t\t");
                          _builder.append("; idx_");
                          String _name_29 = input_1.getName();
                          _builder.append(_name_29, "\t\t");
                          _builder.append("++) {");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("putfsl(*(data_");
                          String _name_30 = input_1.getName();
                          _builder.append(_name_30, "\t\t\t");
                          _builder.append("+idx_");
                          String _name_31 = input_1.getName();
                          _builder.append(_name_31, "\t\t\t");
                          _builder.append("), ");
                          Integer _get_16 = this.inputMap.get(input_1);
                          _builder.append(_get_16, "\t\t\t");
                          _builder.append(");");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("}");
                          _builder.newLine();
                        }
                      }
                    }
                  }
                }
              }
              _builder.append("\t");
              _builder.newLine();
              {
                Set<Port> _keySet_7 = this.outputMap.keySet();
                for(final Port output_1 : _keySet_7) {
                  _builder.append("\t");
                  _builder.append("\t");
                  _builder.append("// receive data port ");
                  String _name_32 = output_1.getName();
                  _builder.append(_name_32, "\t\t");
                  _builder.newLineIfNotEmpty();
                  {
                    if (this.enDma) {
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_17 = this.outputMap.get(output_1);
                      _builder.append(_get_17, "\t\t");
                      _builder.append("_BASEADDR + (0x30>>2)) = 0x00000001; // start");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_18 = this.outputMap.get(output_1);
                      _builder.append(_get_18, "\t\t");
                      _builder.append("_BASEADDR + (0x34>>2)) = 0x00000000; // reset idle");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_19 = this.outputMap.get(output_1);
                      _builder.append(_get_19, "\t\t");
                      _builder.append("_BASEADDR + (0x48>>2)) = (int) data_");
                      String _name_33 = output_1.getName();
                      _builder.append(_name_33, "\t\t");
                      _builder.append("; // dst");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_20 = this.outputMap.get(output_1);
                      _builder.append(_get_20, "\t\t");
                      _builder.append("_BASEADDR + (0x58>>2)) = size_");
                      String _name_34 = output_1.getName();
                      _builder.append(_name_34, "\t\t");
                      _builder.append("*4; // size [B]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("while(((*((volatile int*) XPAR_AXI_DMA_");
                      Integer _get_21 = this.outputMap.get(output_1);
                      _builder.append(_get_21, "\t\t");
                      _builder.append("_BASEADDR + (0x34>>2))) & 0x2) != 0x2);");
                      _builder.newLineIfNotEmpty();
                    } else {
                      {
                        boolean _isArm_1 = this.isArm();
                        if (_isArm_1) {
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("while(*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_22 = this.outputMap.get(output_1);
                          _builder.append(_get_22, "\t\t");
                          _builder.append("_BASEADDR + 0x1C)) < size_");
                          String _name_35 = output_1.getName();
                          _builder.append(_name_35, "\t\t");
                          _builder.append(");\t// verify read fifo occupancy");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("//while((*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_23 = this.outputMap.get(output_1);
                          _builder.append(_get_23, "\t\t");
                          _builder.append("_BASEADDR)) & 0x04000000) != 0x04000000);\t// wait for interrupt (not always working with this condition)");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_24 = this.outputMap.get(output_1);
                          _builder.append(_get_24, "\t\t");
                          _builder.append("_BASEADDR)) = 0xFFFFFFFF;\t\t\t\t\t\t\t// clear interrupts");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("for(idx_");
                          String _name_36 = output_1.getName();
                          _builder.append(_name_36, "\t\t");
                          _builder.append("=0; idx_");
                          String _name_37 = output_1.getName();
                          _builder.append(_name_37, "\t\t");
                          _builder.append("<size_");
                          String _name_38 = output_1.getName();
                          _builder.append(_name_38, "\t\t");
                          _builder.append("; idx_");
                          String _name_39 = output_1.getName();
                          _builder.append(_name_39, "\t\t");
                          _builder.append("++) {");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*(data_");
                          String _name_40 = output_1.getName();
                          _builder.append(_name_40, "\t\t\t");
                          _builder.append("+idx_");
                          String _name_41 = output_1.getName();
                          _builder.append(_name_41, "\t\t\t");
                          _builder.append(") = *((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_25 = this.outputMap.get(output_1);
                          _builder.append(_get_25, "\t\t\t");
                          _builder.append("_AXI4_BASEADDR + 0x1000));\t// read data");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("}");
                          _builder.newLine();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("*((volatile int*) (XPAR_AXI_FIFO_");
                          Integer _get_26 = this.outputMap.get(output_1);
                          _builder.append(_get_26, "\t\t");
                          _builder.append("_BASEADDR)) = 0xFFFFFFFF;\t\t\t\t\t// clear interrupts*/");
                          _builder.newLineIfNotEmpty();
                        } else {
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("for(idx_");
                          String _name_42 = output_1.getName();
                          _builder.append(_name_42, "\t\t");
                          _builder.append("=0; idx_");
                          String _name_43 = output_1.getName();
                          _builder.append(_name_43, "\t\t");
                          _builder.append("<size_");
                          String _name_44 = output_1.getName();
                          _builder.append(_name_44, "\t\t");
                          _builder.append("; idx_");
                          String _name_45 = output_1.getName();
                          _builder.append(_name_45, "\t\t");
                          _builder.append("++) {");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("getfsl(*(data_");
                          String _name_46 = output_1.getName();
                          _builder.append(_name_46, "\t\t\t");
                          _builder.append("+idx_");
                          String _name_47 = output_1.getName();
                          _builder.append(_name_47, "\t\t\t");
                          _builder.append("), ");
                          Integer _get_27 = this.outputMap.get(output_1);
                          _builder.append(_get_27, "\t\t\t");
                          _builder.append(");");
                          _builder.newLineIfNotEmpty();
                          _builder.append("\t");
                          _builder.append("\t");
                          _builder.append("}");
                          _builder.newLine();
                        }
                      }
                    }
                  }
                }
              }
            } else {
              _builder.append("\t");
              _builder.append("// wait for completion");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("while( ((*(config)) & 0x4) != 0x4 );");
              _builder.newLine();
              _builder.append("\t");
              _builder.append("\t\t");
              _builder.newLine();
              {
                Set<Port> _keySet_8 = this.outputMap.keySet();
                for(final Port output_2 : _keySet_8) {
                  _builder.append("\t");
                  _builder.append("// receive data port ");
                  String _name_48 = output_2.getName();
                  _builder.append(_name_48, "\t");
                  _builder.newLineIfNotEmpty();
                  {
                    if (this.enDma) {
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x04>>2)) = 0x00000002; // verify idle");
                      _builder.newLine();
                      _builder.append("\t");
                      _builder.append("//*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x00>>2)) = 0x00001000;\t// irq en (optional)");
                      _builder.newLine();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x18>>2)) = XPAR_MM_ACCELERATOR_0_MEM_BASEADDR + MM_ACCELERATOR_MEM_");
                      Integer _get_28 = this.portMap.get(output_2);
                      int _plus_5 = ((_get_28).intValue() + 1);
                      _builder.append(_plus_5, "\t");
                      _builder.append("_OFFSET; // src");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x20>>2)) = (int) data_");
                      String _name_49 = output_2.getName();
                      _builder.append(_name_49, "\t");
                      _builder.append("; // dst");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x28>>2)) = size_");
                      String _name_50 = output_2.getName();
                      _builder.append(_name_50, "\t");
                      _builder.append("*4; // size [B]");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("while((*((volatile int*) XPAR_AXI_CDMA_0_BASEADDR + (0x04>>2)) & 0x2) != 0x2);");
                      _builder.newLine();
                    } else {
                      _builder.append("\t");
                      _builder.append("for(idx_");
                      String _name_51 = output_2.getName();
                      _builder.append(_name_51, "\t");
                      _builder.append("=0; idx_");
                      String _name_52 = output_2.getName();
                      _builder.append(_name_52, "\t");
                      _builder.append("<size_");
                      String _name_53 = output_2.getName();
                      _builder.append(_name_53, "\t");
                      _builder.append("; idx_");
                      String _name_54 = output_2.getName();
                      _builder.append(_name_54, "\t");
                      _builder.append("++) {");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("\t");
                      _builder.append("*(data_");
                      String _name_55 = output_2.getName();
                      _builder.append(_name_55, "\t\t");
                      _builder.append("+idx_");
                      String _name_56 = output_2.getName();
                      _builder.append(_name_56, "\t\t");
                      _builder.append(") = *((int *) (XPAR_MM_ACCELERATOR_0_MEM_BASEADDR + MM_ACCELERATOR_MEM_");
                      Integer _get_29 = this.portMap.get(output_2);
                      int _plus_6 = ((_get_29).intValue() + 1);
                      _builder.append(_plus_6, "\t\t");
                      _builder.append("_OFFSET + idx_");
                      String _name_57 = output_2.getName();
                      _builder.append(_name_57, "\t\t");
                      _builder.append("*4));");
                      _builder.newLineIfNotEmpty();
                      _builder.append("\t");
                      _builder.append("}");
                      _builder.newLine();
                    }
                  }
                }
              }
            }
          }
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("// stop execution");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("//*(config) = 0x");
          String _hexString_1 = Integer.toHexString(0);
          _builder.append(_hexString_1, "\t");
          _builder.append(";");
          _builder.newLineIfNotEmpty();
          _builder.append("\t");
          _builder.newLine();
          _builder.append("\t");
          _builder.append("return 0;");
          _builder.newLine();
          _builder.append("}");
          _builder.newLine();
        }
      }
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printDriverHeader(final Network network, final Map<String, Map<String, String>> networkVertexMap) {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      Map<String, ArrayList<Port>> netIdPortMap = new LinkedHashMap<String, ArrayList<Port>>();
      int i = 0;
      Set<String> _keySet = networkVertexMap.keySet();
      for (final String net : _keySet) {
        {
          i = 0;
          List<Integer> _sort = IterableExtensions.<Integer>sort(this.portMap.values());
          for (final Integer id : _sort) {
            Set<Port> _keySet_1 = this.portMap.keySet();
            for (final Port port : _keySet_1) {
              boolean _equals = this.portMap.get(port).equals(id);
              if (_equals) {
                boolean _contains = networkVertexMap.get(net).values().contains(port.getName());
                if (_contains) {
                  boolean _containsKey = netIdPortMap.containsKey(net);
                  boolean _not = (!_containsKey);
                  if (_not) {
                    ArrayList<Port> newList = new ArrayList<Port>();
                    newList.add(i, port);
                    netIdPortMap.put(net, newList);
                  } else {
                    netIdPortMap.get(net).add(i, port);
                  }
                }
              }
            }
          }
        }
      }
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("/*****************************************************************************");
      _builder.newLine();
      _builder.append("*  Filename:          ");
      _builder.append(this.coupling);
      _builder.append("_accelerator.h");
      _builder.newLineIfNotEmpty();
      _builder.append("*  Description:       ");
      {
        boolean _isMemoryMapped = this.isMemoryMapped();
        if (_isMemoryMapped) {
          _builder.append("Memory-Mapped");
        } else {
          _builder.append("Stream");
        }
      }
      _builder.append(" Accelerator Driver Header");
      _builder.newLineIfNotEmpty();
      _builder.append("*  Date:              ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.append(" (by Multi-Dataflow Composer - Platform Composer)");
      _builder.newLineIfNotEmpty();
      _builder.append("*****************************************************************************/");
      _builder.newLine();
      _builder.newLine();
      _builder.append("#ifndef ");
      String _upperCase = this.coupling.toUpperCase();
      _builder.append(_upperCase);
      _builder.append("_ACCELERATOR_H");
      _builder.newLineIfNotEmpty();
      _builder.append("#define ");
      String _upperCase_1 = this.coupling.toUpperCase();
      _builder.append(_upperCase_1);
      _builder.append("_ACCELERATOR_H");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("/***************************** Include Files *******************************/\t\t");
      _builder.newLine();
      _builder.append("#include \"xparameters.h\"");
      _builder.newLine();
      {
        if ((((!this.isMemoryMapped()) && (!this.enDma)) && (!this.isArm()))) {
          _builder.append("#include \"fsl.h\"");
        }
      }
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("/************************** Constant Definitions ***************************/");
      _builder.newLine();
      {
        boolean _isMemoryMapped_1 = this.isMemoryMapped();
        if (_isMemoryMapped_1) {
          {
            Set<Port> _keySet_1 = this.portMap.keySet();
            for(final Port port : _keySet_1) {
              _builder.append("// ");
              String _name = port.getName();
              _builder.append(_name);
              _builder.append(" local memory offset (size in terms of number of words)");
              _builder.newLineIfNotEmpty();
              _builder.append("#define MEM_");
              Integer _get = this.portMap.get(port);
              int _plus = ((_get).intValue() + 1);
              _builder.append(_plus);
              _builder.append("_SIZE 256");
              _builder.newLineIfNotEmpty();
              _builder.append("#define ");
              String _upperCase_2 = this.coupling.toUpperCase();
              _builder.append(_upperCase_2);
              _builder.append("_ACCELERATOR_MEM_");
              Integer _get_1 = this.portMap.get(port);
              int _plus_1 = ((_get_1).intValue() + 1);
              _builder.append(_plus_1);
              _builder.append("_OFFSET ");
              {
                Integer _get_2 = this.portMap.get(port);
                int _plus_2 = ((_get_2).intValue() + 1);
                boolean _equals = (_plus_2 == 1);
                if (_equals) {
                  _builder.append("0");
                } else {
                  String _upperCase_3 = this.coupling.toUpperCase();
                  _builder.append(_upperCase_3);
                  _builder.append("_ACCELERATOR_MEM_");
                  Integer _get_3 = this.portMap.get(port);
                  _builder.append(_get_3);
                  _builder.append("_OFFSET + (MEM_");
                  Integer _get_4 = this.portMap.get(port);
                  _builder.append(_get_4);
                  _builder.append("_SIZE<<2)");
                }
              }
              _builder.newLineIfNotEmpty();
            }
          }
        }
      }
      _builder.append("/************************* Functions Definitions ***************************/");
      _builder.newLine();
      _builder.newLine();
      _builder.newLine();
      {
        Set<String> _keySet_2 = networkVertexMap.keySet();
        for(final String net_1 : _keySet_2) {
          _builder.append("int ");
          _builder.append(this.coupling);
          _builder.append("_accelerator_");
          _builder.append(net_1);
          _builder.append("(");
          _builder.newLineIfNotEmpty();
          {
            ArrayList<Port> _get_5 = netIdPortMap.get(net_1);
            boolean _hasElements = false;
            for(final Port port_1 : _get_5) {
              if (!_hasElements) {
                _hasElements = true;
              } else {
                _builder.appendImmediate(",", "\t");
              }
              _builder.append("\t");
              _builder.append("// port ");
              String _name_1 = port_1.getName();
              _builder.append(_name_1, "\t");
              _builder.newLineIfNotEmpty();
              _builder.append("\t");
              _builder.append("int size_");
              String _name_2 = port_1.getName();
              _builder.append(_name_2, "\t");
              _builder.append(", int* data_");
              String _name_3 = port_1.getName();
              _builder.append(_name_3, "\t");
              _builder.newLineIfNotEmpty();
            }
          }
          _builder.append(");");
          _builder.newLine();
          _builder.newLine();
        }
      }
      _builder.newLine();
      _builder.append("#endif /** MM_ACCELERATOR_H */");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public CharSequence printDriverTcl() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("proc generate {drv_handle} {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("xdefine_include_file $drv_handle \"xparameters.h\" \"");
    _builder.append(this.coupling, "\t");
    _builder.append("_accelerator\" \"NUM_INSTANCES\" \"DEVICE_ID\"  \"C_CFG_BASEADDR\" \"C_CFG_HIGHADDR\" ");
    {
      boolean _isMemoryMapped = this.isMemoryMapped();
      if (_isMemoryMapped) {
        _builder.append("\"C_MEM_BASEADDR\" \"C_MEM_HIGHADDR\"");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public CharSequence printDriverMdd() {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("OPTION psf_version = 2.1;");
    _builder.newLine();
    _builder.newLine();
    _builder.append("BEGIN DRIVER ");
    _builder.append(this.coupling);
    _builder.append("_accelerator");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("OPTION supported_peripherals = (");
    _builder.append(this.coupling, "\t");
    _builder.append("_accelerator);");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("OPTION copyfiles = all;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("OPTION VERSION = 1.0;");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("OPTION NAME = ");
    _builder.append(this.coupling, "\t");
    _builder.append("_accelerator;");
    _builder.newLineIfNotEmpty();
    _builder.append("END DRIVER");
    _builder.newLine();
    return _builder;
  }
}
