package it.mdc.tool.core.platformComposer;

import com.google.common.base.Objects;
import it.mdc.tool.core.ConfigManager;
import it.mdc.tool.core.sboxManagement.SboxLut;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import net.sf.orcc.df.Network;
import net.sf.orcc.util.OrccLogger;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.ExclusiveRange;

/**
 * A Verilog Network Configurator printer
 * 
 * @author Carlo Sau
 */
@SuppressWarnings("all")
public class ConfigPrinter {
  private List<SboxLut> luts;
  
  private List<Network> networks;
  
  private ConfigManager configManager;
  
  public CharSequence headerComments() {
    CharSequence _xblockexpression = null;
    {
      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
      Date date = new Date();
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// Multi-Dataflow Composer tool - Platform Composer");
      _builder.newLine();
      _builder.append("// Configurator module ");
      _builder.newLine();
      _builder.append("// Date: ");
      String _format = dateFormat.format(date);
      _builder.append(_format);
      _builder.newLineIfNotEmpty();
      _builder.append("//");
      _builder.newLine();
      _builder.append("// ----------------------------------------------------------------------------");
      _builder.newLine();
      _xblockexpression = _builder;
    }
    return _xblockexpression;
  }
  
  public void computeNets() {
    boolean _equals = Objects.equal(this.configManager, null);
    if (_equals) {
      OrccLogger.warnln("Warning: configManager is null!");
      return;
    }
    if ((Objects.equal(this.luts, null) || this.luts.isEmpty())) {
      OrccLogger.warnln("Warning: luts is null or empty!");
      return;
    }
    final List<Network> networkList = this.configManager.getNetworkList();
    boolean _notEquals = (!Objects.equal(networkList, null));
    if (_notEquals) {
      for (final Network net : networkList) {
        boolean _notEquals_1 = (!Objects.equal(net, null));
        if (_notEquals_1) {
          final SboxLut firstLut = this.luts.get(0);
          boolean _notEquals_2 = (!Objects.equal(firstLut, null));
          if (_notEquals_2) {
            try {
              final Network foundNet = firstLut.getNetworkByName(net.getSimpleName());
              boolean _notEquals_3 = (!Objects.equal(foundNet, null));
              if (_notEquals_3) {
                this.networks.add(foundNet);
              } else {
                String _simpleName = net.getSimpleName();
                String _plus = ("[DEBUG ConfigPrinter.computeNets] Network " + _simpleName);
                String _plus_1 = (_plus + " not found in LUT (returned null)");
                OrccLogger.warnln(_plus_1);
                this.networks.add(net);
              }
            } catch (final Throwable _t) {
              if (_t instanceof IndexOutOfBoundsException) {
                this.networks.add(net);
              } else if (_t instanceof Exception) {
                this.networks.add(net);
              } else {
                throw Exceptions.sneakyThrow(_t);
              }
            }
          } else {
            this.networks.add(net);
          }
        }
      }
    }
  }
  
  public String printBody() {
    if ((Objects.equal(this.luts, null) || this.luts.isEmpty())) {
      OrccLogger.traceln("Warning: luts is null or empty!");
      return "";
    }
    if ((Objects.equal(this.networks, null) || this.networks.isEmpty())) {
      OrccLogger.traceln("Warning: networks is null or empty!");
      return "";
    }
    try {
      final StringBuilder result = new StringBuilder();
      StringConcatenation _builder = new StringConcatenation();
      _builder.newLine();
      _builder.append("reg [");
      int _size = this.luts.size();
      int _minus = (_size - 1);
      _builder.append(_minus);
      _builder.append(":0] sel;");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      _builder.append("// case ID");
      _builder.newLine();
      _builder.append("always@(ID)");
      _builder.newLine();
      _builder.append("case(ID)");
      _builder.newLine();
      result.append(_builder);
      for (final Network network : this.networks) {
        boolean _notEquals = (!Objects.equal(network, null));
        if (_notEquals) {
          try {
            final int networkId = this.configManager.getNetworkId(network.getSimpleName());
            String _simpleName = network.getSimpleName();
            String _plus = ((("8\'d" + Integer.valueOf(networkId)) + ":    begin    // ") + _simpleName);
            String _plus_1 = (_plus + "\n");
            result.append(_plus_1);
            for (final SboxLut lut : this.luts) {
              boolean _notEquals_1 = (!Objects.equal(lut, null));
              if (_notEquals_1) {
                try {
                  final boolean lutValue = lut.getLutValue(network, 0);
                  Integer _count = lut.getCount();
                  String _plus_2 = ("sel[" + _count);
                  String _plus_3 = (_plus_2 + "]=");
                  String _xifexpression = null;
                  if (lutValue) {
                    _xifexpression = "1\'b1";
                  } else {
                    _xifexpression = "1\'b0";
                  }
                  String _plus_4 = (_plus_3 + _xifexpression);
                  String _plus_5 = (_plus_4 + ";\n");
                  result.append(_plus_5);
                } catch (final Throwable _t) {
                  if (_t instanceof Exception) {
                    Integer _count_1 = lut.getCount();
                    String _plus_6 = ("// ERROR: sel[" + _count_1);
                    String _plus_7 = (_plus_6 + "]=?;\n");
                    result.append(_plus_7);
                  } else {
                    throw Exceptions.sneakyThrow(_t);
                  }
                }
              }
            }
            result.append("end\n");
          } catch (final Throwable _t) {
            if (_t instanceof Exception) {
              String _simpleName_1 = network.getSimpleName();
              String _plus_2 = ("// ERROR: Network " + _simpleName_1);
              String _plus_3 = (_plus_2 + " not found in configManager\n");
              result.append(_plus_3);
            } else {
              throw Exceptions.sneakyThrow(_t);
            }
          }
        } else {
          OrccLogger.warnln("Warning: Found null network in networks list!");
        }
      }
      int _size_1 = this.luts.size();
      String _plus = ("default:    sel=" + Integer.valueOf(_size_1));
      String _plus_1 = (_plus + "\'bx;\n");
      result.append(_plus_1);
      result.append("endcase\n");
      return result.toString();
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception e = (Exception)_t;
        e.printStackTrace();
        return "// ERROR: Failed to generate configuration body";
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  public CharSequence printSignals() {
    CharSequence _xblockexpression = null;
    {
      boolean _equals = Objects.equal(this.luts, null);
      if (_equals) {
        OrccLogger.warnln("Warning: luts is null, using default size 0");
        StringConcatenation _builder = new StringConcatenation();
        _builder.newLine();
        _builder.append("// Input");
        _builder.newLine();
        _builder.append("input [7:0] ID;");
        _builder.newLine();
        _builder.newLine();
        _builder.append("// Ouptut(s)");
        _builder.newLine();
        _builder.append("output [0:0] sel;");
        _builder.newLine();
        _builder.newLine();
        return _builder.toString();
      }
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.newLine();
      _builder_1.append("// Input");
      _builder_1.newLine();
      _builder_1.append("input [7:0] ID;");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("// Ouptut(s)");
      _builder_1.newLine();
      _builder_1.append("output [");
      int _size = this.luts.size();
      int _minus = (_size - 1);
      _builder_1.append(_minus);
      _builder_1.append(":0] sel;");
      _builder_1.newLineIfNotEmpty();
      _builder_1.newLine();
      _xblockexpression = _builder_1;
    }
    return _xblockexpression;
  }
  
  public CharSequence printInterface(final Network network) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.newLine();
    _builder.append("module configurator(");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("ID,");
    _builder.newLine();
    _builder.append("    ");
    _builder.append("sel");
    _builder.newLine();
    _builder.append(");");
    _builder.newLine();
    _builder.newLine();
    return _builder;
  }
  
  public String printConfig(final Network network, final List<SboxLut> luts, final ConfigManager configManager) {
    this.luts = luts;
    this.configManager = configManager;
    ArrayList<Network> _arrayList = new ArrayList<Network>();
    this.networks = _arrayList;
    this.computeNets();
    if (((!Objects.equal(this.networks, null)) && (!this.networks.isEmpty()))) {
      int _size = this.networks.size();
      ExclusiveRange _doubleDotLessThan = new ExclusiveRange(0, _size, true);
      for (final Integer i : _doubleDotLessThan) {
        final Network net = this.networks.get((i).intValue());
      }
    }
    boolean _notEquals = (!Objects.equal(this.luts, null));
    if (_notEquals) {
      int _size_1 = this.luts.size();
      ExclusiveRange _doubleDotLessThan_1 = new ExclusiveRange(0, _size_1, true);
      for (final Integer i_1 : _doubleDotLessThan_1) {
        {
          final SboxLut lut = this.luts.get((i_1).intValue());
          boolean _notEquals_1 = (!Objects.equal(lut, null));
          if (_notEquals_1) {
            try {
              if (((!this.networks.isEmpty()) && (!Objects.equal(this.networks.get(0), null)))) {
                final boolean testValue = lut.getLutValue(this.networks.get(0), 0);
              }
            } catch (final Throwable _t) {
              if (_t instanceof Exception) {
              } else {
                throw Exceptions.sneakyThrow(_t);
              }
            }
          }
        }
      }
    }
    final CharSequence header = this.headerComments();
    final CharSequence interfacePart = this.printInterface(network);
    final CharSequence signalsPart = this.printSignals();
    final String bodyPart = this.printBody();
    StringConcatenation _builder = new StringConcatenation();
    _builder.append(header);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Module Interface");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append(interfacePart);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Module Signals");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append(signalsPart);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// Body");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append(bodyPart);
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("endmodule");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    _builder.append("// ----------------------------------------------------------------------------");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
}
